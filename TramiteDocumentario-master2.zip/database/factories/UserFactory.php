<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Usuario;
use App\TablaInfo\UsuarioTablaInfo as UserAttr;
use Faker\Generator as Faker;
use Illuminate\Support\Facades\Hash;

$factory->define(Usuario::class, function (Faker $faker) {
    return [
        UserAttr::USERNAME => $faker->unique()->userName,
        UserAttr::NOMBRES => $faker->firstName,
        UserAttr::APELLIDOS => $faker->lastName,
        UserAttr::DNI => $faker->randomNumber(8),
        UserAttr::CORREO => $faker->email,
        UserAttr::PASSWORD => Hash::make('123456789'),
        UserAttr::CARGO => $faker->jobTitle,
    ];
});
