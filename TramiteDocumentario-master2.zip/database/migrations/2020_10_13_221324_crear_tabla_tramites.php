<?php

use App\TablaInfo\TramiteTablaInfo;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CrearTablaTramites extends Migration
{
    private const TABLA_TRAMITES = TramiteTablaInfo::NOMBRE_TABLA;

    public function up()
    {
        Schema::create(self::TABLA_TRAMITES, function (Blueprint $table) {
            $table->id();
            $table->enum(TramiteTablaInfo::PRIORIDAD, array_keys(TramiteTablaInfo::prioridadesDict()))
                ->default(array_keys(TramiteTablaInfo::prioridadesDict())[0]);
            $table->unsignedBigInteger(TramiteTablaInfo::USER_CREADOR_ID);
            $table->unsignedBigInteger(TramiteTablaInfo::USER_EXPEDIENTE_ID);
            $table->date(TramiteTablaInfo::FECHA_EMISION);

            $table->unsignedBigInteger(TramiteTablaInfo::TIPO_SOLICITUD_ID)->nullable();
            $table->string(TramiteTablaInfo::OTRO_TIPO_SOLICITUD)->nullable();

            $table->enum(TramiteTablaInfo::TIPO_SOLICITANTE, array_keys(TramiteTablaInfo::getPrivateTiposSolicitante()))
                ->default(array_keys(TramiteTablaInfo::getPrivateTiposSolicitante())[0]);
            $table->string(TramiteTablaInfo::DATO_IDENTIFICACION);
            $table->string(TramiteTablaInfo::NUMERO_TRAMITE)->unique();
            $table->enum(TramiteTablaInfo::FORMA_RECEPCION, array_keys(TramiteTablaInfo::formasRecepcionDict()))
                ->default(array_keys(TramiteTablaInfo::formasRecepcionDict())[0]);
            $table->string(TramiteTablaInfo::ARCHIVO_TRAMITE)->nullable();
            $table->string(TramiteTablaInfo::FOLIOS);
            $table->text(TramiteTablaInfo::ASUNTO);
            $table->string(TramiteTablaInfo::ANEXOS)->nullable();
            $table->string(TramiteTablaInfo::REFERENCIA)->nullable();

            $table->string(TramiteTablaInfo::CODIGO_PAGO)->nullable()->unique();
            $table->string(TramiteTablaInfo::ADJUNTO_PAGO)->nullable();

            $table->timestamp(TramiteTablaInfo::FECHA_CREADO)->nullable();
            $table->timestamp(TramiteTablaInfo::FECHA_ACTUALIZADO)->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLA_TRAMITES);
    }
}
