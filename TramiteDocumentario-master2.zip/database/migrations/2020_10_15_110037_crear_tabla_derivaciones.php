<?php

use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CrearTablaDerivaciones extends Migration
{
    private const TABLA_DERIVACIONES = DerivacionTablaInfo::NOMBRE_TABLA;

    public function up()
    {
        Schema::create(self::TABLA_DERIVACIONES, function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger(DerivacionTablaInfo::TRAMITE_ID);
            $table->boolean(DerivacionTablaInfo::ES_COPIA)->default(false);
            $table->unsignedBigInteger(TramiteTablaInfo::ARCHIVADOR_ID)->nullable();
            $table->unsignedBigInteger(DerivacionTablaInfo::AREA_DESTINO_ID)->nullable();
            $table->unsignedBigInteger(DerivacionTablaInfo::USER_DESTINO_ID)->nullable();
            $table->text(DerivacionTablaInfo::DETALLE)->nullable();
            $table->string(DerivacionTablaInfo::PROVEIDO)->nullable();
            $table->enum(DerivacionTablaInfo::ESTADO, array_keys(DerivacionTablaInfo::estadoDerivacionDict()))
                ->default(DerivacionTablaInfo::ESTADO_POR_RECIBIR);
            $table->timestamp(DerivacionTablaInfo::FECHA_CREADO)->nullable();
            $table->timestamp(DerivacionTablaInfo::FECHA_ACTUALIZADO)->nullable();

            $table->foreign(DerivacionTablaInfo::TRAMITE_ID)
                ->references(TramiteTablaInfo::ID)
                ->on(TramiteTablaInfo::NOMBRE_TABLA)
                ->onDelete('CASCADE')
                ->onUpdate('CASCADE');
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLA_DERIVACIONES);
    }
}
