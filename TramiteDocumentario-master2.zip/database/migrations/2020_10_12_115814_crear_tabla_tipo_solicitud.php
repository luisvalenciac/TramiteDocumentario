<?php

use App\TablaInfo\TipoSolicitudTablaInfo;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CrearTablaTipoSolicitud extends Migration
{
    private const TABLA_TIPO_SOLICITUD = TipoSolicitudTablaInfo::NOMBRE_TABLA;

    public function up()
    {
        Schema::create(self::TABLA_TIPO_SOLICITUD, function (Blueprint $table) {
            $table->id();
            $table->string(TipoSolicitudTablaInfo::NOMBRE_TIPO);
        });
    }
    
    public function down()
    {
        Schema::dropIfExists(self::TABLA_TIPO_SOLICITUD);
    }
}
