<?php

use App\TablaInfo\AdjuntoTablaInfo;
use App\TablaInfo\DerivacionTablaInfo;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CrearTablaAdjuntos extends Migration
{
    private const TABLA_HISTORIAL = AdjuntoTablaInfo::NOMBRE_TABLA;

    public function up()
    {
        Schema::create(self::TABLA_HISTORIAL, function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger(AdjuntoTablaInfo::DERIVACION_ID);
            $table->string(AdjuntoTablaInfo::NOMBRE_ADJUNTO);
            $table->string(AdjuntoTablaInfo::ADJUNTO);
            $table->timestamp(AdjuntoTablaInfo::FECHA_CREADO)->nullable();
            $table->timestamp(AdjuntoTablaInfo::FECHA_ACTUALIZADO)->nullable();

            $table->foreign(AdjuntoTablaInfo::DERIVACION_ID)
                ->references(DerivacionTablaInfo::ID)
                ->on(DerivacionTablaInfo::NOMBRE_TABLA)
                ->onDelete('CASCADE')
                ->onUpdate('CASCADE');
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLA_HISTORIAL);
    }
}
