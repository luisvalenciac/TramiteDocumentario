<?php

use App\TablaInfo\ConfigTramiteTablaInfo;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CrearTablaConfigTramite extends Migration
{
    private const NOMBRE_TABLA = ConfigTramiteTablaInfo::NOMBRE_TABLA;

    public function up()
    {
        Schema::create(self::NOMBRE_TABLA, function (Blueprint $table) {
            $table->unsignedTinyInteger(ConfigTramiteTablaInfo::CONFIG_KEY)->unique();
            $table->unsignedBigInteger(ConfigTramiteTablaInfo::USER_RECIBE_SOLICITUD_ID)->nullable();
            $table->timestamp(ConfigTramiteTablaInfo::FECHA_ACTUALIZADO)->nullable();
            $table->timestamp(ConfigTramiteTablaInfo::FECHA_CREADO)->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::NOMBRE_TABLA);
    }
}
