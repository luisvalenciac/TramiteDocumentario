<?php

use App\TablaInfo\ArchivadorTablaInfo;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CrearTablaArchivadores extends Migration
{
    private const TABLA_ARCHIVADORES = ArchivadorTablaInfo::NOMBRE_TABLA;

    public function up()
    {
        Schema::create(self::TABLA_ARCHIVADORES, function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger(ArchivadorTablaInfo::AREA_ID);
            $table->string(ArchivadorTablaInfo::NOMBRE);
            $table->string(ArchivadorTablaInfo::PERIODO);
            $table->timestamp(ArchivadorTablaInfo::FECHA_CREADO)->nullable();
            $table->timestamp(ArchivadorTablaInfo::FECHA_ACTUALIZADO)->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLA_ARCHIVADORES);
    }
}
