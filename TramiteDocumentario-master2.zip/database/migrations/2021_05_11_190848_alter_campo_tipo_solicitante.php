<?php

use App\TablaInfo\TramiteTablaInfo;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

class AlterCampoTipoSolicitante extends Migration
{

    public function up()
    {
        $tablaTramites = TramiteTablaInfo::NOMBRE_TABLA;
        $columnaSolicitantes = TramiteTablaInfo::TIPO_SOLICITANTE;
        $tipos = array_keys(TramiteTablaInfo::getPrivateTiposSolicitante());
        $strTipos = implode(",", $tipos);

        DB::raw("ALTER TABLE {$tablaTramites} DROP  {$columnaSolicitantes}");
        DB::raw("ALTER TABLE {$tablaTramites} ADD  {$columnaSolicitantes} VALUES ({$strTipos}) DEFAULT  {$tipos[0]}");
    }

    public function down()
    {
        $tablaTramites = TramiteTablaInfo::NOMBRE_TABLA;
        $columnaSolicitantes = TramiteTablaInfo::TIPO_SOLICITANTE;
        $tipos = array_keys(TramiteTablaInfo::getPublicTiposSolicitante());
        $strTipos = implode(",", $tipos);

        DB::raw("ALTER TABLE {$tablaTramites} DROP  {$columnaSolicitantes}");
        DB::raw("ALTER TABLE {$tablaTramites} ADD  {$columnaSolicitantes} VALUES ({$strTipos}) DEFAULT  {$tipos[0]}");

    }
}
