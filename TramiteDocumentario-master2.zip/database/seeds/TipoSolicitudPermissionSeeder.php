<?php

use App\Config\Permisos\VerbosPermisos;
use App\TablaInfo\TipoSolicitudTablaInfo;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class TipoSolicitudPermissionSeeder extends Seeder
{
    public function run()
    {
        $verbos = VerbosPermisos::getVerbos();
        $tablaTipoSolicitud = TipoSolicitudTablaInfo::NOMBRE_TABLA;
        $nombrePermiso = TipoSolicitudTablaInfo::NOMBRE_PARA_PERMISOS;
        foreach ($verbos as $k => $v)
            Permission::create([
                'name' => "{$tablaTipoSolicitud}.{$k}",
                'display_name' => "{$v} {$nombrePermiso}"
            ]);
    }
}
