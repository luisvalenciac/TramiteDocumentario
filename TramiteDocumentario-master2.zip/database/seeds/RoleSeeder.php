<?php

use App\Config\Permisos\DefaultRoles;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RoleSeeder extends Seeder
{
    public function run()
    {
        $nombreTablas = config('permission.table_names');
        $roles = DefaultRoles::getAllRoles();
        foreach ($roles as $k => $v)
            DB::table($nombreTablas['roles'])->updateOrInsert(
                ['name' => $k],
                ['name' => $k, 'display_name' => $v]
            );
    }
}
