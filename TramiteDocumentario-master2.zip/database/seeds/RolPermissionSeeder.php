<?php

use App\Config\Permisos\VerbosPermisos;
use App\TablaInfo\RolTablaInfo;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class RolPermissionSeeder extends Seeder
{
    public function run()
    {
        $verbos = VerbosPermisos::getVerbos();
        $tablaAreas = RolTablaInfo::nombreTabla();
        foreach ($verbos as $k => $v)
            Permission::create([
                'name' => "{$tablaAreas}.{$k}",
                'display_name' => "{$v} {$tablaAreas}"
            ]);
    }
}
