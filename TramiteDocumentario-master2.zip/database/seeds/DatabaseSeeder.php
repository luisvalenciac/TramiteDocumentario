<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        $this->call([
            RoleSeeder::class,
            UserPermissionSeeder::class,
            AreaPermissionSeeder::class,
            RolPermissionSeeder::class,
            DerivacionPermissionSeeder::class,
            TramitePermissionSeeder::class,
            TipoSolicitudPermissionSeeder::class,
            TipoSolicitudSeeder::class,
            ArchivadorPermissionSeeder::class,
            ConfigTramitePermissionSeeder::class,
        ]);
    }
}

