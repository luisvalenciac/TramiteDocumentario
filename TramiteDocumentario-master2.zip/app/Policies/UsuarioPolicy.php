<?php

namespace App\Policies;

use App\Config\Permisos\VerbosPermisos;
use App\Models\Usuario;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Auth\Access\HandlesAuthorization;

class UsuarioPolicy
{
    use HandlesAuthorization;

    public function viewAny(Usuario $loggedUser)
    {
        $listar = UsuarioTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::LISTAR;
        return $loggedUser->can($listar);
    }

    public function view(Usuario $loggedUser, Usuario $usuario)
    {
        $mostrar = UsuarioTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::MOSTRAR;
        return $loggedUser->can($mostrar);
    }

    public function create(Usuario $loggedUser)
    {
        $crear = UsuarioTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::CREAR;
        return $loggedUser->can($crear);
    }

    public function update(Usuario $loggedUser, Usuario $usuario)
    {
        $actualizar = UsuarioTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::ACTUALIZAR;
        return $loggedUser->can($actualizar);
    }

    public function delete(Usuario $loggedUser, Usuario $usuario)
    {
        $eliminar = UsuarioTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::ELIMINAR;
        return $loggedUser->can($eliminar);
    }

    public function verDashboard(Usuario $loggedUser)
    {
        $verDashboard = UsuarioTablaInfo::NOMBRE_TABLA . '.' . UsuarioTablaInfo::PERM_VER_DASHBOARD;
        return $loggedUser->can($verDashboard);
    }
}
