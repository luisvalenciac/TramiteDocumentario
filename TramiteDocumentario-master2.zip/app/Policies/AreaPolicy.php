<?php

namespace App\Policies;

use App\Config\Permisos\VerbosPermisos;
use App\Models\Area;
use App\Models\Usuario;
use App\TablaInfo\AreaTablaInfo;
use Illuminate\Auth\Access\HandlesAuthorization;

class AreaPolicy
{
    use HandlesAuthorization;

    public function viewAny(Usuario $loggedUser)
    {
        $listar = AreaTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::LISTAR;
        return $loggedUser->can($listar);
    }

    public function view(Usuario $loggedUser, Area $area)
    {
        $mostrar = AreaTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::MOSTRAR;
        return $loggedUser->can($mostrar);
    }

    public function create(Usuario $loggedUser)
    {
        $crear = AreaTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::CREAR;
        return $loggedUser->can($crear);
    }

    public function update(Usuario $loggedUser, Area $area)
    {
        $actualizar = AreaTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::ACTUALIZAR;
        return $loggedUser->can($actualizar);
    }

    public function delete(Usuario $loggedUser, Area $area)
    {
        $eliminar = AreaTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::ELIMINAR;
        return $loggedUser->can($eliminar);
    }
}
