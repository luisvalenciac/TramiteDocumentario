<?php

namespace App\Policies;

use App\Config\Permisos\VerbosPermisos;
use App\Models\Archivador;
use App\Models\Usuario;
use App\TablaInfo\ArchivadorTablaInfo;
use Illuminate\Auth\Access\HandlesAuthorization;

class ArchivadorPolicy
{
    use HandlesAuthorization;

    public function viewAny(Usuario $loggedUser)
    {
        $listar = ArchivadorTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::LISTAR;
        return $loggedUser->can($listar);
    }

    public function view(Usuario $loggedUser, Archivador $usuario)
    {
        $mostrar = ArchivadorTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::MOSTRAR;
        return $loggedUser->can($mostrar);
    }

    public function create(Usuario $loggedUser)
    {
        $crear = ArchivadorTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::CREAR;
        return $loggedUser->can($crear);
    }

    public function update(Usuario $loggedUser, Archivador $usuario)
    {
        $actualizar = ArchivadorTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::ACTUALIZAR;
        return $loggedUser->can($actualizar);
    }

    public function delete(Usuario $loggedUser, Archivador $usuario)
    {
        $eliminar = ArchivadorTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::ELIMINAR;
        return $loggedUser->can($eliminar);
    }
}
