<?php

namespace App\Policies;

use App\Config\Permisos\VerbosPermisos;
use App\Models\TipoSolicitud;
use App\Models\Usuario;
use App\TablaInfo\TipoSolicitudTablaInfo;
use Illuminate\Auth\Access\HandlesAuthorization;

class TipoSolicitudPolicy
{
    use HandlesAuthorization;

    public function viewAny(Usuario $loggedUser)
    {
        $listar = TipoSolicitudTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::LISTAR;
        return $loggedUser->can($listar);
    }

    public function view(Usuario $loggedUser, TipoSolicitud $tipoSolicitud)
    {
        $mostrar = TipoSolicitudTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::MOSTRAR;
        return $loggedUser->can($mostrar);
    }

    public function create(Usuario $loggedUser)
    {
        $crear = TipoSolicitudTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::CREAR;
        return $loggedUser->can($crear);
    }

    public function update(Usuario $loggedUser, TipoSolicitud $tipoSolicitud)
    {
        $actualizar = TipoSolicitudTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::ACTUALIZAR;
        return $loggedUser->can($actualizar);
    }

    public function delete(Usuario $loggedUser, TipoSolicitud $tipoSolicitud)
    {
        $eliminar = TipoSolicitudTablaInfo::NOMBRE_TABLA . '.' . VerbosPermisos::ELIMINAR;
        return $loggedUser->can($eliminar);
    }
}
