<?php


namespace App\Strategies;


use App\Contracts\HistorialCambioEstadoRepository;
use App\TablaInfo\DerivacionTablaInfo;

class CardPorAtenderStrategy extends CardStrategy
{
    public function __construct(HistorialCambioEstadoRepository $historialService)
    {
        parent::__construct();
        $this->historialService = $historialService;
        $this->estado = DerivacionTablaInfo::ESTADO_POR_ATENDER;
    }
}
