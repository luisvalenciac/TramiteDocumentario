<?php


namespace App\Strategies;


use App\Contracts\GraficoStrategy;
use Carbon\Carbon;

abstract class CardStrategy extends GraficoStrategy
{
    protected $historialService;
    protected $estado;

    public function obtenerDatos()
    {
        $fechaInicio = Carbon::now();
        $fechaInicio->month(1)->day(1)->hour(0)->minute(0)->second(0);
        $fechaFin = Carbon::now()->addDay();
        return $this->historialService->statsDerivacion($fechaInicio, $fechaFin, $this->estado);
    }
}
