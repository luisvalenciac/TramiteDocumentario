<?php

namespace App\Services;

use App\Contracts\ArchivoRepository;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class ArchivoService implements ArchivoRepository
{
    private const S3_DISK = 's3';
    private const LOCAL_DISK = 'local';

    public function getDisk()
    {
        if (config('app.debug'))
            return self::LOCAL_DISK;
        return self::S3_DISK;
    }

    public function saveArchivosFromDatos(&$datos, $keys, $nombreCarpeta)
    {
        $rutasArchivos = $this->guardarArchivos(Arr::only($datos, $keys), $nombreCarpeta);
        foreach ($rutasArchivos as $key => $ruta)
            $datos[$key] = $rutasArchivos[$key];
    }

    private function guardarArchivos($archivosRequest, $nombreCarpeta)
    {
        $archivosGuardados = [];
        foreach ($archivosRequest as $k => $v)
            $archivosGuardados[$k] = $this->guardarArchivo($nombreCarpeta, $v);
        return $archivosGuardados;
    }

    private function guardarArchivo($nombreCarpeta, $archivo)
    {
        $disk = $this->getDisk();
        if ($this->getDisk() == self::LOCAL_DISK)
            return isset($archivo) ? url(Storage::disk($disk)->putFile($nombreCarpeta, $archivo)) : null;
        return isset($archivo) ? Storage::disk($disk)->putFile($nombreCarpeta, $archivo) : null;
    }

}
