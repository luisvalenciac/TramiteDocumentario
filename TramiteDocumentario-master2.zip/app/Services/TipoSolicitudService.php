<?php

namespace App\Services;

use App\Contracts\TipoSolicitudRepository;
use App\Models\TipoSolicitud;
use App\Models\Tramite;
use App\TablaInfo\TipoSolicitudTablaInfo;

class TipoSolicitudService implements TipoSolicitudRepository
{
    public function tiposSolicitud($cantidad = 15)
    {
        if ($cantidad == '*')
            return TipoSolicitud::all();
        return TipoSolicitud::paginate($cantidad);
    }

    public function crear($datos)
    {
        return TipoSolicitud::create($datos);
    }

    public function actualizar($tipoSolicitud, $datos)
    {
        $tipoSolicitud->update($datos);
        return $tipoSolicitud;
    }

    public function eliminar($tipoSolicitud)
    {
        $tipoSolicitud->delete();
        return $tipoSolicitud;
    }

    public function buscarPorId($id)
    {
        return TipoSolicitud::find($id);
    }

    public function tiposSolicitudFiltrados($request)
    {
        return TipoSolicitud::filter($request->all())->paginate();
    }
}
