<?php

namespace App\Services;

use App\Contracts\DerivacionRepository;
use App\Contracts\AdjuntoRepository;
use App\Contracts\HistorialCambioEstadoRepository;
use App\Models\Derivacion;
use App\TablaInfo\DerivacionTablaInfo;
use Illuminate\Support\Arr;

class DerivacionService implements DerivacionRepository
{
    private $histCambioEstadoService;
    private $adjuntoService;

    public function __construct(HistorialCambioEstadoRepository $histCambioEstadoService,
                                AdjuntoRepository $histAdjuntoService)
    {
        $this->histCambioEstadoService = $histCambioEstadoService;
        $this->adjuntoService = $histAdjuntoService;
    }

    public function crearDerivacion($datos)
    {
        $derivacion = Derivacion::create($datos);
        $this->registrarCambio($derivacion->id, '-', $derivacion->estado);
        return $derivacion;
    }

    public function crearDerivaciones($tramite, $datos)
    {
        foreach ($datos as $derivacion) {
            $derivacion[DerivacionTablaInfo::TRAMITE_ID] = $tramite->id;
            $this->crearDerivacion($derivacion);
        }
    }

    public function derivacionesFiltradas($request, $cantidad = 15)
    {
        $derivaciones = $this->getBaseDerivaciones()->filter($request->all());
        if ($cantidad == '*')
            return $derivaciones;
        return $derivaciones->paginate($cantidad);
    }

    public function actualizarDerivacion($derivacion, $datos)
    {
        $this->registrarCambio($derivacion->id, $derivacion->estado, $datos[DerivacionTablaInfo::ESTADO]);
        $this->adjuntoService->crearAdjuntos($derivacion, Arr::get($datos, DerivacionTablaInfo::ADJUNTOS, []));
        $derivacion->update($datos);
        return $derivacion;
    }

    private function registrarCambio($derivacionId, $estadoInicial, $estadoFinal)
    {
        $this->histCambioEstadoService->registrarCambio($derivacionId, $estadoInicial, $estadoFinal);
    }

    private function getBaseDerivaciones()
    {
        return Derivacion::orderBy(DerivacionTablaInfo::FECHA_CREADO, 'DESC');
    }
}
