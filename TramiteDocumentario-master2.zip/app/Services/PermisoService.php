<?php

namespace App\Services;

use App\Contracts\PermisoRepository;
use Spatie\Permission\Models\Permission;

class PermisoService implements PermisoRepository
{

    public function permisos()
    {
        return Permission::all();
    }
}
