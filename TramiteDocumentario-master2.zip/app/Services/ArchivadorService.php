<?php

namespace App\Services;

use App\Contracts\ArchivadorRepository;
use App\Models\Archivador;
use App\TablaInfo\ArchivadorTablaInfo;

class ArchivadorService implements ArchivadorRepository
{

    public function archivadoresFiltrados($request, $cantidad = 15)
    {
        $archivadores = $this->getBaseArchivadores()->filter($request->all());
        if ($cantidad == '*')
            return $archivadores;
        return $archivadores->paginate($cantidad);
    }

    public function crear($datos)
    {
        return Archivador::create($datos);
    }

    public function actualizar($archivador, $datos)
    {
        $archivador->update($datos);
        return $archivador;
    }

    public function allArchivadores()
    {
        return $this->getBaseArchivadores()->get();
    }

    public function buscar($termino, $cantidad = 15)
    {
        return $this->getBaseArchivadores()
            ->where(ArchivadorTablaInfo::NOMBRE, 'LIKE', "%{$termino}%")
            ->paginate($cantidad);
    }

    public function buscarPor($attr, $value)
    {
        return $this->getBaseArchivadores()->where($attr, '=', $value)->first();
    }

    private function getBaseArchivadores()
    {
        return Archivador::with(['area'])->orderBy(ArchivadorTablaInfo::FECHA_CREADO, 'DESC');
    }
}
