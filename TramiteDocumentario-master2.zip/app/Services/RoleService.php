<?php

namespace App\Services;

use App\Config\Permisos\DefaultRoles;
use App\Contracts\RoleRepository;
use App\TablaInfo\RolTablaInfo;
use Illuminate\Support\Arr;
use Spatie\Permission\Models\Role;

class RoleService implements RoleRepository
{
    public function roles($loggedUser)
    {
        if ($loggedUser->hasRole(DefaultRoles::ADMIN_SISTEMA))
            return Role::all();
        return Role::where(RolTablaInfo::NOMBRE, '!=', DefaultRoles::ADMIN_SISTEMA)->get();
    }

    public function crearRoles($datos)
    {
        $permisos = Arr::pull($datos, RolTablaInfo::PERMISOS);
        $rol = Role::create($datos);
        $rol->syncPermissions($permisos);
        return $rol;
    }

    public function editarRole($rol, $datos)
    {
        $permisos = Arr::pull($datos, RolTablaInfo::PERMISOS);
        $rol->update($datos);
        $rol->syncPermissions($permisos);
        return $rol;
    }

    public function eliminarRole($role)
    {
        $role->delete();
        return $role;
    }
}
