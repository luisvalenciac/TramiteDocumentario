<?php


namespace App\Services;

use App\Contracts\ReniecRepository;
use Illuminate\Support\Facades\Log;
use Peru\Http\ContextClient;
use Peru\Jne\{Dni, DniParser};
use App\Wrappers\PersonaReniec;
use Peru\Reniec\Person;

class ReniecService implements ReniecRepository
{
    private $servicio;

    public function __construct()
    {
        $this->servicio = new Dni(new ContextClient(), new DniParser());
    }

    public function consultarDni(string $dni): PersonaReniec
    {
        $persona = $this->servicio->get($dni);
        if (isset($persona))
            return new PersonaReniec($persona);
        return new PersonaReniec($this->getPersonaAnonima($dni));
    }

    private function getPersonaAnonima($dni)
    {
        $personaAnonima = new Person();
        $personaAnonima->nombres = "NO SE HA ENCONTRADO - INGRESE OTRO DNI";
        $personaAnonima->apellidoPaterno = "NO SE HA ENCONTRADO - INGRESE OTRO DNI";
        $personaAnonima->dni = $dni;
        return $personaAnonima;
    }
}
