<?php

namespace App\Config\Cleaners;

use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;

class DatosCrearTramiteCleaner extends DatosCleaner
{
    public function __construct($datos)
    {
        parent::__construct($datos);
    }

    public function getCleanData()
    {
        $this->setDataFaltante();
        $this->removerDataCondicional();
        return $this->datos;
    }

    private function setDataFaltante()
    {
        $this->datos[TramiteTablaInfo::USER_CREADOR_ID] = Auth::user()->id;
        $this->setDerivacion();
    }

    private function setDerivacion()
    {
        $derivaciones = Arr::get($this->datos, TramiteTablaInfo::DERIVACIONES, []);
        if (count($derivaciones) == 0) {
            $this->datos[TramiteTablaInfo::DERIVACIONES] = [
                0 => [
                    DerivacionTablaInfo::ES_COPIA => false,
                    DerivacionTablaInfo::PROVEIDO => '-',
                    DerivacionTablaInfo::DETALLE => '-',
                    DerivacionTablaInfo::ESTADO => DerivacionTablaInfo::ESTADO_POR_ATENDER,
                ]
            ];
        }
    }

    private function removerDataCondicional()
    {
        $this->removerDataIncluyePago();
    }

    private function removerDataIncluyePago()
    {
        $incluyePago = Arr::get($this->datos, TramiteTablaInfo::INCLUYE_PAGO);
        if (!$incluyePago)
            Arr::pull($this->datos, TramiteTablaInfo::ADJUNTO_PAGO);
    }
}
