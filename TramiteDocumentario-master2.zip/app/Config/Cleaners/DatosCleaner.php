<?php

namespace App\Config\Cleaners;

abstract class DatosCleaner
{
    protected $datos;

    public function __construct($datos)
    {
        $this->datos = $datos;
    }

    abstract public function getCleanData();
}
