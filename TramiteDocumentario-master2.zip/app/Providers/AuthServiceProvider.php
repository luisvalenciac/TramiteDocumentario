<?php

namespace App\Providers;

use App\Config\Permisos\DefaultRoles;
use App\Models\Archivador;
use App\Models\Area;
use App\Models\ConfigTramite;
use App\Models\Derivacion;
use App\Models\TipoSolicitud;
use App\Models\Tramite;
use App\Models\Usuario;
use App\Policies\ArchivadorPolicy;
use App\Policies\AreaPolicy;
use App\Policies\ConfigTramitePolicy;
use App\Policies\DerivacionPolicy;
use App\Policies\RolPolicy;
use App\Policies\TipoSolicitudPolicy;
use App\Policies\TramitePolicy;
use App\Policies\UsuarioPolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;
use Spatie\Permission\Models\Role;

class AuthServiceProvider extends ServiceProvider
{

    protected $policies = [
        Usuario::class => UsuarioPolicy::class,
        Area::class => AreaPolicy::class,
        Role::class => RolPolicy::class,
        Tramite::class => TramitePolicy::class,
        Derivacion::class => DerivacionPolicy::class,
        Archivador::class => ArchivadorPolicy::class,
        ConfigTramite::class => ConfigTramitePolicy::class,
        TipoSolicitud::class => TipoSolicitudPolicy::class,
    ];

    public function boot()
    {
        $this->registerPolicies();

        Gate::before(function ($user, $abilidad) {
            return $user->hasRole(DefaultRoles::ADMIN_SISTEMA) ? true : null;
        });
    }

}
