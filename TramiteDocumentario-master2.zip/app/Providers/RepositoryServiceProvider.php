<?php

namespace App\Providers;

use App\Contracts\ArchivadorRepository;
use App\Contracts\ArchivoRepository;
use App\Contracts\AreaRepository;
use App\Contracts\ConfigTramiteRepository;
use App\Contracts\DerivacionRepository;
use App\Contracts\AdjuntoRepository;
use App\Contracts\HistorialCambioEstadoRepository;
use App\Contracts\PermisoRepository;
use App\Contracts\ReniecRepository;
use App\Contracts\RoleRepository;
use App\Contracts\TipoSolicitudRepository;
use App\Contracts\TramiteRepository;
use App\Contracts\UsuarioRepository;
use App\Services\ArchivadorService;
use App\Services\ArchivoService;
use App\Services\AreaService;
use App\Services\ConfigTramiteService;
use App\Services\DerivacionService;
use App\Services\AdjuntoService;
use App\Services\HistorialCambioEstadoService;
use App\Services\PermisoService;
use App\Services\ReniecService;
use App\Services\RoleService;
use App\Services\TipoSolicitudService;
use App\Services\TramiteService;
use App\Services\UsuarioService;
use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{

    public $bindings = [
        UsuarioRepository::class => UsuarioService::class,
        RoleRepository::class => RoleService::class,
        AreaRepository::class => AreaService::class,
        PermisoRepository::class => PermisoService::class,
        TramiteRepository::class => TramiteService::class,
        TipoSolicitudRepository::class => TipoSolicitudService::class,
        ArchivoRepository::class => ArchivoService::class,
        ReniecRepository::class => ReniecService::class,
        DerivacionRepository::class => DerivacionService::class,
        ArchivadorRepository::class => ArchivadorService::class,
        HistorialCambioEstadoRepository::class => HistorialCambioEstadoService::class,
        ConfigTramiteRepository::class => ConfigTramiteService::class,
        AdjuntoRepository::class => AdjuntoService::class,
    ];
}
