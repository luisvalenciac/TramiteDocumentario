<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Blade;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {

    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $this->translateResourceVerbs();
        $this->bladeDeclareVariable();
    }

    public function translateResourceVerbs()
    {
        Route::resourceVerbs([
            'create' => 'registrar',
            'store' => 'guardar',
            'show' => 'detalle',
            'edit' => 'editar',
            'update' => 'actualizar',
            'delete' => 'eliminar',
        ]);
    }

    private function bladeDeclareVariable()
    {
        Blade::extend(function ($value) {
            return preg_replace('/\{\?(.+)\?\}/', '<?php ${1} ?>', $value);
        });
    }
}
