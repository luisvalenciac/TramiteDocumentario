<?php

namespace App\Utils;

use DateTime;

class DateUtils
{
    static function convertToDate($date, $format)
    {
        try {
            $converted = DateTime::createFromFormat($format, $date);
            return $converted;
        } catch (\Exception $e) {
            return now()->format($format);
        }
    }
}
