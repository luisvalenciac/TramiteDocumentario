<?php

namespace App\Traits\Reglas\Oficina;


trait CrearOficinaReglas
{
    use OficinaRequestReglas;
}
