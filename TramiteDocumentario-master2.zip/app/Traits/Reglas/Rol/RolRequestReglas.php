<?php

namespace App\Traits\Reglas\Rol;

use App\TablaInfo\PermisoTablaInfo;
use App\TablaInfo\RolTablaInfo;

trait RolRequestReglas
{
    private function nombreDescriptivoReglas()
    {
        return ['required', 'regex:/[a-z A-Z]+/'];
    }

    private function permisosReglas()
    {
        $tablaPermisos = PermisoTablaInfo::nombreTabla();
        $nombreClave = PermisoTablaInfo::NOMBRE;
        return ['required', "exists:{$tablaPermisos},{$nombreClave}"];
    }

    private function nombreAtributos()
    {
        return [
            RolTablaInfo::NOMBRE => 'nombre clave',
            RolTablaInfo::NOMBRE_DESCRIPTIVO => 'nombre declarativo',
        ];
    }

    private function mensajesValidacion()
    {
        return [
            RolTablaInfo::NOMBRE . '.' . 'regex' => "El :attribute ingresado no debe tener caracteres especiales."
        ];
    }
}
