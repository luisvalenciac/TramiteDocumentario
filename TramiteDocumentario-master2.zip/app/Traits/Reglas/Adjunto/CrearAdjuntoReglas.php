<?php

namespace App\Traits\Reglas\Adjunto;

use App\TablaInfo\AdjuntoTablaInfo;


trait CrearAdjuntoReglas
{

    public function adjuntoReglas($required = false)
    {
        $req = $required ? 'required' : 'nullable';
        return [$req, 'file', 'max:4096', 'mimes:pdf,docx,doc,PDF,png,PNG,jpeg'];
    }

    public function nombreAdjuntoReglas()
    {
        return ['required', 'string'];
    }

    private function nombreAtributos()
    {
        return [
            AdjuntoTablaInfo::NOMBRE_ADJUNTO => 'nombre de adjunto',
        ];
    }
}
