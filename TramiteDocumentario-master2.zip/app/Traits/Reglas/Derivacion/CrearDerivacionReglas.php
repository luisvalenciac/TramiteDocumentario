<?php

namespace App\Traits\Reglas\Derivacion;

use App\Contracts\UsuarioRepository;
use App\Rules\EsUserActivoRule;
use App\Rules\UserPerteneceAreaRule;
use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Validation\Rule;

trait CrearDerivacionReglas
{
    public function esCopiaReglas()
    {
        return ['required', 'boolean'];
    }

    public function areaDestinoReglas()
    {
        $tablaArea = AreaTablaInfo::NOMBRE_TABLA;
        $idAttr = AreaTablaInfo::ID;
        return ['required', "exists:{$tablaArea},{$idAttr}"];
    }

    public function userDestinoReglas(UsuarioRepository $userService, $idUserValue = null)
    {
        return [
            'required', Rule::exists(UsuarioTablaInfo::NOMBRE_TABLA, UsuarioTablaInfo::ID),
            new EsUserActivoRule($userService, $idUserValue), new UserPerteneceAreaRule($userService, $idUserValue)
        ];
    }

    public function detalleReglas()
    {
        return ['required'];
    }

    public function proveidoReglas()
    {
        return ['required'];
    }

    public function estadoReglas($estados)
    {
        return ['required', Rule::in($estados)];
    }

    public function nombresAtributos()
    {
        return [
            DerivacionTablaInfo::PROVEIDO => 'proveído',
            DerivacionTablaInfo::AREA_DESTINO_ID => 'área de destino',
            DerivacionTablaInfo::USER_DESTINO_ID => 'usuario de destino',
            DerivacionTablaInfo::TRAMITE_ID => 'trámite',
        ];
    }

    public function mensajesValidacion()
    {
        return [
            DerivacionTablaInfo::USER_DESTINO_ID . '.required' => "Se debe tener un responsable",
            DerivacionTablaInfo::USER_DESTINO_ID . '.exists' => "Se debe tener un responsable válido",
        ];
    }
}
