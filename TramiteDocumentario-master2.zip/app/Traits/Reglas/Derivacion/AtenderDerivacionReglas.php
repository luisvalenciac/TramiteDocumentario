<?php

namespace App\Traits\Reglas\Derivacion;

use App\TablaInfo\DerivacionTablaInfo as DerivacionAttr;
use Illuminate\Validation\Rule;

trait AtenderDerivacionReglas
{
    use CrearDerivacionReglas {
        nombresAtributos as crearDerivacionAttrs;
    }

    private function derivacionReglas()
    {
        return ['required', Rule::exists(DerivacionAttr::NOMBRE_TABLA, DerivacionAttr::ID)];
    }

    private function nombresAtributos()
    {
        return [
            DerivacionAttr::ID => 'derivación',
        ];
    }
}
