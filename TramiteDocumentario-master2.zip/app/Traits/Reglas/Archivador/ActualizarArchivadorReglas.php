<?php

namespace App\Traits\Reglas\Archivador;

use App\TablaInfo\ArchivadorTablaInfo;

trait ActualizarArchivadorReglas
{
    use ArchivadorRequestReglas;

    public function idReglas()
    {
        $archivadorTabla = ArchivadorTablaInfo::NOMBRE_TABLA;
        $idAttr = ArchivadorTablaInfo::ID;
        return ['required', "exists:{$archivadorTabla},{$idAttr}"];
    }
}
