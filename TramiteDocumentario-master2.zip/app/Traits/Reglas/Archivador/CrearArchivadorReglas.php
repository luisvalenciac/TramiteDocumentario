<?php

namespace App\Traits\Reglas\Archivador;

trait CrearArchivadorReglas
{
    use ArchivadorRequestReglas;
}
