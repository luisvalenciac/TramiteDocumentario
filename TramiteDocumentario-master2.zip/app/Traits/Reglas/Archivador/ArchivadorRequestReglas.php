<?php

namespace App\Traits\Reglas\Archivador;

use App\TablaInfo\ArchivadorTablaInfo;
use App\TablaInfo\AreaTablaInfo;

trait ArchivadorRequestReglas
{
    private function areaReglas()
    {
        $areaTabla = AreaTablaInfo::NOMBRE_TABLA;
        $idAttr = AreaTablaInfo::ID;
        return ['required', "exists:{$areaTabla},{$idAttr}"];
    }

    private function nombreReglas()
    {
        return ['required'];
    }

    private function periodoReglas()
    {
        return ['required', 'date_format:Y'];
    }

    public function nombresAtributos()
    {
        return [
            ArchivadorTablaInfo::AREA_ID => 'unidad orgánica',
        ];
    }
}
