<?php

namespace App\Traits\Reglas\TipoSolicitud;

use App\TablaInfo\TipoSolicitudTablaInfo;

trait TipoSolicitudRequestReglas
{

    private function nombreTipoReglas()
    {
        return ['required'];
    }

    public function nombresAtributos()
    {
        return [
          TipoSolicitudTablaInfo::NOMBRE_TIPO => 'nombre de solicitud'
        ];
    }
}
