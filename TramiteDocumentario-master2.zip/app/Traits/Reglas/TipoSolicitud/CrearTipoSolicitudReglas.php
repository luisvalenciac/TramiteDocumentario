<?php

namespace App\Traits\Reglas\TipoSolicitud;

trait CrearTipoSolicitudReglas
{
    use TipoSolicitudRequestReglas;
}
