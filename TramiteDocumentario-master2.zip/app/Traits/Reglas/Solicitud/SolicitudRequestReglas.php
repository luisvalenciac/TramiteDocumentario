<?php


namespace App\Traits\Reglas\Solicitud;


class SolicitudRequestReglas
{
    private function nombreAtributos()
    {
        return [

        ];
    }
}
