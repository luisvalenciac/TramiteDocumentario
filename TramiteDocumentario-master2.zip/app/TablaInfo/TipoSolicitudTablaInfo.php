<?php

namespace App\TablaInfo;

class TipoSolicitudTablaInfo
{
    const NOMBRE_PARA_PERMISOS = 'tipos de solicitud';
    const NOMBRE_TABLA = 'tipos_solicitud';
    const ID = 'id';
    const NOMBRE_TIPO = 'nombre_tipo';

    const TIPOS_DEFECTO = [
        'Certificado de estudios',
        'Certificado de inglés',
        'Certificado de prácticas'
    ];
}
