<?php

namespace App\TablaInfo;

class RolTablaInfo
{
    const ID = 'id';
    const NOMBRE = 'name';
    const NOMBRE_DESCRIPTIVO = 'display_name';
    const PERMISOS = 'permisos';

    static function nombreTabla()
    {
        $nombreTablas = config('permission.table_names');
        return $nombreTablas['roles'];
    }
}
