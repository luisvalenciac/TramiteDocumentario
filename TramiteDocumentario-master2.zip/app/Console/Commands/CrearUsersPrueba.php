<?php

namespace App\Console\Commands;

use App\Contracts\AreaRepository;
use App\Contracts\UsuarioRepository;
use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class CrearUsersPrueba extends Command
{
    protected $signature = 'make:test_users {cantidad} {area_id} {rol_name}';
    protected $description = 'Comando para la creación de usuarios de prueba';

    private $userService;
    private $areaService;

    public function __construct(UsuarioRepository $userService, AreaRepository $areaService)
    {
        parent::__construct();
        $this->userService = $userService;
        $this->areaService = $areaService;
    }

    public function handle()
    {
        $fakeNames = ['David', "George", "Lumen", "Carlos", "Miguel", "Maria", "Ana", "Laura"];
        $fakeLastNames = ["Villanueva", "Ruiz", "Alvarez", "Quiroz", "Castañeda", "Vilchez"];
        $cantidad = $email = $this->argument('cantidad');
        $areaId = $email = $this->argument('area_id');
        $rolName = $email = $this->argument('rol_name');

        $area = $this->areaService->buscarPor(AreaTablaInfo::ID, $areaId);

        for ($i = 0; $i < $cantidad; $i++)
            $this->userService->crear([
                UsuarioTablaInfo::NOMBRES => $fakeNames[rand(0, 7)],
                UsuarioTablaInfo::APELLIDOS => $fakeLastNames[rand(0, 5)],
                UsuarioTablaInfo::DNI => rand(10000000, 99999998),
                UsuarioTablaInfo::USERNAME => 'user_' . rand(100, 999),
                UsuarioTablaInfo::PASSWORD => Hash::make('123456789'),
                UsuarioTablaInfo::CARGO => 'algún cargo  de ' . $area->nombre,
                UsuarioTablaInfo::AREA_ID => $area->id,
                UsuarioTablaInfo::ROL => $rolName,
            ]);

        return 0;
    }
}
