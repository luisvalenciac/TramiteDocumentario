<?php

namespace App\Console\Commands;

use App\Config\Permisos\DefaultRoles;
use App\Models\Usuario;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

class CrearAdminSistema extends Command
{
    protected $signature = 'make:admin_user {username}';
    protected $description = 'Comando para la creación de administradores de sistema o asignarle a
    un usuario el rol de administrador del sistema';


    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $username = $this->argument('username');
        $user = Usuario::firstWhere(UsuarioTablaInfo::USERNAME, '=', $username);

        $role = DefaultRoles::ADMIN_SISTEMA;

        if ($user) {
            $this->info("Se ha encontrado un usuario con el username ${username}. Asignado el rol de sistema.");
            $user->assignRole($role);
            $user->esta_activo = true;
            return $user->save();
        }
        $this->info("No se ha encontrado un usuario con el username ,
        creando uno con el username ${username}");

        $this->info("La contraseña por defecto es 1234");

        $user = Usuario::create([
            UsuarioTablaInfo::USERNAME => $username,
            UsuarioTablaInfo::NOMBRES => 'nombre admin',
            UsuarioTablaInfo::APELLIDOS => 'apellido admin',
            UsuarioTablaInfo::CORREO => 'admin_sistema@test.com',
            UsuarioTablaInfo::PASSWORD => Hash::make('1234'),
            UsuarioTablaInfo::DNI => '99999999',
            UsuarioTablaInfo::ESTA_ACTIVO => true,
        ]);
        $user->assignRole($role);
        $this->info("Se ha creado el username: {$username}");
        return 0;
    }
}
