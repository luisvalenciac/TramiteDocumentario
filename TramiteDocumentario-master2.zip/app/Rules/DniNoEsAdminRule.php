<?php

namespace App\Rules;

use App\Config\Permisos\DefaultRoles;
use App\Contracts\UsuarioRepository;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Contracts\Validation\Rule;

class DniNoEsAdminRule implements Rule
{
    private $userService;

    public function __construct(UsuarioRepository $userService)
    {
        $this->userService = $userService;
    }

    public function passes($attribute, $value)
    {
        $user = $this->userService->buscarPor(UsuarioTablaInfo::DNI, $value, '*');
        if ($user)
            return !$user->hasRole(DefaultRoles::ADMIN_SISTEMA);
        return true;
    }

    public function message()
    {
        return 'El DNI ingresado no puede ser registrado, ya que pertenece a un administrador del sistema.';
    }
}
