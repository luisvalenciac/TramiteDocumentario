<?php

namespace App\ModelFilters;

use App\TablaInfo\TipoSolicitudTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\Utils\DateUtils;
use EloquentFilter\ModelFilter;

class TramiteFilter extends ModelFilter
{
    public $relations = [
        'derivaciones' => ['user_destino']
    ];

    public function minFecha($value)
    {
        $fecha = DateUtils::convertToDate($value, 'Y-m-d');
        return $this->whereDate(TramiteTablaInfo::FECHA_EMISION, '>=', $fecha->format('Y-m-d'));
    }

    public function maxFecha($value)
    {
        $fecha = DateUtils::convertToDate($value, 'Y-m-d');
        return $this->whereDate(TramiteTablaInfo::FECHA_EMISION, '<=', $fecha->format('Y-m-d'));
    }

    public function tipoSolicitud($value)
    {
        if ($value == -1 || $value == '-1')
            return $this->whereNull(TramiteTablaInfo::TIPO_SOLICITUD_ID);
        return $this->related('tipoSolicitud', TipoSolicitudTablaInfo::ID, '=', $value);
    }

    public function numeroTramite($value)
    {
        return $this->where(TramiteTablaInfo::NUMERO_TRAMITE, 'LIKE', "%{$value}%");
    }

    public function formaRecepcion($value)
    {
        return $this->where(TramiteTablaInfo::FORMA_RECEPCION, '=', $value);
    }

    public function asunto($value)
    {
        return $this->where(TramiteTablaInfo::ASUNTO, 'LIKE', "%{$value}%");
    }

    public function codigoPago($value)
    {
        return $this->where(TramiteTablaInfo::CODIGO_PAGO, 'LIKE', "%{$value}%");
    }

    public function prioridad($value)
    {
        return $this->where(TramiteTablaInfo::PRIORIDAD, '=', $value);
    }

    public function datoIdentificacion($value)
    {
        return $this->where(TramiteTablaInfo::DATO_IDENTIFICACION, 'LIKE', "%{$value}%");
    }

    public function tipoSolicitante($value)
    {
        return $this->where(TramiteTablaInfo::TIPO_SOLICITANTE, '=', $value);
    }
}
