<?php

namespace App\ModelFilters;

use App\TablaInfo\TipoSolicitudTablaInfo;
use EloquentFilter\ModelFilter;

class TipoSolicitudFilter extends ModelFilter
{
    public $relations = [];

    public function nombreTipo($value)
    {
        return $this->where(TipoSolicitudTablaInfo::NOMBRE_TIPO, 'LIKE', "%{$value}%");
    }
}
