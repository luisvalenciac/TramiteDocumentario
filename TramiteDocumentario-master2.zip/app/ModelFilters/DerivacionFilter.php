<?php

namespace App\ModelFilters;

use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use EloquentFilter\ModelFilter;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

class DerivacionFilter extends ModelFilter
{
    public $relations = [
        'tramite' => ['tipo_solicitud', 'min_fecha', 'max_fecha', 'numero_tramite',
            'forma_recepcion', 'prioridad', 'dato_identificacion', 'tipo_solicitante'],
    ];

    public function userExpediente($value)
    {
        return $this->related('tramite', TramiteTablaInfo::USER_EXPEDIENTE_ID, '=', $value);
    }

    public function userDestino($value)
    {
        return $this->related('userDestino', UsuarioTablaInfo::ID, '=', $value);
    }

    public function estado($estado)
    {
        if ($estado == DerivacionTablaInfo::ESTADO_POR_ATENDER)
            return $this->getFiltradosPorAtender(Auth::user(), $estado);
        return $this->getFiltradosPorUser(Auth::user(), $estado);
    }

    public function archivador($value)
    {
        return $this->where(DerivacionTablaInfo::ARCHIVADOR_ID, '=', $value);
    }

    private function getFiltradosPorUser($loggedUser, $estado)
    {
        $baseQuery = $this->where(DerivacionTablaInfo::ESTADO, '=', $estado);
        if ($loggedUser->esAdminSistema())
            return $baseQuery;
        if ($loggedUser->esResponsableArea())
            return $baseQuery->where(DerivacionTablaInfo::AREA_DESTINO_ID, $loggedUser->area->id);
        return $baseQuery->where(DerivacionTablaInfo::USER_DESTINO_ID, $loggedUser->id);
    }

    private function getFiltradosPorAtender($loggedUser, $estado)
    {
        $baseQuery = $this->where(DerivacionTablaInfo::ESTADO, '=', $estado);
        if ($loggedUser->esAdminSistema())
            return $baseQuery;
        if ($loggedUser->esResponsableArea())
            return $baseQuery
                ->whereNull(DerivacionTablaInfo::USER_DESTINO_ID)
                ->whereNull(DerivacionTablaInfo::AREA_DESTINO_ID)
                ->whereHas('tramite', function (Builder $tramiteQuery) use ($loggedUser) {
                    $tramiteQuery->whereHas('userOrigen', function (Builder $userQuery) use ($loggedUser) {
                        $userQuery->whereHas('area', function (Builder $areaQuery) use ($loggedUser) {
                            $areaQuery->where(AreaTablaInfo::ID, '=', $loggedUser->area->id);
                        });
                    });
                });
        return $baseQuery
            ->whereNull(DerivacionTablaInfo::USER_DESTINO_ID)
            ->whereNull(DerivacionTablaInfo::AREA_DESTINO_ID)
            ->whereHas('tramite', function (Builder $tramiteQuery) use ($loggedUser) {
                $tramiteQuery->whereHas('userOrigen', function (Builder $userQuery) use ($loggedUser) {
                    $userQuery->where(UsuarioTablaInfo::ID, '=', $loggedUser->id);
                });
            });
    }
}
