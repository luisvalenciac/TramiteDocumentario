<?php

namespace App\ModelFilters;

use App\TablaInfo\ArchivadorTablaInfo;
use EloquentFilter\ModelFilter;

class ArchivadorFilter extends ModelFilter
{
    public $relations = [];

    public function nombre($value)
    {
        return $this->where(ArchivadorTablaInfo::NOMBRE, 'LIKE', "%{$value}%");
    }

    public function periodo($value)
    {
        return $this->where(ArchivadorTablaInfo::PERIODO, 'LIKE', "%{$value}%");
    }

    public function area($value)
    {
        return $this->where(ArchivadorTablaInfo::AREA_ID, '=', $value);
    }
}
