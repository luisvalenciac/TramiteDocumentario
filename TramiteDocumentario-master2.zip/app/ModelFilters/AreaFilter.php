<?php

namespace App\ModelFilters;

use App\TablaInfo\AreaTablaInfo;
use EloquentFilter\ModelFilter;

class AreaFilter extends ModelFilter
{
    public $relations = [];

    public function nombre($value)
    {
        return $this->where(AreaTablaInfo::NOMBRE, 'LIKE', "%{$value}%");
    }

    public function abreviatura($value)
    {
        return $this->where(AreaTablaInfo::ABREVIATURA, 'LIKE', "%{$value}%");
    }

    public function siglas($value)
    {
        return $this->where(AreaTablaInfo::SIGLAS, 'LIKE', "%{$value}%");
    }

    public function responsable($value)
    {
        return $this->where(AreaTablaInfo::USER_RESPONSABLE_ID, '=', $value);
    }
}
