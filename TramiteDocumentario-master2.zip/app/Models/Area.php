<?php

namespace App\Models;

use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use EloquentFilter\Filterable;
use Illuminate\Database\Eloquent\Model;

class Area extends Model
{
    use Filterable;

    const CREATED_AT = AreaTablaInfo::FECHA_CREADO;
    const UPDATED_AT = AreaTablaInfo::FECHA_ACTUALIZADO;
    protected $table = AreaTablaInfo::NOMBRE_TABLA;
    protected $fillable = [
        AreaTablaInfo::NOMBRE,
        AreaTablaInfo::ABREVIATURA,
        AreaTablaInfo::SIGLAS,
        AreaTablaInfo::TIPO_AREA,
        AreaTablaInfo::USER_RESPONSABLE_ID,
    ];

    public function responsable()
    {
        return $this->hasOne('App\Models\Usuario', UsuarioTablaInfo::ID,
            AreaTablaInfo::USER_RESPONSABLE_ID);
    }

    public function infoArea()
    {
        return $this->nombre . "-" . $this->abreviatura . "-" . $this->siglas;
    }
}
