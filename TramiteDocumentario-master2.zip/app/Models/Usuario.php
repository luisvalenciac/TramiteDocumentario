<?php

namespace App\Models;

use App\Config\Permisos\DefaultRoles;
use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\HistorialCambioEstadoTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use EloquentFilter\Filterable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Traits\HasRoles;

class Usuario extends Authenticatable
{
    use HasRoles;
    use Notifiable;
    use Filterable;

    const CREATED_AT = UsuarioTablaInfo::FECHA_CREADO;
    const UPDATED_AT = UsuarioTablaInfo::FECHA_ACTUALIZADO;
    protected $table = UsuarioTablaInfo::NOMBRE_TABLA;
    protected $fillable = [
        UsuarioTablaInfo::AREA_ID,
        UsuarioTablaInfo::USERNAME,
        UsuarioTablaInfo::NOMBRES,
        UsuarioTablaInfo::APELLIDOS,
        UsuarioTablaInfo::CORREO,
        UsuarioTablaInfo::TELEFONO,
        UsuarioTablaInfo::PASSWORD,
        UsuarioTablaInfo::DNI,
        UsuarioTablaInfo::CARGO,
        UsuarioTablaInfo::ESTA_ACTIVO,
        UsuarioTablaInfo::DIRECCION
    ];
    protected $hidden = [
        UsuarioTablaInfo::PASSWORD
    ];

    protected $casts = [
        UsuarioTablaInfo::FECHA_CORREO_VERIFICADO => 'datetime',
    ];

    public function area()
    {
        return $this->hasOne('App\Models\Area', AreaTablaInfo::ID,
            UsuarioTablaInfo::AREA_ID);
    }

    public function infoUserYArea()
    {
        return $this->nombresCompletos() . " " . $this->infoDeArea();
    }

    public function esAdminSistema()
    {
        return $this->hasRole(DefaultRoles::ADMIN_SISTEMA);
    }

    public function nombresCompletos()
    {
        return $this->nombres . ' ' . $this->apellidos;
    }

    public function infoDeArea()
    {
        return "Unid. Orga.:" . ($this->area ? ($this->area->nombre . "-" . $this->area->siglas) : "Sin unidad orgánica");
    }

    public function esResponsableArea()
    {
        $responsableArea = $this->area->responsable;
        return $responsableArea && $this->id == $responsableArea->id;
    }
}
