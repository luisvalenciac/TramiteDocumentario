<?php

namespace App\Models;

use App\TablaInfo\ArchivadorTablaInfo;
use App\TablaInfo\AreaTablaInfo;
use EloquentFilter\Filterable;
use Illuminate\Database\Eloquent\Model;

class Archivador extends Model
{
    use Filterable;

    public const CREATED_AT = ArchivadorTablaInfo::FECHA_CREADO;
    public const UPDATED_AT = ArchivadorTablaInfo::FECHA_ACTUALIZADO;
    protected $table = ArchivadorTablaInfo::NOMBRE_TABLA;
    protected $fillable = [
        ArchivadorTablaInfo::AREA_ID,
        ArchivadorTablaInfo::NOMBRE,
        ArchivadorTablaInfo::PERIODO,
    ];

    public function area()
    {
        return $this->belongsTo("App\Models\Area", ArchivadorTablaInfo::AREA_ID,
            AreaTablaInfo::ID);
    }
}
