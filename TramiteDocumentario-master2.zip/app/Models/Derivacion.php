<?php

namespace App\Models;

use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\AdjuntoTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use EloquentFilter\Filterable;
use Illuminate\Database\Eloquent\Model;

class Derivacion extends Model
{
    use Filterable;

    const CREATED_AT = DerivacionTablaInfo::FECHA_CREADO;
    const UPDATED_AT = DerivacionTablaInfo::FECHA_ACTUALIZADO;
    protected $table = DerivacionTablaInfo::NOMBRE_TABLA;

    protected $fillable = [
        DerivacionTablaInfo::TRAMITE_ID,
        DerivacionTablaInfo::ES_COPIA,
        DerivacionTablaInfo::AREA_DESTINO_ID,
        DerivacionTablaInfo::USER_DESTINO_ID,
        DerivacionTablaInfo::DETALLE,
        DerivacionTablaInfo::PROVEIDO,
        DerivacionTablaInfo::ESTADO,
        DerivacionTablaInfo::ARCHIVADOR_ID,
    ];

    public function tramite()
    {
        return $this->belongsTo('App\Models\Tramite', DerivacionTablaInfo::TRAMITE_ID,
            TramiteTablaInfo::ID);
    }

    public function areaDestino()
    {
        return $this->hasOne('App\Models\Area', AreaTablaInfo::ID,
            DerivacionTablaInfo::AREA_DESTINO_ID);
    }

    public function userDestino()
    {
        return $this->hasOne('App\Models\Usuario', UsuarioTablaInfo::ID,
            DerivacionTablaInfo::USER_DESTINO_ID);
    }

    public function adjuntos()
    {
        return $this->hasMany('App\Models\Adjunto', AdjuntoTablaInfo::DERIVACION_ID,
            DerivacionTablaInfo::ID);
    }
}
