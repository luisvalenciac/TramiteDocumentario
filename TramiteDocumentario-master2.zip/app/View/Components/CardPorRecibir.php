<?php

namespace App\View\Components;

use App\Contracts\HistorialCambioEstadoRepository;
use App\Strategies\CardPorRecibirStrategy;
use Illuminate\View\Component;

class CardPorRecibir extends Card
{
    public function __construct(HistorialCambioEstadoRepository $historialService)
    {
        $this->strategy = new CardPorRecibirStrategy($historialService);
        $this->vista = 'components.card-por-recibir';
    }
}
