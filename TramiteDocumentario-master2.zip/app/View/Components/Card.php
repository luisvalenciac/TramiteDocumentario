<?php

namespace App\View\Components;

use Illuminate\View\Component;

abstract class Card extends Component
{
    protected $strategy;
    protected $vista;

    public function render()
    {
        $datos = $this->strategy->obtenerDatos();
        return view($this->vista, ['datos' => $datos]);
    }
}
