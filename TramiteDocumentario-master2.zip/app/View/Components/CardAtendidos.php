<?php

namespace App\View\Components;

use App\Contracts\HistorialCambioEstadoRepository;
use App\Strategies\CardAtendidosStrategy;
use Illuminate\View\Component;

class CardAtendidos extends Card
{
    public function __construct(HistorialCambioEstadoRepository $historialService)
    {
        $this->strategy = new CardAtendidosStrategy($historialService);
        $this->vista = 'components.card-atendidos';
    }
}
