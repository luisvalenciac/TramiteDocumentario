<?php

namespace App\Http\Requests\Archivador;

use App\TablaInfo\ArchivadorTablaInfo;
use App\Traits\Reglas\Archivador\CrearArchivadorReglas;
use Illuminate\Foundation\Http\FormRequest;

class CrearArchivadorRequest extends FormRequest
{
    use CrearArchivadorReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            ArchivadorTablaInfo::AREA_ID => $this->areaReglas(),
            ArchivadorTablaInfo::NOMBRE => $this->nombreReglas(),
            ArchivadorTablaInfo::PERIODO => $this->periodoReglas(),
        ];
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }
}
