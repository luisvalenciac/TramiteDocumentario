<?php

namespace App\Http\Requests\Archivador;

use App\TablaInfo\ArchivadorTablaInfo;
use App\Traits\Reglas\Archivador\ActualizarArchivadorReglas;
use Illuminate\Foundation\Http\FormRequest;

class ActualizarArchivadorRequest extends FormRequest
{
    use ActualizarArchivadorReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            ArchivadorTablaInfo::ID => $this->idReglas(),
            ArchivadorTablaInfo::AREA_ID => $this->areaReglas(),
            ArchivadorTablaInfo::NOMBRE => $this->nombreReglas(),
            ArchivadorTablaInfo::PERIODO => $this->periodoReglas(),
        ];
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }
}
