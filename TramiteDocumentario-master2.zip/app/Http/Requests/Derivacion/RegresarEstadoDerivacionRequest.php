<?php

namespace App\Http\Requests\Derivacion;

use App\TablaInfo\DerivacionTablaInfo;
use App\Traits\Reglas\Derivacion\AtenderDerivacionReglas;
use Illuminate\Foundation\Http\FormRequest;

class RegresarEstadoDerivacionRequest extends FormRequest
{
    use AtenderDerivacionReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            DerivacionTablaInfo::ID => $this->derivacionReglas(),
            DerivacionTablaInfo::DETALLE => $this->detalleReglas(),
            DerivacionTablaInfo::ESTADO =>
                $this->estadoReglas([DerivacionTablaInfo::ESTADO_ATENDIDO, DerivacionTablaInfo::ESTADO_POR_RECIBIR]),
        ];
    }
}
