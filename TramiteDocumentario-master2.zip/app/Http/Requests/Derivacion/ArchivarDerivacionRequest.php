<?php

namespace App\Http\Requests\Derivacion;

use App\TablaInfo\DerivacionTablaInfo;
use App\Traits\Reglas\Derivacion\AtenderDerivacionReglas;
use App\Traits\Reglas\Derivacion\ArchivarDerivacionReglas;
use Illuminate\Foundation\Http\FormRequest;

class ArchivarDerivacionRequest extends FormRequest
{
    use AtenderDerivacionReglas;
    use ArchivarDerivacionReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            DerivacionTablaInfo::ID => $this->derivacionReglas(),
            DerivacionTablaInfo::ARCHIVADOR_ID => $this->idArchivadorReglas(),
            DerivacionTablaInfo::DETALLE => $this->detalleReglas(),
            DerivacionTablaInfo::ESTADO => $this->estadoReglas([DerivacionTablaInfo::ESTADO_ARCHIVADO]),
        ];
    }

    public function attributes()
    {
        return [
            DerivacionTablaInfo::ARCHIVADOR_ID => 'archivador',
            DerivacionTablaInfo::ID => 'derivación'
        ];
    }
}
