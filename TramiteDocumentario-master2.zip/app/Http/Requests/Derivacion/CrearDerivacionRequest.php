<?php

namespace App\Http\Requests\Derivacion;

use App\Contracts\UsuarioRepository;
use App\TablaInfo\DerivacionTablaInfo;
use App\Traits\Reglas\Derivacion\CrearDerivacionReglas;
use Illuminate\Foundation\Http\FormRequest;

class CrearDerivacionRequest extends FormRequest
{
    use CrearDerivacionReglas;

    public function authorize()
    {
        return true;
    }

    public function rules(UsuarioRepository $userService)
    {
        return [
            DerivacionTablaInfo::ES_COPIA => $this->esCopiaReglas(),
            DerivacionTablaInfo::AREA_DESTINO_ID => $this->areaDestinoReglas(),
            DerivacionTablaInfo::USER_DESTINO_ID => $this->userDestinoReglas($userService),
            DerivacionTablaInfo::DETALLE => $this->detalleReglas(),
            DerivacionTablaInfo::PROVEIDO => $this->proveidoReglas(),
            DerivacionTablaInfo::ESTADO => $this->estadoReglas([DerivacionTablaInfo::ESTADO_POR_RECIBIR]),
        ];
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }

    public function messages()
    {
        return $this->mensajesValidacion();
    }
}
