<?php

namespace App\Http\Requests\Derivacion;

use App\Contracts\UsuarioRepository;
use App\TablaInfo\DerivacionTablaInfo;
use App\Traits\Reglas\Derivacion\DerivarReglas;
use Illuminate\Foundation\Http\FormRequest;

class DerivarRequest extends FormRequest
{
    use DerivarReglas;

    public function authorize()
    {
        return true;
    }

    public function rules(UsuarioRepository $userService)
    {
        return [
            DerivacionTablaInfo::ID => $this->derivacionReglas(),
            DerivacionTablaInfo::DETALLE => $this->detalleReglas(),
            DerivacionTablaInfo::AREA_DESTINO_ID => $this->areaDestinoReglas(),
            DerivacionTablaInfo::USER_DESTINO_ID => $this->userDestinoReglas($userService),
            DerivacionTablaInfo::PROVEIDO => $this->proveidoReglas(),
        ];
    }

    public function validated($estado = null)
    {
        $datos = parent::validated();
        if ($estado) {
            if ($estado == DerivacionTablaInfo::ESTADO_POR_ATENDER)
                $datos[DerivacionTablaInfo::ESTADO] = DerivacionTablaInfo::ESTADO_POR_RECIBIR;
            else
                $datos[DerivacionTablaInfo::ESTADO] = $estado;
        }
        return $datos;
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }

    public function messages()
    {
        return $this->mensajesValidacion();
    }
}
