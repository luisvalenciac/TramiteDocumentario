<?php

namespace App\Http\Requests\ConfigTramite;

use App\Contracts\UsuarioRepository;
use App\TablaInfo\ConfigTramiteTablaInfo;
use App\Traits\Reglas\ConfigTramite\ActualizarConfigTramiteReglas;
use Illuminate\Foundation\Http\FormRequest;

class ActualizarConfigTramiteRequest extends FormRequest
{
    use ActualizarConfigTramiteReglas;

    public function authorize()
    {
        return true;
    }

    public function rules(UsuarioRepository $userService)
    {
        return [
            ConfigTramiteTablaInfo::USER_RECIBE_SOLICITUD_ID => $this->usuarioSolicitudReglas($userService),
        ];
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }
}
