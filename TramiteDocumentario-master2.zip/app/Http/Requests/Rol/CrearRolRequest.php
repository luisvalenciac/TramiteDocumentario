<?php

namespace App\Http\Requests\Rol;

use App\TablaInfo\RolTablaInfo;
use App\Traits\Reglas\Rol\CrearRolReglas;
use Illuminate\Foundation\Http\FormRequest;

class CrearRolRequest extends FormRequest
{
    use CrearRolReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            RolTablaInfo::NOMBRE => $this->nombreReglas(),
            RolTablaInfo::NOMBRE_DESCRIPTIVO => $this->nombreDescriptivoReglas(),
            RolTablaInfo::PERMISOS => $this->permisosReglas(),
        ];
    }

    public function attributes()
    {
        return $this->nombreAtributos();
    }

    public function messages()
    {
        return $this->mensajesValidacion();
    }
}
