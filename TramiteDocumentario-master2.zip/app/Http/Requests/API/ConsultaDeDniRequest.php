<?php

namespace App\Http\Requests\API;

use Illuminate\Foundation\Http\FormRequest;
use App\TablaInfo\UsuarioTablaInfo as UserAttr;

class ConsultaDeDniRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            UserAttr::DNI  => ['required','digits:8']
        ];
    }

    public function getDni() {
        return $this->input(UserAttr::DNI);
    }
}
