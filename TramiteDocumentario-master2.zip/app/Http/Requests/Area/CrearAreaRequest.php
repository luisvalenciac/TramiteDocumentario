<?php

namespace App\Http\Requests\Area;

use App\Contracts\UsuarioRepository;
use App\Traits\Reglas\Area\CrearAreaReglas;
use Illuminate\Foundation\Http\FormRequest;
use App\TablaInfo\AreaTablaInfo as AreaAttr;

class CrearAreaRequest extends FormRequest
{
    use CrearAreaReglas;

    public function authorize()
    {
        return true;
    }

    public function rules(UsuarioRepository $userService)
    {
        return [
            AreaAttr::NOMBRE => $this->nombreReglas(),
            AreaAttr::ABREVIATURA => $this->nombreReglas(),
            AreaAttr::SIGLAS => $this->siglasReglas(),
            AreaAttr::TIPO_AREA => $this->tipoAreaReglas(),
            AreaAttr::USER_RESPONSABLE_ID => $this->userResponsableReglas($userService),
        ];
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }
}
