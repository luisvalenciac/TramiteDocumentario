<?php

namespace App\Http\Requests\Solicitud;

use App\Config\Cleaners\DatosCrearSolicitudCleaner;
use App\Contracts\ConfigTramiteRepository;
use App\Contracts\TipoSolicitudRepository;
use App\Contracts\TramiteRepository;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\Traits\Reglas\Derivacion\CrearDerivacionReglas;
use App\Traits\Reglas\Tramite\CrearTramiteReglas;
use Illuminate\Foundation\Http\FormRequest;

class CrearSolicitudRequest extends FormRequest
{
    use CrearTramiteReglas;
    use CrearDerivacionReglas;

    private $tiposSolicitud;
    private $tramites;
    private $configTramiteService;

    public function authorize()
    {
        return true;
    }

    public function rules(TipoSolicitudRepository $tiposSolicitudService, TramiteRepository $tramiteService,
                          ConfigTramiteRepository $configTramiteService)
    {
        $this->asignarServices($tiposSolicitudService, $tramiteService, $configTramiteService);
        return [
            TramiteTablaInfo::TIPO_SOLICITUD_ID => $this->tipoSolicitudReglas(),
            TramiteTablaInfo::OTRO_TIPO_SOLICITUD => $this->otroTipoSolicitudReglas($this->tipoSolicitudValue()),
            TramiteTablaInfo::INCLUYE_PAGO => $this->incluyePagoReglas(),
            TramiteTablaInfo::CODIGO_PAGO => $this->codigoPagoReglas($this->incluyePagoValue()),
            TramiteTablaInfo::ADJUNTO_PAGO => $this->adjuntoPagoReglas($this->incluyePagoValue()),
            TramiteTablaInfo::TIPO_SOLICITANTE => $this->tipoSolicitantePublicReglas(),
            TramiteTablaInfo::DATO_IDENTIFICACION => $this->datoIdentificacionReglas($this->tipoSolicitanteValue()),
            TramiteTablaInfo::ARCHIVO_TRAMITE => $this->archivoTramiteReglas(),
            DerivacionTablaInfo::DETALLE => $this->detalleReglas(),
        ];
    }

    public function attributes()
    {
        return $this->nombreAtributos();
    }

    public function validated()
    {
        return (new DatosCrearSolicitudCleaner(
            parent::validated(), $this->tiposSolicitud, $this->tramites, $this->configTramiteService
        ))->getCleanData();
    }

    private function incluyePagoValue()
    {
        return $this->input(TramiteTablaInfo::INCLUYE_PAGO, 0);
    }

    private function tipoSolicitanteValue()
    {
        return $this->input(TramiteTablaInfo::TIPO_SOLICITANTE);
    }

    private function tipoSolicitudValue()
    {
        return $this->input(TramiteTablaInfo::TIPO_SOLICITUD_ID);
    }

    private function asignarServices($tiposSolicitudService, $tramiteService, $configTramiteService)
    {
        $this->tiposSolicitud = $tiposSolicitudService;
        $this->tramites = $tramiteService;
        $this->configTramiteService = $configTramiteService;
    }
}
