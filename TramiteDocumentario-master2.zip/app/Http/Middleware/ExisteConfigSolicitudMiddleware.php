<?php

namespace App\Http\Middleware;

use App\Contracts\ConfigTramiteRepository;
use Closure;

class ExisteConfigSolicitudMiddleware
{
    private $configTramiteService;

    public function __construct(ConfigTramiteRepository $configTramiteService)
    {
        $this->configTramiteService = $configTramiteService;
    }

    public function handle($request, Closure $next)
    {
        if (!$this->configTramiteService->existeUserConfigTramite())
            return redirect()->route('procesos.solicitudes.avisoConfigTramite');
        return $next($request);
    }
}
