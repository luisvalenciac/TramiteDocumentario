<?php

namespace App\Http\Controllers\Configuracion;

use App\Contracts\ConfigTramiteRepository;
use App\Http\Controllers\Controller;
use App\Http\Requests\ConfigTramite\ActualizarConfigTramiteRequest;

class ConfigTramiteController extends Controller
{
    private $configTramiteService;

    public function __construct(ConfigTramiteRepository $configTramiteService)
    {
        $this->middleware(['auth']);
        $this->configTramiteService = $configTramiteService;
    }

    public function vistaConfigTramite()
    {
        $configTramite = $this->configTramiteService->getConfigTramite();
        return view('configuracion.tramites.configTramite', ["configTramite" => $configTramite]);
    }

    public function actualizarConfigTramite(ActualizarConfigTramiteRequest $request)
    {
        $configTramite = $this->configTramiteService->actualizarConfig($request->validated());
        return view('configuracion.tramites.configTramite', ["configTramite" => $configTramite]);
    }
}
