<?php

namespace App\Http\Controllers\Administracion;

use App\Contracts\PermisoRepository;
use App\Contracts\RoleRepository;
use App\Http\Controllers\Controller;
use App\Http\Requests\Rol\ActualizarRolRequest;
use App\Http\Requests\Rol\CrearRolRequest;
use App\Wrappers\Vistas\DatosActualizarRol;
use Illuminate\Support\Facades\Auth;
use Spatie\Permission\Models\Role;

class RolController extends Controller
{
    private $roles;
    private $permisos;

    public function __construct(RoleRepository $roles, PermisoRepository $permisos)
    {
        $this->middleware(['auth']);
        $this->authorizeResource(Role::class);
        $this->roles = $roles;
        $this->permisos = $permisos;
    }

    public function index()
    {
        $roles = $this->roles->roles(Auth::user());
        return view('administracion.roles.listarRoles', ['roles' => $roles]);
    }

    public function create()
    {
        $permisos = $this->permisos->permisos();
        return view('administracion.roles.crearRol', ['permisos' => $permisos]);
    }

    public function store(CrearRolRequest $request)
    {
        $rol = $this->roles->crearRoles($request->validated());
        return redirect()->route('administracion.roles.index');
    }

    public function show(Role $role)
    {
        return view('administracion.roles.detalleRol', ['rol' => $role]);
    }

    public function edit(Role $role)
    {
        $datosVista = new DatosActualizarRol($role, $this->permisos);
        return view('administracion.roles.editarRol', ['datos' => $datosVista]);
    }

    public function update(ActualizarRolRequest $request, Role $role)
    {
        $this->roles->editarRole($role, $request->validated());
        return redirect()->route('administracion.roles.index');
    }

    public function destroy(Role $role)
    {
        $this->roles->eliminarRole($role);
        return redirect()->route('administracion.roles.index');
    }
}
