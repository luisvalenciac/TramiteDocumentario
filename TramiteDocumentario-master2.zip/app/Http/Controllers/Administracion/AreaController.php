<?php

namespace App\Http\Controllers\Administracion;

use App\Contracts\UsuarioRepository;
use App\Http\Controllers\Controller;
use App\Models\Area;
use App\Contracts\AreaRepository;
use App\Http\Requests\Area\ActualizarAreaRequest;
use App\Http\Requests\Area\CrearAreaRequest;
use App\TablaInfo\AreaTablaInfo;
use App\Wrappers\Vistas\DatosEditarArea;
use App\Wrappers\Vistas\DatosListarAreas;
use Illuminate\Http\Request;

class AreaController extends Controller
{
    private $areaService;
    private $usuarioService;

    public function __construct(AreaRepository $areas, UsuarioRepository $usuarioService)
    {
        $this->middleware('auth');
        $this->authorizeResource(Area::class);
        $this->areaService = $areas;
        $this->usuarioService = $usuarioService;
    }

    public function index(Request $request)
    {
        $datosVista = new DatosListarAreas($this->areaService, $this->usuarioService, $request);
        return view('administracion.areas.listarAreas', ['datos' => $datosVista]);
    }

    public function create()
    {
        return view('administracion.areas.crearArea', ["tiposArea" => AreaTablaInfo::tiposAreaDict()]);
    }

    public function store(CrearAreaRequest $request)
    {
        $this->areaService->crear($request->validated());
        return redirect()->route('administracion.areas.index');
    }

    public function show(Area $area)
    {
        return view('administracion.areas.detalleArea', ['area' => $area,
            'tipos' => AreaTablaInfo::tiposAreaDict()]);
    }

    public function edit(Area $area)
    {
        $datosVista = new DatosEditarArea($area, $this->usuarioService);
        return view('administracion.areas.editarArea', ['datos' => $datosVista]);
    }

    public function update(ActualizarAreaRequest $request, Area $area)
    {
        $this->areaService->actualizar($area, $request->validated());
        return redirect()->route('administracion.areas.index');
    }

    public function destroy(Area $area)
    {
        $this->areaService->eliminar($area);
        return redirect()->route('administracion.areas.index');
    }
}
