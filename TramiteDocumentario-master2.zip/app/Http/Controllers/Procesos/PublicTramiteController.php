<?php

namespace App\Http\Controllers\Procesos;

use App\Contracts\AreaRepository;
use App\Contracts\TipoSolicitudRepository;
use App\Contracts\TramiteRepository;
use App\Contracts\UsuarioRepository;
use App\Http\Controllers\Controller;
use App\Http\Requests\Solicitud\CrearSolicitudRequest;
use App\Models\Tramite;
use App\TablaInfo\TramiteTablaInfo;
use App\Wrappers\Vistas\DatosCrearSolicitud;
use App\Wrappers\Vistas\DatosCrearTramite;
use App\Wrappers\Vistas\DatosDetalleTramite;
use Illuminate\Http\Request;


class PublicTramiteController extends Controller
{
    private $tiposSolicitud;
    private $tramites;

    public function __construct(TipoSolicitudRepository $tiposSolicitud, TramiteRepository $tramite)
    {
        $this->tiposSolicitud = $tiposSolicitud;
        $this->tramites = $tramite;
    }

    public function crearSolicitud()
    {
        $datosVista = new DatosCrearSolicitud($this->tiposSolicitud);
        return view('procesos.solicitudes.crearSolicitud', ["datos" => $datosVista]);
    }

    public function guardarSolicitud(CrearSolicitudRequest $request)
    {
        $datos = $request->validated();
        $tramite = $this->tramites->crearTramite($datos);
        $request->session()->flash('NUMERO_TRAMITE', $tramite->numero_tramite);
        return redirect()->route('procesos.solicitudes.crear');
    }

    public function consultarSolicitud(Request $request)
    {
        $numero_tramite = $request->get('numero_tramite');
        if ($numero_tramite != null) {
            $tramite = $this->tramites->buscarPor(TramiteTablaInfo::NUMERO_TRAMITE, $numero_tramite);
            if ($tramite != null) {
                $datosVista = new DatosDetalleTramite($tramite);
                return view('procesos.solicitudes.detalleSolicitud', ['datos' => $datosVista]);
            }
            $request->session()->flash('TRAMITE_NO_EXISTE', '');
            return view('procesos.solicitudes.consultarSolicitud');
        }
        return view('procesos.solicitudes.consultarSolicitud');
    }

    public function mensajeConfigTramite()
    {
        return view('procesos.solicitudes.mensajeSolicitud');
    }
}
