<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Usuario;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    use AuthenticatesUsers {
        attemptLogin as protected parentAttemptLogin;
    }

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    protected function redirectTo()
    {
        return redirect()->route('login.vistaLogin');
    }

    public function authenticated(Request $request, $user)
    {
        $verDashboard = UsuarioTablaInfo::NOMBRE_TABLA . '.' . UsuarioTablaInfo::PERM_VER_DASHBOARD;
        if ($user->can($verDashboard))
            return redirect()->route('administracion.dashboard');
        return redirect()->route('procesos.tramites.crear');
    }

    protected function attemptLogin(Request $request)
    {
        $user = Usuario::where($this->username(), $request->input($this->username()))->first();
        if ($user && $user->esta_activo)
            return $this->parentAttemptLogin($request);
        return false;
    }

    public function username()
    {
        return UsuarioTablaInfo::USERNAME;
    }

    public function loggedOut()
    {
        return redirect()->route('login.vistaLogin');
    }
}
