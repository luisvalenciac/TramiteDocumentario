<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\Derivacion\CrearDerivacionRequest;

class APIDerivacionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function validarDerivacion(CrearDerivacionRequest $request)
    {
        return response()->json($request->validated());
    }
}
