<?php

namespace App\Http\Controllers\API;

use App\Contracts\UsuarioRepository;
use App\Http\Controllers\Controller;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Http\Request;

class APIUsuarioController extends Controller
{
    private $userService;

    public function __construct(UsuarioRepository $users)
    {
        $this->middleware('auth');
        $this->userService = $users;
    }

    public function buscarUsuario(Request $request)
    {
        $users = $this->userService->buscarPorTermino($request);
        return response()->json($users);
    }
}
