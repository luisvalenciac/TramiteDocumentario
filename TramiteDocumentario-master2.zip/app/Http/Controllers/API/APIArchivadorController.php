<?php

namespace App\Http\Controllers\API;

use App\Contracts\ArchivadorRepository;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class APIArchivadorController extends Controller
{
    private $archivadorService;

    public function __construct(ArchivadorRepository $archivadorService)
    {
        $this->middleware(['auth']);
        $this->archivadorService = $archivadorService;
    }

    public function buscar(Request $request)
    {
        $termino = $request->query('q', '');
        $archivadores = $this->archivadorService->buscar($termino);
        return response()->json($archivadores);
    }
}
