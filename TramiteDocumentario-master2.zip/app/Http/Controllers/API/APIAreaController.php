<?php

namespace App\Http\Controllers\API;

use App\Contracts\AreaRepository;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class APIAreaController extends Controller
{
    private $areas;

    public function __construct(AreaRepository $areas)
    {
        $this->middleware('auth');
        $this->areas = $areas;
    }

    public function buscarAreas(Request $request)
    {
        $termino = $request->query('q', '');
        $areas = $this->areas->buscar($termino);
        return response()->json($areas);
    }
}
