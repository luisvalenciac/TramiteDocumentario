<?php


namespace App\Exports;


use App\Wrappers\Vistas\DatosTablaExportarDerivaciones;

interface ArchivoExport
{
    public function download(DatosTablaExportarDerivaciones $datos);
}
