<?php

namespace App\Contracts;

use App\Models\Adjunto;

interface AdjuntoRepository
{
    public function eliminar(Adjunto $adjunto);

    public function crearAdjuntos($derivacion, $datos);
}
