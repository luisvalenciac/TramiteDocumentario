<?php

namespace App\Contracts;

interface DerivacionRepository
{
    public function crearDerivacion($datos);

    public function crearDerivaciones($tramite, $datos);

    public function derivacionesFiltradas($request, $cantidad = 15);

    public function actualizarDerivacion($derivacion, $datos);
}
