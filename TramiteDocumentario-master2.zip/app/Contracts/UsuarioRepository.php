<?php

namespace App\Contracts;

interface UsuarioRepository
{
    public function usersFiltrados($request, $cantidad = 15);

    public function crear($datos);

    public function asignarRol($user, $rol);

    public function actualizar($user, $datos);

    public function deshabilitar($user);

    public function buscarPor($attr, $valor, $buscarEnTodos = '*');

    public function getUsersPorRol();

    public function count();

    public function buscarPorTermino($request, $cantidad = 15);
}
