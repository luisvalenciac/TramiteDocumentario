<?php

namespace App\Contracts;

interface PermisoRepository
{
    public function permisos();

}
