<?php

namespace App\Contracts;

interface TipoSolicitudRepository
{
    public function tiposSolicitud($cantidad = 15);

    public function tiposSolicitudFiltrados($request);

    public function crear($datos);

    public function actualizar($tipoSolicitud, $datos);

    public function eliminar($tipoSolicitud);

    public function buscarPorId($id);
}
