<?php

namespace App\Wrappers\Vistas;

use App\Contracts\ArchivadorRepository;
use App\Contracts\AreaRepository;
use App\TablaInfo\AreaTablaInfo;

class DatosListarArchivadores
{
    public $archivadores;
    private $areaService;

    public function __construct(ArchivadorRepository $archivadorService, AreaRepository $areaService, $request)
    {
        $this->archivadores = $archivadorService->archivadoresFiltrados($request);
        $this->areaService = $areaService;
    }

    public function getAreaPorId($areaId)
    {
        return $areaId == 0 ? null : $this->areaService->buscarPor(AreaTablaInfo::ID, $areaId);
    }
}
