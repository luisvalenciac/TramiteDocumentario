<?php

namespace App\Wrappers\Vistas;

use App\Contracts\AreaRepository;
use App\Contracts\UsuarioRepository;

class DatosListarUsuarios
{
    public $usuarios;
    public $areas;

    public function __construct(UsuarioRepository $userService, AreaRepository $areaService, $request)
    {
        $this->usuarios = $userService->usersFiltrados($request);
        $this->areas = $areaService->areas()->get();
    }
}
