<?php

namespace App\Wrappers\Vistas;

use App\Contracts\ArchivadorRepository;
use App\Contracts\DerivacionRepository;
use App\Contracts\TipoSolicitudRepository;
use App\Contracts\UsuarioRepository;
use App\TablaInfo\ArchivadorTablaInfo;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Http\Request;

class DatosListarDerivaciones
{
    public $derivaciones;
    public $prioridadDict;
    public $estadosDerivacionDict;
    public $tiposSolicitud;
    public $formasRecepcion;
    public $tiposSolicitante;
    private $archivadorService;
    private $userService;

    public function __construct(DerivacionRepository $derivacionService, UsuarioRepository $userService,
                                TipoSolicitudRepository $tipoSolicitudService, ArchivadorRepository $archivadorService,
                                Request $request)
    {
        $this->derivaciones = $derivacionService->derivacionesFiltradas($request);
        $this->prioridadDict = TramiteTablaInfo::prioridadesDict();
        $this->estadosDerivacionDict = DerivacionTablaInfo::estadoDerivacionDict();
        $this->tiposSolicitud = $tipoSolicitudService->tiposSolicitud('*');
        $this->formasRecepcion = TramiteTablaInfo::formasRecepcionDict();
        $this->tiposSolicitante = TramiteTablaInfo::getPrivateTiposSolicitante();
        $this->userService = $userService;
        $this->archivadorService = $archivadorService;
    }

    public function getUserPorId($id)
    {
        return $id == 0 ? null : $this->userService->buscarPor(UsuarioTablaInfo::ID, $id);
    }

    public function getArchivador($id)
    {
        return $id == 0 ? null : $this->archivadorService->buscarPor(ArchivadorTablaInfo::ID, $id);
    }
}
