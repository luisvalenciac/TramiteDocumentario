<?php

namespace App\Wrappers\Vistas;

use App\Contracts\AreaRepository;
use App\Contracts\TipoSolicitudRepository;
use App\Contracts\TramiteRepository;
use App\TablaInfo\TramiteTablaInfo;
use Illuminate\Http\Request;

class DatosCrearTramite
{
    public $areas;
    public $tiposSolicitud;
    public $prioridadDict;
    public $formasRecepcion;
    public $tiposSolicitante;
    private $request;
    private $tramiteService;

    public function __construct(AreaRepository $areaService, TipoSolicitudRepository $tiposSolicitudService,
                                TramiteRepository $tramiteService, Request $request)
    {
        $this->areas = $areaService->areas()->get();
        $this->prioridadDict = TramiteTablaInfo::prioridadesDict();
        $this->tiposSolicitud = $tiposSolicitudService->tiposSolicitud('*');
        $this->formasRecepcion = TramiteTablaInfo::formasRecepcionDict();
        $this->tiposSolicitante = TramiteTablaInfo::getPrivateTiposSolicitante();
        $this->request = $request;
        $this->tramiteService = $tramiteService;
    }

    public function numeroReferenciaTramite()
    {
        return $this->tramiteService->generarNumeroTramite();
    }

    public function idPersonal()
    {
        return $this->request->user()->id;
    }

    public function documentoIdentidadPersonal()
    {
        return $this->request->user()->dni;
    }

    public function siglasUnidadOrganicaPersonal()
    {
        $area = $this->request->user()->area;
        return $area ? $area->siglas : "SIN UNIDAD";
    }

    public function siglasUnidadOrganicaResponsable()
    {
        $area = $this->request->user()->area;
        if ($area)
            return $area->responsable ? $area->responsable->area->siglas : "SIN RESPONSABLE";
        return "SIN UNIDAD";
    }

    public function unidadOrganicaPersonal()
    {
        $area = $this->request->user()->area;
        return $area ? $area->nombre : "SIN UNIDAD";
    }

    public function firmaPersonal()
    {
        return $this->request->user()->nombres . ' ' . $this->request->user()->apellidos;
    }

    public function cargoPersonal()
    {
        $user = $this->request->user();
        return $user->cargo ? $user->cargo : "SIN CARGO";
    }

    public function idResponsable()
    {
        $area = $this->request->user()->area;
        if ($area)
            return $area->responsable ? $area->responsable->id : "";
        return "";
    }

    public function unidadOrganicaResponsable()
    {
        $area = $this->request->user()->area;
        if ($area)
            return $area->responsable ? $area->responsable->area->nombre : "Sin unidad - Sin responsable";
        return "SIN UNIDAD SIN REPONSABLE";
    }

    public function firmaResponsable()
    {
        $area = $this->request->user()->area;
        if ($area)
            return $area->responsable ?
                ($area->responsable->nombres . ' ' . $area->responsable->apellidos) : "Sin nombres - Sin responsable";
        return "SIN UNIDAD - SIN REPONSABLE";
    }

    public function cargoResponsable()
    {
        $area = $this->request->user()->area;
        if ($area)
            return $area->responsable ? $area->responsable->cargo : "Sin cargo - Sin responsable";
        return "SIN UNIDAD - SIN RESPONSABLE";
    }
}
