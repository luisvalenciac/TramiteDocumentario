<?php

namespace App\Wrappers\Vistas;

use App\Contracts\UsuarioRepository;
use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;

class DatosEditarArea
{
    public $area;
    public $tiposArea;
    private $userService;

    public function __construct($area, UsuarioRepository $userService)
    {
        $this->area = $area;
        $this->tiposArea = AreaTablaInfo::tiposAreaDict();
        $this->userService = $userService;
    }

    public function getUserPorId($id)
    {
        return $id != '' ? $this->userService->buscarPor(UsuarioTablaInfo::ID, $id) : null;
    }
}
