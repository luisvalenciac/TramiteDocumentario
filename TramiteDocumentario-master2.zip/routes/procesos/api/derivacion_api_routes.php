<?php

use App\Http\Controllers\API\APIDerivacionController;

Route::post('validar', [APIDerivacionController::class, 'validarDerivacion'])
    ->name('validar');


