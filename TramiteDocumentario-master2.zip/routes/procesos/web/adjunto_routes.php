<?php


use Illuminate\Support\Facades\Route;

Route::prefix('api-v1/')
    ->name('api.v1.')
    ->group(base_path('routes/procesos/api/adjunto_api_routes.php'));
