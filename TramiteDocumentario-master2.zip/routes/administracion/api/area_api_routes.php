<?php

use App\Http\Controllers\API\APIAreaController;

Route::get('buscar', [APIAreaController::class, 'buscarAreas'])->name('buscar');
