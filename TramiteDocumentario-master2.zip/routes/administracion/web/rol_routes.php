<?php


Route::resource('roles', 'Administracion\RolController');
