<?php

use App\Http\Controllers\Auth\LoginController;
use Illuminate\Support\Facades\Route;

Route::get('/', [LoginController::class, 'showLoginForm'])->name('login.vistaLogin');
Route::post('iniciar-sesion', [LoginController::class, 'login'])->name('login.iniciarSesion');
Route::post('cerrar-sesion', [LoginController::class, 'logout'])->name('login.cerrarSesion');

Route::prefix('administracion/')
    ->name('administracion.')
    ->group(base_path('routes/administracion/web/usuario_routes.php'));

Route::prefix('administracion/')
    ->name('administracion.')
    ->group(base_path('routes/administracion/web/tipo_solicitud_routes.php'));

Route::prefix('administracion/')
    ->name('administracion.')
    ->group(base_path('routes/administracion/web/area_routes.php'));

Route::prefix('administracion/')
    ->name('administracion.')
    ->group(base_path('routes/administracion/web/rol_routes.php'));

Route::prefix('administracion/')
    ->name('administracion.')
    ->group(base_path('routes/administracion/web/archivador_routes.php'));

Route::prefix('administracion/')
    ->name('administracion.')
    ->group(base_path('routes/administracion/web/dashboard_routes.php'));

Route::prefix('procesos/tramites/')
    ->name('procesos.tramites.')
    ->group(base_path('routes/procesos/web/tramite_routes.php'));

Route::prefix('procesos/derivaciones/')
    ->name('procesos.derivaciones.')
    ->group(base_path('routes/procesos/web/derivacion_routes.php'));

Route::prefix('procesos/solicitudes/')
    ->name('procesos.solicitudes.')
    ->group(base_path('routes/procesos/web/solicitud_routes.php'));

Route::prefix('procesos/adjuntos/')
    ->name('procesos.adjuntos.')
    ->group(base_path('routes/procesos/web/adjunto_routes.php'));

Route::prefix('configuracion/tramites/')
    ->name('configuracion.tramites.')
    ->group(base_path('routes/configuracion/web/config_tramite_routes.php'));
