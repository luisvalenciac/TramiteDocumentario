//document.addEventListener("DOMContentLoaded", function (event) {
//    var wrapper = document.getElementById('wrapper');
//    wrapper.classList.remove('wrapper-is-loading');

 //   var spinner = document.getElementById('Spinner');
   // spinner.style.opacity = 0;
    //spinner.style.visibility = 'hidden';
//});
