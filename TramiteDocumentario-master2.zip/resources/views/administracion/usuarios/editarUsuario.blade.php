@extends('layouts.app')
@section('titulo', 'Editar Usuario')
@section('contenido')

<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Usuario</a></li>
                    <li class="breadcrumb-item active">Editar</li>
                </ol>
            </div>
            <h4 id="TituloCrearUser" class="page-title">Editar Usuario</h4>
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>
    </div>
</div>

<form action="{{ route('administracion.usuarios.update', ['usuario' => $datos->usuario]) }}" method="post">
    @csrf
    @method('PATCH')
    <div class="row">
        <input type="hidden" name="id" value="{{$datos->usuario->id}}">
        <div class="col-lg-6">
            <div class="card-box">
                <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Datos Personales</h5>

                {{-- DNI --}}
                <div class="form-group mb-3">
                    <label for="dni">DNI <span class="text-danger">*</span></label>
                    <input type="text" id="dni" name="dni"
                           class="form-control @error('dni') is-invalid @enderror"
                           value="{{ old('dni', $datos->usuario->dni) }}"
                           autocomplete="off"
                           maxlength="8">
                    <span class="invalid-feedback" data-input-name="dni"></span>
                    @error('dni')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- NOMBRES --}}
                <div class="form-group mb-3">
                    <label for="nombres">Nombres <span class="text-danger">*</span></label>
                    <input type="text" id="nombres" name="nombres"
                           class="form-control @error('nombres') is-invalid @enderror"
                           value="{{ old('nombres', $datos->usuario->nombres) }}"

                           autocomplete="off">
                    @error('nombres')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- APELLIDOS --}}
                <div class="form-group mb-3">
                    <label for="apellidos">Apellidos <span class="text-danger">*</span></label>
                    <input type="text" id="apellidos" name="apellidos"
                           class="form-control @error('apellidos') is-invalid @enderror"
                           value="{{ old('apellidos', $datos->usuario->apellidos) }}"

                           autocomplete="off">
                    @error('apellidos')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- CORREO ELECTRÓNICO --}}
                <div class="form-group mb-3">
                    <label for="correo">Correo Electrónico</label>
                    <input type="text" id="correo" name="correo"
                           class="form-control @error('correo') is-invalid @enderror"
                           value="{{ old('correo', $datos->usuario->correo) }}"
                           autocomplete="off">
                    @error('correo')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- TELÉFONO --}}
                <div class="form-group mb-3">
                    <label for="telefono">Teléfono</label>
                    <input type="text" id="telefono" name="telefono"
                           class="form-control @error('telefono') is-invalid @enderror"
                           value="{{ old('telefono', $datos->usuario->telefono) }}"
                           autocomplete="off">
                    @error('telefono')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- DIRECCIÓN --}}
                <div class="form-group mb-3">
                    <label for="direccion">Dirección</label>
                    <input type="text" id="direccion" name="direccion"
                           class="form-control @error('direccion') is-invalid @enderror"
                           value="{{ old('direccion', $datos->usuario->direccion) }}"
                           autocomplete="off">
                    @error('direccion')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div> <!-- end card-box -->
        </div> <!-- end col -->

        <div class="col-lg-6">

            <div class="card-box">
                <h5 class="text-uppercase mt-0 mb-3 bg-light p-2">Datos de la Cuenta</h5>

                {{-- CARGO --}}
                <div class="form-group mb-3">
                    <label for="cargo">Cargo <span class="text-danger">*</span></label>
                    <input type="text" id="cargo" name="cargo"
                           class="form-control @error('cargo') is-invalid @enderror"
                           value="{{ old('cargo', $datos->usuario->cargo) }}"
                           autocomplete="off">
                    @error('cargo')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- ROL DE USUARIO --}}
                <div class="form-group mb-3">
                    <label for="rol">Rol de Usuario <span class="text-danger">*</span></label>
                    <select name="rol" id="rol" class="form-control">
                        @foreach($datos->roles as $r)
                            <option
                                @foreach($datos->usuario->getRoleNames() as $rn)
                                @if($r->name == $rn)
                                selected
                                @endif
                                @endforeach
                                value="{{$r->name}}">{{$r->display_name}}</option>
                        @endforeach
                    </select>
                    @error('rol')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- UNIDAD ORGÁNICA --}}
                <div class="form-group mb-3">
                    <label for="area_id">Unidad orgánica <span class="text-danger">*</span></label>
                    <select id="area_id" name="area_id" class="form-control">
                        <option value="">Seleccionar una unidad</option>
                        @foreach($datos->areas as $area)
                            <option
                                @if($area->id == ($datos->usuario->area ? $datos->usuario->area->id : "0"))
                                selected
                                @endif
                                value="{{$area->id}}">{{$area->nombre}}</option>
                        @endforeach
                    </select>
                    @error('area_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- NOMBRE DE USUARIO --}}
                <div class="form-group mb-3">
                    <label for="username">Nombre de usuario</label>
                    <input type="text" id="username" name="username"
                           class="form-control @error('username') is-invalid @enderror"
                           value="{{ old('username', $datos->usuario->username) }}"
                           autocomplete="off">
                    @error('username')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                <div class="form-group form-check">
                    <input type="checkbox" id="change_password"
                           name="change_password"
                           class="form-check-input"
                           value="true"
                           @if(old('change_password') == 'true')
                           checked
                        @endif
                    >
                    <label for="change_password">Deseo actualizar la contraseña</label>
                </div>

                {{-- CONTRASEÑA --}}
                <div class="form-group mb-3">
                    <label for="password">Contraseña</label>
                    <input type="password" id="password" name="password"
                           class="form-control @error('password') is-invalid @enderror"
                           value=""
                           autocomplete="off">
                    @error('password')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- CONTRASEÑA --}}
                <div class="form-group mb-3">
                    <label for="password_confirmation">Confirmar contraseña</label>
                    <input type="password" id="password_confirmation" name="password_confirmation"
                           class="form-control @error('password_confirmation') is-invalid @enderror"
                           value=""
                           autocomplete="off">
                </div>

                <button type="submit" class="btn btn-primary">Actualizar</button>

            </div> <!-- end col-->
        </div> <!-- end col-->
    </div>
</form>

@endsection
