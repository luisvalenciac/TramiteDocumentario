@extends('layouts.app')
@section('titulo', 'Detalle de Usuario')
@section('contenido')

<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Usuario</a></li>
                    <li class="breadcrumb-item active">Detalle</li>
                </ol>
            </div>
            <h4 id="TituloCrearUser" class="page-title">Detalle de Usuario</h4>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-lg-6">
        <div class="card-box">
            <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Datos Personales</h5>

            {{-- DNI --}}
            <div class="form-group mb-3">
                <label for="dni">DNI </label>
                <input type="text" id="dni" name="dni"
                       class="form-control"
                       value="{{ $usuario->dni }}"
                       readonly>
            </div>

            {{-- NOMBRES --}}
            <div class="form-group mb-3">
                <label for="nombres">Nombres </label>
                <input type="text" id="nombres" name="nombres"
                       class="form-control"
                       value="{{ $usuario->nombres }}"
                       readonly>
            </div>

            {{-- APELLIDOS --}}
            <div class="form-group mb-3">
                <label for="apellidos">Apellidos </label>
                <input type="text" id="apellidos" name="apellidos"
                       class="form-control"
                       value="{{ $usuario->apellidos }}"
                       readonly>
            </div>

            {{-- CORREO ELECTRÓNICO --}}
            <div class="form-group mb-3">
                <label for="correo">Correo Electrónico </label>
                <input type="text" id="correo" name="correo"
                       class="form-control"
                       value="{{ $usuario->correo }}"
                       readonly>
            </div>

            {{-- TELÉFONO --}}
            <div class="form-group mb-3">
                <label for="telefono">Teléfono </label>
                <input type="text" id="telefono" name="telefono"
                       class="form-control"
                       value="{{ $usuario->telefono }}"
                       readonly>
            </div>

            {{-- DIRECCIÓN --}}
            <div class="form-group mb-3">
                <label for="direccion">Dirección </label>
                <input type="text" id="direccion" name="direccion"
                class="form-control"
                value="{{ $usuario->direccion }}"
                readonly>
            </div>
        </div> <!-- end card-box -->
    </div> <!-- end col -->

    <div class="col-lg-6">
        <div class="card-box">
            <h5 class="text-uppercase mt-0 mb-3 bg-light p-2">Datos de la Cuenta</h5>

            {{-- CARGO --}}
            <div class="form-group mb-3">
                <label for="cargo">Cargo </label>
                <input type="text" id="cargo" name="cargo"
                        class="form-control"
                        value="{{ $usuario->cargo }}"
                        readonly>
            </div>

            {{-- ROL DE USUARIO --}}
            <div class="form-group mb-3">
                <label for="rol">Rol de Usuario </label>
                <ul>
                    @forelse($usuario->roles as $r)
                        <li>{{$r->display_name}}</li>
                    @empty
                        <li>No tiene rol</li>
                    @endforelse
                </ul>
            </div>

            {{-- UNIDAD ORGÁNICA --}}
            <div class="form-group mb-3">
                <label for="area_id">Unidad orgánica </label>
                @if($usuario->area)
                    <input type="text" id="area" name="area"
                           class="form-control"
                           value="{{ $usuario->area->nombre }}"
                           readonly>
                @else
                    No tiene área
                @endif
            </div>

            {{-- NOMBRE DE USUARIO --}}
            <div class="form-group mb-3">
                <label for="username">Nombre de usuario </label>
                <input type="text" id="username" name="username"
                       class="form-control"
                       value="{{ $usuario->username }}"
                       readonly>
            </div>


            <a href="{{route('administracion.usuarios.index')}}">Regresar</a>

        </div> <!-- end col-->
    </div> <!-- end col-->
</div>

@endsection

