@extends('layouts.app')
@section('titulo', 'Editar tipo solicitud')
@section('contenido')

    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Tipo solicitud</a></li>
                        <li class="breadcrumb-item active">Editar</li>
                    </ol>
                </div>
                <h4 class="page-title">Editar Tipo Solicitud</h4>
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif
            </div>
        </div>
    </div>

    <form action="{{ route('administracion.tiposSolicitud.update', ['tipoSolicitud' => $tipoSolicitud]) }}" method="post">
        @csrf
        @method('PATCH')
        <div class="row">
            <div class="col-lg-6">
                <div class="card-box">
                    <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Datos</h5>
                    <input type="hidden" name="id" value="{{$tipoSolicitud->id}}">
                    <div class="form-group mb-3">
                        <label for="nombre">Nombre de solicitud <span class="text-danger">*</span></label>
                        <input type="text" id="nombre_tipo" name="nombre_tipo"
                               class="form-control @error('nombre_tipo') is-invalid @enderror"
                               value="{{ old('nombre_tipo', $tipoSolicitud->nombre_tipo) }}"
                               autocomplete="off">
                        @error('nombre_tipo')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </div>
    </form>

@endsection
