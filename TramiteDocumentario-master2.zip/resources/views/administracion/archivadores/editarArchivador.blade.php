@extends('layouts.app')
@section('titulo', 'Archivadores')
@section('contenido')

<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Archivador</a></li>
                    <li class="breadcrumb-item active">Registrar</li>
                </ol>
            </div>
            <h4 id="" class="page-title">Actualizar Archivador: {{$datos->archivador->nombre}}</h4>
            @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        </div>
    </div>
</div>

<form action="{{ route('administracion.archivadores.update', ['archivadore' => $datos->archivador]) }}"
        method="POST">
    @method('PATCH')
    @csrf
    <input type="hidden" name="id" value="{{$datos->archivador->id}}">
    <div class="row">
        <div class="col-lg-6">
            <div class="card-box">
                <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Datos</h5>
                <div class="form-group mb-3">
                    <label for="area_id">Unidad orgánica a la que pertenece</label>
                    <select name="area_id" id="area_id" class="custom-select2 @error('area_id') is-invalid @enderror"
                    style="width: 100%">
                        @foreach($datos->areas as $area)
                            <option
                                @if($area->id == $datos->archivador->area->id)
                                selected="selected"
                                @endif
                                value="{{$area->id}}">
                                {{$area->nombre}} - {{$area->siglas}}
                            </option>
                        @endforeach
                    </select>
                    @error('area_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <div class="form-group mb-3">
                    <label for="nombre">Nombre</label>
                    <input type="text" id="nombre" name="nombre" class="form-control @error('nombre') is-invalid @enderror"
                            value="{{old('nombre', $datos->archivador->nombre)}}">
                    @error('nombre')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card-box">
                <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Periodo</h5>
                <div class="form-group mb-3">
                    <label for="periodo">Periodo</label>
                    <input type="text" id="periodo" name="periodo" class="form-control @error('periodo') is-invalid @enderror"
                            value="{{old('periodo', $datos->archivador->periodo)}}">
                    @error('periodo')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </div>
    </div>
</form>

@endsection
