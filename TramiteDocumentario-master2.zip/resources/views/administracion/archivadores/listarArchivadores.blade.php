@extends('layouts.app')
@section('titulo', 'Archivadores')
@section('contenido')

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item active">Archivadores</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Archivadores</h4>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-2">
        @can('create', App\Models\Archivador::class)
            <div class="col-sm-4">
                <a href="{{ route('administracion.archivadores.create')}}"
                    class="btn btn-primary btn-rounded waves-effect waves-light mb-3">
                    <i class="mdi mdi-plus"></i>
                    Crear Archivador
                </a>
            </div>
        @endcan
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <form action="{{route('administracion.archivadores.index')}}" id="DivFiltros">
                    <div class="form-row">
                        <div class="col-md-2">
                            <label for="nombres">Nombres</label>
                            <input type="text" name="nombre" class="form-control"
                                   value="{{request()->query('nombre', '')}}">
                        </div>
                        <div class="col-md-2">
                            <label for="correo">Periodo</label>
                            <input type="text" name="periodo" class="form-control"
                                   value="{{request()->query('periodo', '')}}">
                        </div>
                        <div class="col-md-3">
                            <label for="area">Unidad orgánica</label>
                            {? $area = $datos->getAreaPorId(request()->query('area', 0)) ?}
                            <select data-allow-clear="true" name="area" id="SelectBuscarArea"
                                    data-placeholder="Busque unidad orgánica por nombre"
                                    class="form-control"
                                    data-buscar-area-url="{{route('administracion.areas.api.v1.buscar')}}">
                                <option></option>
                                @if($area)
                                    <option selected value="{{$area->id}}">
                                        {{$area->infoArea()}}
                                    </option>
                                @endif
                            </select>
                        </div>
                        <div class="col-md-3 mt-3" style="display: flex; align-items: center;">
                            <button class="btn btn-blue waves-effect waves-light"><i class="mdi mdi-filter mr-1"></i> Filtrar</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
            <table class="table table-hover datatable">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Periodo</th>
                    <th>Unidad orgánica</th>
                    <th>Opciones</th>
                </tr>
                </thead>
                <tbody>
                @foreach($datos->archivadores as $archivador)
                    <tr>
                        <td>{{ $archivador->id }}</td>
                        <td>{{ $archivador->nombre }}</td>
                        <td>{{ $archivador->periodo }}</td>
                        <td>{{ $archivador->area->nombre }} - {{ $archivador->area->siglas  }}</td>
                        <td>
                            @can('update', $archivador)

                                <a href="{{ route('administracion.archivadores.edit', ['archivadore' => $archivador]) }}"
                                   class="btn btn-warning waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Editar" data-original-title="Editar">
                                    <i class="mdi mdi-account-box-multiple"></i>
                                </a>
                            @endcan
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
            </div>
        </div>
    </div>
        {{$datos->archivadores->withQueryString()->links()}}
@endsection
