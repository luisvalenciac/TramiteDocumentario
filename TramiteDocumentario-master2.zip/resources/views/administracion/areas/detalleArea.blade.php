@extends('layouts.app')
@section('titulo', 'Detalle de area')
@section('contenido')

    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Unidad Orgánica</a></li>
                        <li class="breadcrumb-item active">Detalle</li>
                    </ol>
                </div>
                <h4  class="page-title">Detalle de Unidad Orgánica</h4>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="card-box">
                <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Datos</h5>
                <div class="form-group">
                    <label for="nombre">Nombre</label>
                    <input type="text" id="nombre" name="nombre"
                           class="form-control"
                           value="{{ $area->nombre }}"
                           readonly>
                </div>
                <div class="form-group">
                    <label for="abreviatura">Abreviatura</label>
                    <input type="text" id="abreviatura" name="abreviatura"
                           class="form-control"
                           value=" {{ $area->abreviatura }}" readonly/>
                </div>
                <div class="form-group">
                    <label for="siglas">Siglas</label>
                    <input type="text" id="siglas" name="siglas"
                           class="form-control"
                           value="{{ $area->siglas }}"
                           readonly/>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card-box">
                <div class="form-group mb-3">
                    <label for="tipo_area">Tipo <span class="text-danger">*</span></label>
                    <input id="tipo_area" type="text" name="tipo_area" value="{{$tipos[$area->tipo_area]}}"
                           class="form-control">
                </div>
                <div class="form-group">
                    <label for="siglas">Representante</label>
                    <input type="text" id="siglas" name="siglas"
                           class="form-control"
                           @if($area->responsable)
                           value="{{ $area->responsable->infoUserYArea()}}"
                           @else
                           value="Sin representante"
                           @endif
                           readonly>
                </div>
            </div>
        </div>
    </div>
@endsection
