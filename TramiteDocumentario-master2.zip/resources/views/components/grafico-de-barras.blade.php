<canvas id="GraficoDeBarras"></canvas>
<input type="hidden" id="GraficoDeBarrasDatos" value="{{ $datos }}">
