<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('titulo', 'Sistema de Trámite Documentario - UNACH')</title>
    <meta content="" name="description" />
    <meta content="" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="shortcut icon" href="{{asset('assets/images/favicon.ico')}}">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    {{-- TODO: SEO --}}
    <link rel="stylesheet" type="text/css" id="app-default-stylesheet" href="{{ mix('css/home.css') }}">

</head>

<body class="auth-fluid-pages pb-0">
    @include('partials.home.upNavbar')

    @yield('contenido')
    <script src="{{asset('assets/js/vendor.min.js')}}"></script>
    <script src="{{ mix('js/home.js') }}"></script>
</body>

</html>
