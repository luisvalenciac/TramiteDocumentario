@extends('layouts.app')
@section('titulo', "Dashboard")
@section('contenido')

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Dashboard Principal</h4>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 col-xl-3">
                <div class="widget-rounded-circle card-box">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <div class="avatar-lg">
                                <img src="{{asset('assets/images/brands/worker.png')}}" class="img-fluid"
                                     alt="user-img">
                            </div>
                        </div>
                        <div class="col">
                            <h5 class="mb-1 mt-2 font-16">Usuarios</h5>
                            @can('viewAny', App\Models\Usuario::class)
                                <a href="{{route('administracion.usuarios.index')}}"
                                   class="{{setActive('administracion.usuarios.*')}} btn btn-blue waves-effect waves-light">
                                    <span class="btn-label"><i class="mdi mdi-check-all"></i></span>Seleccionar
                                </a>
                            @endcan
                        </div>
                    </div> <!-- end row-->
                </div> <!-- end widget-rounded-circle-->
            </div> <!-- end col-->

            <div class="col-md-6 col-xl-3">
                <div class="widget-rounded-circle card-box">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <div class="avatar-lg">
                                <img src="{{asset('assets/images/brands/documents.png')}}" class="img-fluid"
                                     alt="user-img">
                            </div>
                        </div>
                        <div class="col">
                            <h5 class="mb-1 mt-2 font-16">Trámites</h5>
                            @can('crearTramite', App\Models\Tramite::class)
                                <a href="{{route('procesos.tramites.crear')}}"
                                   class="{{setActive('procesos.tramites.crear')}} btn btn-info waves-effect waves-light">
                                    <span class="btn-label"><i class="mdi mdi-check-all"></i></span>Seleccionar
                                </a>
                            @endcan
                        </div>
                    </div> <!-- end row-->
                </div> <!-- end widget-rounded-circle-->
            </div> <!-- end col-->

            <div class="col-md-6 col-xl-3">
                <div class="widget-rounded-circle card-box">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <div class="avatar-lg">
                                <img src="{{asset('assets/images/brands/paper-plane.png')}}" class="img-fluid"
                                     alt="user-img">
                            </div>
                        </div>
                        <div class="col">
                            <h5 class="mb-1 mt-2 font-16">Por atender</h5>
                            @can('verEstadosDeTramite', App\Models\Derivacion::class)
                                <a href="{{route('procesos.derivaciones.derivaciones',
                                        ["estado" => derivacionTablaInfo()::ESTADO_POR_ATENDER])}}"
                                   class="btn btn-primary waves-effect waves-light">
                                    <span class="btn-label"><i class="mdi mdi-check-all"></i></span>Seleccionar
                                </a>
                            @endcan
                        </div>
                    </div> <!-- end row-->
                </div> <!-- end widget-rounded-circle-->
            </div> <!-- end col-->

            <div class="col-md-6 col-xl-3">
                <div class="widget-rounded-circle card-box">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <div class="avatar-lg">
                                <img src="{{asset('assets/images/brands/statistics.png')}}" class="img-fluid"
                                     alt="user-img">
                            </div>
                        </div>
                        <div class="col">
                            <h5 class="mb-1 mt-2 font-16">Exportar</h5>
                            @can('exportarDerivaciones', App\Models\Derivacion::class)
                                <a href="{{route('procesos.derivaciones.vistaExportar')}}"
                                   class="btn btn-pink waves-effect waves-light">
                                    <span class="btn-label"><i class="mdi mdi-check-all"></i></span>Seleccionar
                                </a>
                            @endcan
                        </div>
                    </div> <!-- end row-->
                </div> <!-- end widget-rounded-circle-->
            </div> <!-- end col-->
        </div>
        <div class="row">
            @can('verEstadosDeTramite', App\Models\Derivacion::class)
                <div class="col-12 mb-2">
                    <h4>Estádisticas del presente año</h4>
                </div>
                <div class="col">
                    <x-card-por-atender/>
                </div>
                <div class="col">
                    <x-card-por-recibir/>
                </div>
                <div class="col">
                    <x-card-atendidos/>
                </div>
                <div class="col">
                    <x-card-archivados/>
                </div>
            @endcan
            @can('viewAny', App\Models\Usuario::class)
                <div class="col">
                    <x-card-conteo-usuarios></x-card-conteo-usuarios>
                </div>
            @endcan
        </div>
        @can('verEstadosDeTramite', App\Models\Derivacion::class)
        <div class="col-md-12">
            <div class="widget-rounded-circle card-box">
                <div class="row align-items-center">
                    <div class="col-12 col-md-6">
                        <x-grafico-de-barras/>
                    </div>
                    <div class="col-12 col-md-6">
                        <x-grafico-circular/>
                    </div>
                </div>
            </div>
        </div>

        @endcan
    </div>

@endsection
