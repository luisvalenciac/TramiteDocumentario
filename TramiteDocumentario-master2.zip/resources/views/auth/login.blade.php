@extends('layouts.home')
@section('titulo', 'Sistema de Trámite Documentario - UNACH')
@section('contenido')

    <div class="auth-fluid">
        <!--Auth fluid left content -->
        <div class="auth-fluid-form-box">
            <div class="align-items-center d-flex h-100">
                <div class="card-body">

                    <!-- Logo -->
                    <div class="auth-brand text-center text-lg-left">
                        <div class="auth-logo">
                            <a href="/" class="logo logo-dark text-center">
                            <span class="logo-lg">
                                <img src="{{asset('assets/images/logo.png')}}" alt="LOGO UNACH" height="80"/>

                            </span>
                            </a>

                            <a href="/" class="logo logo-light text-center">
                            <span class="logo-lg">
                                <img src="{{asset('assets/images/logo.png')}}" alt="LOGO UNACH" height="80"/>

                            </span>
                            </a>
                        </div>
                    </div>

                    <h4 class="mt-2">Bienvenidos!</h4>
                    <p class="text-muted mb-4">Por favor ingresa los datos de tu cuenta.</p>

                    @if(session('error'))
                        <div class="alert alert-danger">{{ session('error') }}</div>
                        <br>@endif
                    @if(session('success'))
                        <div class="alert alert-success">{{ session('success') }}</div>
                        <br>@endif

                    <form method="POST" action="{{ route('login.iniciarSesion') }}">
                        @csrf
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input id="username" type="text"
                                   class="form-control @if($errors->has('username')) is-invalid @endif" name="username"
                                   value="{{ old('username') }}" required
                                   placeholder="Ingrese su username" autofocus>
                            @if($errors->has('username'))
                                <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('username') }}</strong>
                        </span>
                            @endif

                        </div>
                        <div class="form-group">
                            <label for="password">Contraseña</label>
                            <div class="input-group input-group-merge">
                                <input type="password"
                                       class="form-control @if($errors->has('password')) is-invalid @endif"
                                       id="password"
                                       placeholder="Ingrese su contraseña" required autocomplete="current-password"
                                       name="password"/>
                                <div class="input-group-append" data-password="false">
                                    <div class="input-group-text">
                                        <span class="password-eye"></span>
                                    </div>
                                </div>
                            </div>
                            @if($errors->has('password'))
                                <span class="invalid-feedback" role="alert">
                            <strong>{{ $errors->first('password') }}</strong>
                        </span>
                            @endif
                        </div>

                        <div class="form-group mb-3">
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="checkbox-signin"
                                    {{ old('remember') ? 'checked' : '' }} />
                                <label class="custom-control-label" for="checkbox-signin">Recordar usuario</label>
                            </div>
                        </div>
                        <div class="form-group mb-0 text-center">
                            <button class="btn btn-primary btn-block" type="submit">Log In</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Auth fluid right content -->
        <div class="auth-fluid-right text-center">
            <div class="auth-user-testimonial">
                <h2 class="mb-3 text-white">Sistema de Trámite Documentario - UNACH</h2>
                <h5 class="text-white">
                    Chota - Cajamarca
                </h5>
            </div> <!-- end auth-user-testimonial-->
        </div>
        <!-- end Auth fluid right content -->
    </div>
    <!-- end auth-fluid-->

@endsection
