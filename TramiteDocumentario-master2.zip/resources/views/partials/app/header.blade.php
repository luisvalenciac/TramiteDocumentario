<div class="navbar-custom">
    <div class="container-fluid">
        <ul class="list-unstyled topnav-menu float-right mb-0">

            {{--Buscar mobile--}}

            {{--Boton Pantalla Completa--}}
            <li class="dropdown d-none d-lg-inline-block">
                <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="fullscreen"
                   href="#">
                    <i class="fe-maximize noti-icon"></i>
                </a>
            </li>
            {{--Aplicaciones--}}
            <li class="dropdown d-none d-lg-inline-block topbar-dropdown">
                <a class="nav-link dropdown-toggle arrow-none waves-effect waves-light" data-toggle="dropdown" href="#"
                   role="button" aria-haspopup="false" aria-expanded="false">
                    <i class="fe-grid noti-icon"></i>
                </a>
                <div class="dropdown-menu dropdown-lg dropdown-menu-right">

                    <div class="p-lg-1">
                        <div class="row no-gutters">
                            <div class="col">
                                <a class="dropdown-icon-item" href="https://www.unach.edu.pe/sisacad/zet/index.php">
                                    <img src="{{asset('assets/images/brands/ophtalmology.png')}}" alt="sisgest">
                                    <span>SisGestUniv</span>
                                </a>
                            </div>
                            <div class="col">
                                <a class="dropdown-icon-item"
                                   href="https://elibro.net/es/lc/bibliounach/login_usuario/?next=/es/lc/bibliounach/inicio">
                                    <img src="{{asset('assets/images/brands/open-book.png')}}" alt="elibro">
                                    <span>E-Libro</span>
                                </a>
                            </div>
                            <div class="col">
                                <a class="dropdown-icon-item" href="https://www.unach.edu.pe/serviciosunach/">
                                    <img src="{{asset('assets/images/brands/cubes.png')}}" alt="campusv">
                                    <span>Campus Virtual</span>
                                </a>
                            </div>
                        </div>

                        <div class="row no-gutters">
                            <div class="col">
                                <a class="dropdown-icon-item"
                                   href="https://www.unach.edu.pe/desarrollo/unach2/index.php/index.php?option=com_content&view=article&id=337&catid=106">
                                    <img src="{{asset('assets/images/brands/suitcase.png')}}" alt="bitbucket">
                                    <span>Bolsa de Trabajo</span>
                                </a>
                            </div>
                            <div class="col">
                                <a class="dropdown-icon-item"
                                   href="https://www.unach.edu.pe/desarrollo/unach2/index.php/index.php?option=com_content&amp;view=article&amp;id=255&amp;catid=95">
                                    <img src="{{asset('assets/images/brands/law.png')}}" alt="defensoria">
                                    <span>Defensoría</span>
                                </a>
                            </div>
                            <div class="col">
                                <a class="dropdown-icon-item"
                                   href="https://www.unach.edu.pe/desarrollo/unach2/index.php/index.php?option=com_content&view=article&id=364&catid=95">
                                    <img src="{{asset('assets/images/brands/book.png')}}" alt="saludmental">
                                    <span>Salud Mental</span>
                                </a>
                            </div>

                        </div>
                    </div>

                </div>
            </li>
            {{--Usuario--}}
            <li class="dropdown notification-list topbar-dropdown">
                <a class="nav-link dropdown-toggle nav-user mr-0 waves-effect waves-light" data-toggle="dropdown"
                   href="#" role="button" aria-haspopup="false" aria-expanded="false">
                    <span class="pro-user-name ml-1">
                        {{request()->user()->infoUserYArea()}} <i class="mdi mdi-chevron-down"></i>
                    </span>
                </a>
                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                    <!-- item-->
                    <div class="dropdown-header noti-title">
                        <h6 class="text-overflow m-0">{{request()->user()->roles()->get()[0]->display_name}}</h6>
                    </div>

                    <div class="dropdown-divider"></div>

                    <!-- item-->
                    <a id="LinkCerrarSesion" href="{{ route('login.cerrarSesion') }}"
                       class="dropdown-item notify-item">
                        <i class="fe-log-out"></i>
                        <span>Cerrar Sesión</span>
                    </a>

                    <form id="FormCerrarSesion" action="{{ route('login.cerrarSesion') }}"
                          method="POST">
                        @csrf
                    </form>
                </div>
            </li>
        </ul>
        {{--Logo--}}
        <div class="logo-box">
            <a href="#" class="logo logo-dark text-center">
                <span class="logo-sm">
                    <img src="{{asset('assets/images/logochescudo.png')}}" alt="" height="50">
                </span>
                <span class="logo-lg">
                    <img src="{{asset('assets/images/logochwhite.png')}}" alt="" height="50">
                </span>
            </a>

            <a href="#" class="logo logo-light text-center">
                <span class="logo-sm">
                    <img src="{{asset('assets/images/logochescudo.png')}}" alt="" height="45">
                </span>
                <span class="logo-lg">
                    <img src="{{asset('assets/images/logochwhite.png')}}" alt="" height="48">
                </span>
            </a>
        </div>
        {{--Menu Mobile--}}
        <ul class="list-unstyled topnav-menu topnav-menu-left m-0">
            <li>
                <button class="button-menu-mobile waves-effect waves-light">
                    <i class="fe-menu"></i>
                </button>
            </li>
            <li>
                <!-- Mobile menu toggle (Horizontal Layout)-->
                <a class="navbar-toggle nav-link" data-toggle="collapse" data-target="#topnav-menu-content">
                    <div class="lines">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </a>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
</div>
