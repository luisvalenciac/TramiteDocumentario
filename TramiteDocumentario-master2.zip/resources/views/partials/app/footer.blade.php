<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                {{ date('Y') }} &copy; <a href="https://www.unach.edu.pe/">Universidad Nacional Autónoma de Chota</a> - Todos los derechos reservados
            </div>
        </div>
    </div>
</footer>