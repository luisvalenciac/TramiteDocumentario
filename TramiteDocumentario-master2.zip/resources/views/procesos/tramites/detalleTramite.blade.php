@extends('layouts.app')
@section('titulo', 'Detalle de trámite')
@section('contenido')

    <div class="container-fluid">

        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Trámites</a></li>
                            <li class="breadcrumb-item active">Detalle de trámite</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Detalle de trámite - N° {{$datos->tramite->numero_tramite}}</h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card-box">
                    <!-- Logo & title -->
                    <div class="clearfix">
                        <div class="float-left">
                            <div class="auth-logo">
                                <div class="logo logo-dark">
                                <span class="logo-lg">
                                    <img src="{{asset('assets/images/logo-dark.png')}}" alt="" height="50">
                                </span>
                                </div>

                                <div class="logo logo-light">
                                <span class="logo-lg">
                                    <img src="{{asset('assets/images/logo-dark.png')}}" alt="" height="50">
                                </span>
                                </div>
                            </div>
                        </div>
                        <div class="float-right">
                            <h4 class="m-0 d-print-none">Detalle de trámite</h4>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="mt-3">
                                <p><b>Usuario Solicitante - Firma</b></p>
                                <p class="text-muted">{{$datos->tramite->userOrigen->infoUserYArea()}}</p>
                            </div>

                        </div><!-- end col -->
                        <div class="col-md-4 offset-md-2">
                            <div class="mt-3 float-right">
                                <p class="m-b-10"><strong>Fecha de Solicitud : </strong> <span class="float-right">&nbsp; &nbsp; &nbsp; {{$datos->tramite->fecha_emision}} </span>
                                </p>
                                <p class="m-b-10"><strong>Prioridad : </strong> <span class="float-right"><span
                                            class="badge badge-danger">{{$datos->prioridadDict[$datos->tramite->prioridad]}}</span></span>
                                </p>
                                <p class="m-b-10"><strong>No. de Trámite : </strong> <span
                                        class="float-right">{{$datos->tramite->numero_tramite}} </span></p>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-sm-3">
                            <h6>Tipo de Documento</h6>
                            <strong>
                                @if($datos->tramite->tipoSolicitud)
                                    {{$datos->tramite->tipoSolicitud->nombre_tipo}}
                                @else
                                    Otros - {{$datos->tramite->otro_tipo_solicitud}}
                                @endif
                            </strong>
                        </div>

                        <div class="col-sm-3">
                            <h6>Tipo de solicitante</h6>
                            <strong>
                                {{$datos->tiposSolicitante[$datos->tramite->tipo_solicitante]}}
                            </strong>
                        </div>

                        <div class="col-sm-3">
                            <h6>Datos de identificación</h6>
                            <strong>
                                {{$datos->tramite->dato_identificacion}}
                            </strong>
                        </div>

                        <div class="col-sm-3">
                            <h6>Forma de recepción</h6>
                            <strong>
                                {{$datos->formasRecepcionDict[$datos->tramite->forma_recepcion]}}
                            </strong>
                        </div>

                        <div class="col-sm-3">
                            <h6>Folios</h6>
                            <strong>
                                {{$datos->tramite->folios}}
                            </strong>
                        </div>
                    </div>

                    <div class="row mt-3">
                        <div class="col-sm-3">
                            <h6>Archivo de trámite</h6>
                            <strong>
                                @if($datos->tramite->archivo_tramite)
                                    <a href="{{$datos->tramite->archivo_tramite}}"
                                       class="btn btn-success waves-effect waves-light"><span class="btn-label"><i
                                                class="mdi mdi-cloud-download"></i></span>Descargar Archivo</a>
                                @else
                                    No se agregó archivo
                                @endif
                            </strong>
                        </div>

                        <div class="col-sm-3">
                            <h6>Asunto</h6>
                            <strong>
                                {{$datos->tramite->asunto}}
                            </strong>
                        </div>

                        <div class="col-sm-3">
                            <h6>Anexos</h6>
                            <strong>
                                {{$datos->tramite->anexos}}
                            </strong>
                        </div>

                        <div class="col-sm-3">
                            <h6>Referencia</h6>
                            <strong>
                                {{$datos->tramite->referencia}}
                            </strong>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-12">
                            <div class="table-responsive">
                                <table class="table mt-4 table-centered">
                                    <thead>
                                    <tr>
                                        <th>Copia</th>
                                        <th>Área de destino</th>
                                        <th>Usuario responsable</th>
                                        <th>Detalle</th>
                                        <th>Proveído</th>
                                        <th>Adjunto</th>
                                        <th>Estado</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($datos->tramite->derivaciones as $derivacion)
                                        <tr>
                                            <td>
                                                @if($derivacion->es_copia)
                                                    Copia
                                                @else
                                                    Original
                                                @endif
                                            </td>
                                            <td>
                                                @if($derivacion->areaDestino)
                                                    {{$derivacion->areaDestino->nombre}}
                                                @else
                                                    Sin área de destino
                                                @endif
                                            </td>
                                            <td>
                                                @if($derivacion->userDestino)
                                                    {{$derivacion->userDestino->infoUserYArea()}}
                                                @else
                                                    Sin responsable
                                                @endif
                                            </td>
                                            <td>
                                                {!! str_replace("\n","<br>",$derivacion->detalle) !!}
                                            </td>
                                            <td>
                                                {{$derivacion->proveido}}
                                            </td>
                                            <td>
                                                <a class="btn btn-primary waves-effect waves-light" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                                    Mostrar Adjuntos
                                                </a>
                                                <div class="collapse" id="collapseExample">
                                                    <div class="card-box">
                                                        <table class="table table-hover">
                                                            <thead>
                                                            <tr>
                                                                <th>Nombre de archivo</th>
                                                                <th>Fecha de agregado</th>
                                                            </tr>
                                                            </thead>
                                                            <tbody>
                                                            @forelse($derivacion->adjuntos as $adjunto)
                                                                <tr>
                                                                    <td>
                                                                        <a href="{{$adjunto->adjunto}}">
                                                                            {{$adjunto->nombre_adjunto}}</a>
                                                                    </td>
                                                                    <td>
                                                                        {{getFechaFormateada($adjunto->fecha_creado, 'l d M Y H:i')}}
                                                                    </td>
                                                                </tr>
                                                            @empty
                                                                <tr>
                                                                    Sin historial de adjuntos.
                                                                </tr>
                                                            @endforelse
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                {{$datos->estadosDerivacionDict[$derivacion->estado]}}
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div> <!-- end table-responsive -->
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                    <div class="row">
                        <div class="col-sm-6">
                        </div>
                        <div class="col-sm-6">
                            <div class="float-right">
                                <p><b>¿Es pago?</b>
                                @if($datos->tramite->codigo_pago)
                                    <h3>
                                        Sí - Código:
                                        {{$datos->tramite->codigo_pago}}
                                        <a href="{{$datos->tramite->adjunto_pago}}">Adjunto de pago</a>
                                    </h3>
                                @else
                                    <h3>
                                        No hubo pago
                                    </h3>
                                @endif
                            </div>
                            <div class="clearfix"></div>
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                    <div class="mt-4 mb-1">
                        <div class="text-right d-print-none">
                            <a href="javascript:window.print()" class="btn btn-primary waves-effect waves-light"><i
                                    class="mdi mdi-printer mr-1"></i> Imprimir</a>
                            {{-- <a href="#" class="btn btn-info waves-effect waves-light">Submit</a> --}}
                        </div>
                    </div>
                </div> <!-- end card-box -->
            </div> <!-- end col -->
        </div>
    </div>
@endsection
