@extends('layouts.home')
@section('titulo', 'Crear solicitud')
@section('contenido')

    <div class="container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Realizar una Solicitud</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-box">
                        <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Crear Solicitud</h5>

                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        @if(Session::has('NUMERO_TRAMITE'))
                            <div class="alert alert-success">
                                Su solicitud se ha registrado correctamente, y el número del trámite es el
                                siguiente {{Session::get('NUMERO_TRAMITE')}}
                            </div>
                        @endif

                        <form action="{{route('procesos.solicitudes.guardar')}}" method="post"
                              enctype="multipart/form-data">
                            @csrf


                            <div class="form-group mb-3">
                                <label for="tipo_solicitante">Tipo de solicitante
                                    <span class="text-danger">*</span>
                                </label>
                                <select name="tipo_solicitante" id="tipo_solicitante"
                                        class="form-control @error('tipo_solicitante') is-invalid @enderror">
                                    @foreach($datos->tiposSolicitante as $k => $v)
                                        <option
                                            value="{{$k}}"
                                            @if(old('tipo_solicitante', '') == $k)
                                            selected
                                            @endif
                                        >{{$v}}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group mb-3">
                                <label for="dato_identificacion">Documento de identificación
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="text" name="dato_identificacion"
                                       class="form-control @error('dato_identificacion') is-invalid @enderror"
                                       id="dato_identificacion" value="{{old('dato_identificacion', '')}}">
                                @error('dato_identificacion')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                                <ul>
                                    <li>Si es persona natural ingrese su DNI</li>
                                    <li>Si es persona jurídica ingrese su RUC</li>
                                    <li>Si es estudiante de la universidad ingrese su código</li>
                                </ul>
                            </div>

                            <div class="form-group mb-3">
                                <label for="SelectTipoSolicitud">Tipo de documento <span style="color:red">*</span></label>
                                <select name="tipo_solicitud_id" id="SelectTipoSolicitud"
                                        class="form-control custom-select2 @error('tipo_solicitud_id') is-invalid @enderror">
                                    <option
                                        value=""
                                        @if(old('tipo_solicitud_id') == '')
                                        selected="selected"
                                        @endif
                                    >Otro
                                    </option>
                                    @foreach($datos->tiposSolicitud as $tipo)
                                        <option value="{{$tipo->id}}"
                                                @if($tipo->id == old('tipo_solicitud_id', 0))
                                                selected
                                            @endif
                                        >{{$tipo->nombre_tipo}}</option>
                                    @endforeach
                                </select>
                                @error('tipo_solicitud_id')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div id="DivOtroTipoSolicitud" class="form-group mb-3" hidden>
                                <label for="otro_tipo_solicitud">Otro tipo documento <span style="color:red">*</span></label>
                                <input type="text" name="otro_tipo_solicitud"
                                       class="form-control @error('otro_tipo_solicitud') is-invalid @enderror"
                                       id="otro_tipo_solicitud">
                                @error('otro_tipo_solicitud')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group mb-3">
                                <label for="CheckIncluyePago">¿Realizó pago?</label>
                                <input type="checkbox" name="incluye_pago" id="CheckIncluyePago"
                                       class="@error('incluye_pago') is-invalid @enderror"
                                       @if(old('incluye_pago', false))
                                       checked="checked"
                                    @endif
                                >
                                @error('incluye_pago')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div id="DivCodigoPago" class="form-group mb-3" hidden>
                                <label for="codigo_pago">Código de pago <span style="color:red">*</span></label>
                                <input id="codigo_pago" type="text" name="codigo_pago"
                                       value="{{old('codigo_pago', '')}}"
                                       class="form-control @error('codigo_pago') is-invalid @enderror">
                                @error('codigo_pago')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div id="DivAdjuntoPago" class="form-group mb-3" hidden>
                                <label for="adjunto_pago">Adjunto de pago <span style="color:red">*</span></label>
                                <input id="adjunto_pago" type="file" name="adjunto_pago"
                                       value="{{old('adjunto_pago', '')}}"
                                       class="form-control-file @error('adjunto_pago') is-invalid @enderror">
                                @error('adjunto_pago')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group mb-3">
                                <label for="archivo_tramite">Archivo de trámite</label>
                                <input type="file" name="archivo_tramite"
                                       class="form-control-file @error('archivo_tramite') is-invalid @enderror">
                                <small>Archivos con extensión aceptados pdf,PDF,png,PNG,jpeg</small>
                                @error('archivo_tramite')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>

                            <div class="form-group mb-3">
                                <label for="detalle">Detalle <span style="color:red">*</span></label>
                                <textarea name="detalle" class="form-control"
                                          rows="10">{{old('detalle', '')}}</textarea>
                                @error('detalle')
                                <div class="invalid-feedback">
                                    {{ $message }}
                                </div>
                                @enderror
                            </div>


                            <button class="btn btn-primary">Enviar solicitud</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
