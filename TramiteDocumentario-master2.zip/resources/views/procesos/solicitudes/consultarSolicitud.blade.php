@extends('layouts.home')
@section('titulo', 'Consultar solicitud')
@section('contenido')

    <div class="container">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <h4 class="page-title">Consultar estado de solicitud</h4>
                        @if(Session::has('TRAMITE_NO_EXISTE'))
                            <div class="alert alert-danger" role="alert">
                                <i class="mdi mdi-block-helper mr-2"></i> El <strong>código</strong> del trámite no
                                existe
                            </div>
                        @endif
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-box">
                        <form action="{{ route('procesos.solicitudes.consultar') }}" method="get">
                            <div class="form-group">
                                <label for="numero_tramite">Ingrese código de la solicitud</label>
                                <input type="text" required name="numero_tramite" class="form-control"
                                       id="codigo_tramite">
                            </div>
                            <button class="btn btn-primary">Consultar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection
