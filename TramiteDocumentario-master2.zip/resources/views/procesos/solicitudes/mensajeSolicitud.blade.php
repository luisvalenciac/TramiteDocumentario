@extends('layouts.home')
@section('titulo', 'Crear solicitud')
@section('contenido')
    <div class="container">
        <div class="container-fluid">
            <div class="alert alert-warning">
                Lo sentimos :( , no se puede crear solicitudes en este momento.
                <a href="{{route('login.vistaLogin')}}">Regresar al login</a>
            </div>
        </div>
    </div>
@endsection
