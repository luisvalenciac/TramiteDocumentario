<form id="FormAdjuntar" action="{{route('procesos.derivaciones.adjuntar', ["derivacion" => $derivacion])}}"
      method="POST">
    @csrf
    <input type="hidden" name="id" value="{{$derivacion->id}}">
    <input type="hidden" name="estado" value="{{$derivacion->estado}}">

    <div class="modal-header">
        <h5 class="modal-title">Adjuntar archivo</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar"><span
                aria-hidden="true">&times;</span>
        </button>
    </div>

    <div class="modal-body">
        <div class="form-group">
            <label for="detalle">Detalle</label><br>
            <textarea class="form-control"
                      name="detalle" id="detalle" cols="30" rows="10">{{$derivacion->detalle}}</textarea>
            <span class="invalid-feedback" data-input-name="detalle"></span>
        </div>

        <div class="form-group">
            <p>
                <a class="btn btn-primary waves-effect waves-light" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    Ver historial de adjuntos
                </a>
            </p>
            <div class="collapse" id="collapseExample">
                <div class="card-box bg-light">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>Nombre de archivo</th>
                            <th>Fecha de agregado</th>
                            <th>Opciones</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($derivacion->adjuntos as $adjunto)
                            <tr>
                                <td>
                                    <a href="{{$adjunto->adjunto}}">{{$adjunto->nombre_adjunto}}</a>
                                </td>
                                <td>
                                    {{getFechaFormateada($adjunto->fecha_creado, 'l d M Y H:i')}}
                                </td>
                                <td>
                                    <div data-method="POST"
                                         data-action="{{ route('procesos.adjuntos.api.v1.eliminar',['adjunto' => $adjunto]) }}">
                                        <a href="#" class="btn btn-danger eliminar-adjunto">
                                            Eliminar
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                Sin historial de adjuntos.
                            </tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="form-group">
            <h4>Agregar más adjuntos</h4>
        </div>

        <div id="DivAddAjunto" class="form-row">
            <div class="col">
                <label for="nombre_adjunto">Nombre archivo</label>
                <input type="text" id="nombre_adjunto" required="required" class="form-control">
                <small>Una vez agregado debe seleccionar el archivo en la tabla</small>
            </div>
            <div class="col mt-3">
                <button id="BtnAddAdjunto" class="btn btn-outline-secondary">Agregar</button>
            </div>
        </div>

        <div class="form-group mt-2">
            <table id="TablaAdjuntos" class="table table-hover datatable">
                <thead>
                <tr>
                    <th>Nombre de adjunto</th>
                    <th>Adjunto</th>
                    <th>Opciones</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
            <span class="error" data-input-name="adjuntos" style="color: red"></span>
        </div>
    </div>

    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button id="BtnAdjuntar" class="btn btn-primary">Adjuntar</button>
    </div>
</form>
