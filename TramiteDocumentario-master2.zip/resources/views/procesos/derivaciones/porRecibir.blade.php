@extends('layouts.app')
@section('titulo', 'Por recibir - Derivaciones')
@section('contenido')

    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Trámites</a></li>
                        <li class="breadcrumb-item active">Trámites por recibir</li>
                    </ol>
                </div>
                <h4 id="TituloCrearTramite" class="page-title">Trámites por recibir</h4>

            </div>
        </div>
    </div>

    @include('partials.app.filtrosDerivaciones', ["estado" => derivacionTablaInfo()::ESTADO_POR_RECIBIR,
                                                "incluirArchivador" => false])

    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <table class="table table-hover datatable">
                    <thead>
                    <tr>
                        <th>Número y archivo de trámite</th>
                        <th>Prioridad</th>
                        <th>¿Es copia?</th>
                        <th>Usuario de origen</th>
                        <th>Fecha de emisión</th>
                        <th>Tipo de documento</th>
                        <th>Opciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($datos->derivaciones as $derivacion)
                        <tr>
                            <td>
                                {{$derivacion->tramite->numero_tramite}} -
                                @if($derivacion->tramite->archivo_tramite)
                                    <a href="{{$derivacion->tramite->archivo_tramite}}">Archivo</a>
                                @else
                                    Sin archivo
                                @endif
                            </td>
                            <td>{{$datos->prioridadDict[$derivacion->tramite->prioridad]}}</td>
                            <td>
                                @if($derivacion->es_copia)
                                    Sí
                                @else
                                    No
                                @endif
                            </td>
                            <td>{{$derivacion->tramite->userOrigen->infoUserYArea()}}</td>
                            <td>{{getFechaFormateada($derivacion->tramite->fecha_emision, 'd/m/Y')}}</td>
                            <td>
                                @if($derivacion->tramite->tipoSolicitud)
                                    {{$derivacion->tramite->tipoSolicitud->nombre_tipo}}
                                @else
                                    Otro: {{$derivacion->tramite->otro_tipo_solicitud}}
                                @endif
                            </td>
                            <td>
                                <div class="form-row">
                                    <div class="form-group col-md-4">
                                        @can('verDetalleTramite', $derivacion->tramite)
                                        <a href="{{ route('procesos.tramites.detalle', ['tramite' => $derivacion->tramite]) }}"
                                           class="btn btn-success waves-effect waves-light">
                                            Detalle
                                        </a>
                                        @endcan
                                    </div>
                                    @if($derivacion->es_copia && !request()->user()->esAdminSistema())
                                        <span
                                            class="badge badge-soft-blue badge-pill">Solo se puede modificar el original</span>
                                    @else
                                    <div class="form-group col-md-4">
                                        <a data-toggle="modal" data-target="#ModalTemplate"
                                        href="{{route('procesos.derivaciones.vistaAtender', ["derivacion" => $derivacion])}}"
                                        class="btn btn-info atender-derivacion">
                                            Atender
                                        </a>
                                    </div>
                                    <div class="form-group col-md-4">
                                        <a data-toggle="modal" data-target="#ModalTemplate"
                                        href="{{route('procesos.derivaciones.vistaDerivar', ["derivacion" => $derivacion])}}"
                                        class="btn btn-primary derivar-derivacion">
                                            Derivar
                                        </a>
                                    </div>
                                    @endif
                                </div>
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    {{$datos->derivaciones->withQueryString()->links()}}

@endsection
