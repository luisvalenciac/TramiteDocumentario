<form id="FormRecepcionarDerivacion"
      action="{{route('procesos.derivaciones.recepcionar', ["derivacion" => $derivacion])}}"
      method="POST">
    @csrf

    <input type="hidden" name="id" value="{{$derivacion->id}}">
    <input type="hidden" name="estado" value="{{derivacionTablaInfo()::ESTADO_POR_RECIBIR}}">
    <input type="hidden" name="user_destino_id" value="{{request()->user()->id}}">

    <div class="modal-header">
        <h5 class="modal-title">Recepcionar trámite N° {{$derivacion->tramite->numero_tramite}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar"><span
                aria-hidden="true">&times;</span>
        </button>
    </div>

    <div class="modal-body">
        <div class="form-group">
            <label for="UserOrigen">Firma - Usuario de origen</label>
            <input type="text" id="UserOrigen" readonly class="form-control"
                   value="{{$derivacion->tramite->userOrigen->infoUserYArea()}}">
        </div>
        <div class="form-group">
            <label for="proveido">Proveido<span style="color: red">*</span></label><br>
            <input class="form-control" name="proveido" id="proveido" value="{{$derivacion->proveido}}"/>
            <span class="invalid-feedback" data-input-name="proveido"></span>
        </div>
        <div class="form-group">
            <label for="detalle">Detalle<span style="color: red">*</span></label><br>
            <textarea class="form-control"
                      name="detalle" id="detalle" cols="30" rows="10">{{$derivacion->detalle}}</textarea>
            <span class="invalid-feedback" data-input-name="detalle"></span>
        </div>

        <span class="error" data-input-name="user_destino_id" style="color: red"></span>
    </div>

    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button id="BtnRecepcionarDerivacion" class="btn btn-primary">Recepcionar trámite</button>
    </div>
</form>
