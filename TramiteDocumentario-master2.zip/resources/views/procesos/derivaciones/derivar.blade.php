<form id="FormDerivar" action="{{route('procesos.derivaciones.derivar',
                                            ["derivacion" => $derivacion])}}" method="POST">
    @csrf
    <input type="hidden" name="id" value="{{$derivacion->id}}">
    
    <div class="modal-header">
        <h5 class="modal-title">Derivar a otra área</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar"><span
                aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
        <div class="form-group">
            <label for="UserOrigen">Firma - Usuario de origen</label>
            <input type="text" id="UserOrigen" readonly class="form-control"
                   value="{{$derivacion->tramite->userOrigen->infoUserYArea()}}">
        </div>
        <div class="form-group">
            <label for="SelectAreaDestino">Area de destino <span class="text-danger">*</span></label>
            <select id="SelectAreaDestino" class="form-control"
                    name="area_destino_id"
                    data-placeholder="Seleccione unidad orgánica de destino">
                @foreach($areas as $area)
                    <option value="{{$area->id}}">
                        {{$area->nombre}}
                    </option>
                @endforeach
            </select>
            <span class="invalid-feedback" data-input-name="area_destino_id"></span>
        </div>
        <div class="form-group">
            <label for="SelectUserResponsable">Usuario responsable <span
                    class="text-danger">*</span></label>
            <select name="user_destino_id" id="SelectUserResponsable"
                    data-placeholder="Seleccione usuario responsable"
                    class="form-control"
                    data-buscar-user-url="{{route('administracion.usuarios.api.v1.buscar')}}">
            </select>
            <span class="invalid-feedback" data-input-name="user_destino_id"></span>
        </div>
        <div class="form-group">
            <label for="detalle">Detalle</label><br>
            <textarea class="form-control"
                      name="detalle" id="detalle" cols="30" rows="10">{{$derivacion->detalle}}</textarea>
            <span class="invalid-feedback" data-input-name="detalle"></span>
        </div>
        <div class="form-group">
            <label for="proveido">Proveido<span style="color: red">*</span></label><br>
            <input class="form-control" name="proveido" id="proveido" value="{{$derivacion->proveido}}"/>
            <span class="invalid-feedback" data-input-name="proveido"></span>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button id="BtnDerivar" class="btn btn-primary">Derivar</button>
    </div>
</form>
