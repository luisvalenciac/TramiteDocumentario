@extends('layouts.app')
@section('titulo', 'Usuarios')
@section('contenido')

    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <h4 class="page-title">Cambiar configuración de solicitudes</h4>
            </div>
        </div>
    </div>

    <div class="row-12">
        <form action="{{route('configuracion.tramites.guardarConfigTramite')}}" method="POST">
            @csrf
            <div class="card-box">
                <div class="row">
                    <div class="alert alert-info">
                        Esta configuración permite definir un usuario responsable para las solicitudes que se
                        crean por usuarios externos a la aplicación
                    </div>
                </div>
                @if ($errors->any())
                    <div class="row">
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    </div>
                @endif
                <div class="form-group mb-3">
                    <label for="SelectBuscarUser">Usuario responsable</label>
                    <select name="user_recibe_solicitud_id" id="SelectBuscarUser"
                            data-placeholder="Busque por username, DNI, nombres, apellidos, correo y username"
                            data-allow-clear="true"
                            class="form-control @error('user_recibe_solicitud_id') is-invalid @enderror"
                            data-buscar-user-url="{{route('administracion.usuarios.api.v1.buscar')}}">
                        <option></option>
                        @if($configTramite->userRecibeSolicitud)
                            <option selected value="{{$configTramite->userRecibeSolicitud->id}}">
                                {{$configTramite->userRecibeSolicitud->infoUserYArea()}}
                            </option>
                        @endif
                    </select>
                    @error('user_recibe_solicitud_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
                <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </form>
    </div>

@endsection
