import axiosWrapper from "../utils/request";

$(function () {

    let formCrearUser = $("#FormCrearUser");

    formCrearUser.on('change', 'input[id=dni]', function (e) {
        const url = $("#url-consulta-reniec").val();

        axiosWrapper({
            thenFunc: res => mostrarDatosDePersona(res),
            loadElem: $("#TituloCrearUser"),
            url: url,
            data: {
                dni: $(this).val()
            },
            form: formCrearUser,
            method: "POST"
        });
    });

    function mostrarDatosDePersona(response) {
        const data = response.data;
        formCrearUser.find('input[id=nombres]').val(data.nombres);
        formCrearUser.find('input[id=apellidos]').val(data.apellidos);
    }
});


