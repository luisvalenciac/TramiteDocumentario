import {selectTwoConfig} from "../utils/vendorWrappers";

export function configSelectBuscarUser(select) {

    select.select2(selectTwoConfig({
        url: select.attr('data-buscar-user-url'),
        templateResult: function (usuario) {
            if (usuario.loading)
                return "Buscando...";
            return $(`<label>${infoUser(usuario)}</label>`);
        },
        templateSelection: function (usuario) {
            if (usuario.id === '')
                return usuario.text;
            return usuario.nombres === undefined ? usuario.text : `${infoUser(usuario)}`;
        }
    }));
}

export function infoUser(user) {
    return `${user.nombres} ${user.apellidos} - Unidad orgánica: ${user.area ? user.area.nombre : "Sin unidad orgánica"}`;
}
