import axiosWrapper from "../utils/request";
import {getDivModal} from "../utils/utils";
import showAlert, {MESSAGE_TYPES} from "../utils/messages";
import {selectTwoConfig} from "../utils/vendorWrappers";
import {configUserDerivado} from "../tramites/tramites-extracted-functions";


$(function () {

    let divModal = getDivModal();

    $("a.recepcionar-derivacion").click(function (e) {
        e.preventDefault();
        cargarVistaModal($(this));
    });

    $("a.atender-derivacion").click(function (e) {
        e.preventDefault();
        cargarVistaModal($(this));
    });

    $("a.derivar-derivacion").click(function (e) {
        e.preventDefault();
        cargarVistaModal($(this), configSelectUserResponsable);
    });

    function configSelectUserResponsable(res) {
        let selectAreaDestino = $("#SelectAreaDestino");
        let selectUserResponsable = $("#SelectUserResponsable");
        configUserDerivado(selectAreaDestino, selectUserResponsable);
    }

    $("a.adjuntar-derivacion").click(function (e) {
        e.preventDefault();
        cargarVistaModal($(this));
    });

    $("a.archivar-derivacion").click(function (e) {
        e.preventDefault();
        cargarVistaModal($(this), () => configSelectArchivador($("#SelectArchivador")));
    });

    $("a.desantender-derivacion").click(function (e) {
        e.preventDefault();
        cargarVistaModal($(this));
    });

    $("a.regresar-estado-derivacion").click(function (e) {
        e.preventDefault();
        cargarVistaModal($(this));
    });

    function cargarVistaModal(elem, thenFunc = () => null) {
        axiosWrapper({
            method: "GET",
            url: elem.attr('href'),
            loadElem: elem,
            beforeFunc: () => divModal.html(""),
            thenFunc: res => {
                divModal.html(res.data);
                thenFunc(res);
            },
            errorFunc: err => showAlert("Ha ocurrido un error.", MESSAGE_TYPES.DANGER, divModal)
        });
    }

    configSelectArchivador($("#SelectArchivador"));
});


function configSelectArchivador(select) {
    select.select2(selectTwoConfig({
        url: select.attr('data-buscar-archivador-url'),
        minInputLength: 0,
        templateResult: function (archivador) {
            if (archivador.loading)
                return "Buscando...";
            return $(`<label>${getInfoArchivador(archivador)}</label>`);
        },
        templateSelection: function (archivador) {
            if (archivador.id === '')
                return archivador.text;
            return archivador.nombre === undefined ? archivador.text : `${getInfoArchivador(archivador)}`;
        }
    }));
}

function getInfoArchivador(archivador) {
    return `${archivador.nombre} - ${archivador.periodo}`;
}

