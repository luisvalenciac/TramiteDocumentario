var Chart = require('chart.js');
var moment = require('moment');
var _ = require('lodash');

const ESTADOS = {
    por_atender: 'Por atender',
    por_recibir: 'Por recibir',
    archivado: 'Archivado',
    atendido: 'Atendido'
}

const COLORES = {
    por_recibir: '#E9724C',
    por_atender: '#2EBBDB',
    archivado: '#9FD8CB',
    atendido: '#CACFD6'
}

$(function () {
    graficoCircular();
    graficoDeBarras();
})


function obtenerDatos(id) {
    let data = document.getElementById(id) || {};
    return JSON.parse(data.value || "{}");
}

function graficoCircular() {
    const datos = obtenerDatos('GraficoCircularDatos');
    if (Object.keys(datos).length) {
        const options = {
            type: 'pie',
            options: {
                responsive: true,
                title: {
                    display: true,
                    text: 'Estado de trámites de los últimos 30 días'
                }
            },
            data: {
                datasets: [{
                    data: Object.keys(datos).map(key => datos[key]),
                    backgroundColor: Object.keys(datos).map(key => COLORES[key]),
                }],
                labels: Object.keys(datos).map(key => ESTADOS[key])
            },
        };
        crearGrafico('GraficoCircular', options);
    }
}

function graficoDeBarras() {

    const datos = obtenerDatos('GraficoDeBarrasDatos');
    if (Object.keys(datos).length) {
        var options = {
            type: 'bar',
            options: {
                responsive: true,
                legend: {
                    position: 'bottom',
                },
                title: {
                    display: true,
                    text: 'Estado de trámites de los últimos meses'
                }
            },
            data: {
                labels: datos.meses,
                datasets: Object.keys(ESTADOS).map(key => {
                    return {
                        label: ESTADOS[key],
                        backgroundColor: COLORES[key],
                        borderColor: COLORES[key],
                        data: datos[key]
                    }
                })
            }
        };

        crearGrafico('GraficoDeBarras', options);
    }
}

function crearGrafico(canvasId, options) {
    const contexto = document.getElementById(canvasId);
    var grafico = new Chart(contexto, options);
}
