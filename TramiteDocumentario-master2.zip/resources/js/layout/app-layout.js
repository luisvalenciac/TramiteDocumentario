import {cargarTabla} from "../utils/vendorWrappers";
import showAlert from "../utils/messages";
import {toggleVisibilidad} from "../utils/utils";
import {configSelectBuscarUser} from "../usuarios/users-extracted-functions";

$(function () {

    $("#LinkCerrarSesion").click(function (e) {
        e.preventDefault();
        $("#FormCerrarSesion").submit();
    });

    cargarTabla($(".datatable"));

    $(".custom-select2").select2();

    $("#BtnOcultarFiltros").click(function (e) {
        e.preventDefault();
        toggleVisibilidad($("#DivFiltros"));
    });

    configSelectBuscarUser($("#SelectBuscarUser"));
});


$(document).ready(function () {
    let msg = window.sessionStorage.getItem('msg');
    if (msg) {
        showAlert(msg);
        window.sessionStorage.removeItem('msg');
    }
});
