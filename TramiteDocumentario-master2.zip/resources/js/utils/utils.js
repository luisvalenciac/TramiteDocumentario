function toggleElement(element, checkCallback, nonCheckCallback) {
    let isChecked = element.prop("checked");
    if (isChecked) {
        element.val("1");
        checkCallback();
    } else {
        element.val("0");
        nonCheckCallback();
    }
}

export function configToggle(element, callbackChecked = () => {
}, callbackNonChecked = () => {
}) {
    toggleElement(element, callbackChecked, callbackNonChecked);
    element.change(function () {
        if ($(this).prop('checked')) {
            $(this).val("1");
            callbackChecked();
        } else {
            $(this).val("0");
            callbackNonChecked();
        }
    });
}

export function configByCheckVisibility(checkElem, div) {
    configToggle(checkElem,
        () => hacerVisible(div),
        () => hacerVisible(div, false));
}

export function getDivModal() {
    return $("#ContenidoModal");
}

export function toggleVisibilidad(elem) {
    if (elem.is(':visible'))
        elem.attr('hidden', 'hidden');
    else
        elem.removeAttr('hidden');
}

export function hacerVisible(elem, visible = true) {
    if (visible)
        elem.removeAttr('hidden');
    else
        elem.attr('hidden', 'hidden');

}

export function removerCssYHtml(elem) {
    elem.html("");
    elem.removeClass();
}
