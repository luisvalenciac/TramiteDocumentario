$(document).ready(function () {
    let formCrearRol = $("#FormRol");
    let inputNombreClave = formCrearRol.find("input[id=name]");

    formCrearRol.on('keyup', 'input[id=display_name]', function (e) {
        let nombre = $(this).val();
        if (nombre) {
            nombre = nombre.toLowerCase()
                .normalize("NFD")
                .replace(/[\u0300-\u036f]/g, "")
                .replaceAll(" ", "_");
            inputNombreClave.val(nombre)
        } else
            inputNombreClave.val("");
    });
});

