import {infoUser} from "../usuarios/users-extracted-functions";
import {selectTwoConfig} from "../utils/vendorWrappers";
import {hacerVisible} from "../utils/utils";

export function configUserDerivado(selectAreaDestino, selectUserResponsable) {

    selectAreaDestino.select2();

    selectUserResponsable.select2(selectTwoConfig({
        url: () => getUrlForBusqueda(getAreaFromSelect()),
        minInputLength: 0,
        templateResult: function (usuario) {
            if (usuario.loading)
                return "Buscando...";
            return $(`<label>${infoUser(usuario)}</label>`);
        },
        templateSelection: function (usuario) {
            if (usuario.id === '')
                return usuario.text;
            return usuario.nombres === undefined ? usuario.text : `${infoUser(usuario)}`;
        }
    }));

    function getUrlForBusqueda(area = {}) {
        let baseUrl = `${selectUserResponsable.attr('data-buscar-user-url')}`;
        let queryParams = `area=${area.id ?? ""}`;
        return `${baseUrl}?${queryParams}`;
    }

    function getAreaFromSelect() {
        let areas = selectAreaDestino.select2('data');
        if (areas && areas.length)
            return areas[0];
        return {};
    }
}


export function configCamposOtroTipoSolicitud(selectTipoSolicitud, divOtroTipoSolicitud) {

    selectTipoSolicitud.change(function (e) {
        configVisibility();
    });

    function configVisibility() {
        if (selectTipoSolicitud.val() === '')
            hacerVisible(divOtroTipoSolicitud);
        else
            hacerVisible(divOtroTipoSolicitud, false);
    }

    configVisibility();
}
