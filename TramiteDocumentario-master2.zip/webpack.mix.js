
const mix = require('laravel-mix');

const folder = {
    src: "resources/",
    dist: "public/",
    dist_assets: "public/assets/"
};

mix.sourceMaps(false);

var third_party_js = [
    "./node_modules/jquery/dist/jquery.js",
    "./node_modules/bootstrap/dist/js/bootstrap.bundle.min.js",
    "./node_modules/simplebar/dist/simplebar.min.js",
    "./node_modules/node-waves/dist/waves.min.js",
    "./node_modules//waypoints/lib/jquery.waypoints.min.js",
    "./node_modules/jquery.counterup/jquery.counterup.min.js",
    "./node_modules/feather-icons/dist/feather.js",
];

mix.combine(third_party_js, folder.dist_assets + "js/vendor.js").minify(folder.dist_assets + "js/vendor.js");

var out = folder.dist_assets + "fonts";
mix.copyDirectory(folder.src + "fonts/", out);

out = folder.dist_assets + "images";
mix.copyDirectory(folder.src + "images/", out);


mix.js('resources/js/app.js', 'public/js')
    .sass('resources/sass/app.scss', 'public/css');

mix.js('resources/js/home.js', 'public/js')
    .sass('resources/sass/home.scss', 'public/css');