<?php

namespace App\Services;

use App\Contracts\ConfigTramiteRepository;
use App\Models\ConfigTramite;
use App\TablaInfo\ConfigTramiteTablaInfo;
use Illuminate\Support\Facades\DB;

class ConfigTramiteService implements ConfigTramiteRepository
{

    public function actualizarConfig($datos)
    {
        DB::table(ConfigTramiteTablaInfo::NOMBRE_TABLA)
            ->where(ConfigTramiteTablaInfo::CONFIG_KEY, '=', ConfigTramiteTablaInfo::KEY_VALUE)
            ->update($datos);
        return $this->getConfigTramite();
    }

    public function getConfigTramite()
    {
        $configTramite = ConfigTramite::where(ConfigTramiteTablaInfo::CONFIG_KEY, ConfigTramiteTablaInfo::KEY_VALUE)
            ->first();
        if ($configTramite)
            return $configTramite;
        return $this->crearConfigTramite();
    }

    public function existeUserConfigTramite()
    {
        $configTramite = ConfigTramite::where(ConfigTramiteTablaInfo::CONFIG_KEY, ConfigTramiteTablaInfo::KEY_VALUE)
            ->first();
        return isset($configTramite->userRecibeSolicitud);
    }

    private function crearConfigTramite()
    {
        return ConfigTramite::create([
            ConfigTramiteTablaInfo::CONFIG_KEY => ConfigTramiteTablaInfo::KEY_VALUE
        ]);
    }

}
