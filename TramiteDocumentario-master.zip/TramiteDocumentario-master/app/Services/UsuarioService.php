<?php

namespace App\Services;

use App\Config\Permisos\DefaultRoles;
use App\Contracts\AreaRepository;
use App\Contracts\ReniecRepository;
use App\Contracts\UsuarioRepository;
use App\Models\Usuario;
use App\TablaInfo\RolTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class UsuarioService implements UsuarioRepository
{
    private $reniecService;
    private $areaService;

    public function __construct(ReniecRepository $reniecService, AreaRepository $areaService)
    {
        $this->reniecService = $reniecService;
        $this->areaService = $areaService;
    }

    public function usersFiltrados($request, $cantidad = 15)
    {
        $users = $this->getUsersPorRol()->filter($request->all());
        if ($cantidad == '*')
            return $users;
        return $users->paginate($cantidad);
    }

    public function crear($datos)
    {
        $user = Usuario::create($datos);
        $this->asignarRol($user, $datos[UsuarioTablaInfo::ROL]);
        return $user;
    }

    public function actualizar($user, $datos)
    {
        $user->update($datos);
        $this->asignarRol($user, $datos[UsuarioTablaInfo::ROL]);
        return $user;
    }

    public function deshabilitar($user)
    {
        $user->update([UsuarioTablaInfo::ESTA_ACTIVO => !$user->esta_activo]);
        return $user;
    }

    public function buscarPor($attr, $valor, $buscarEnTodos = '*')
    {
        if ($buscarEnTodos == '*')
            return $this->getBaseUsers()->where($attr, '=', $valor)->first();
        return $this->getUsersPorRol()->where($attr, '=', $valor)->first();
    }


    public function asignarRol($user, $rol)
    {
        foreach ($user->roles as $r)
            $user->removeRole($r);
        $user->assignRole($rol);
        return $user->save();
    }

    public function getUsersPorRol()
    {
        $baseUsers = $this->getBaseUsers();
        if (Auth::user()->hasRole(DefaultRoles::ADMIN_SISTEMA))
            return $baseUsers;
        return $baseUsers->whereIn(UsuarioTablaInfo::ID, $this->getIdNormalUsers());
    }

    public function buscarPorTermino($request, $cantidad = 15)
    {
        $termino = $request->query('q', '');
        return $this->usersFiltrados($request, '*')
            ->where(function ($query) use ($termino) {
                $query->where(UsuarioTablaInfo::CORREO, 'LIKE', "%{$termino}%")
                    ->orWhere(UsuarioTablaInfo::USERNAME, 'LIKE', "%{$termino}%")
                    ->orWhere(UsuarioTablaInfo::NOMBRES, 'LIKE', "%{$termino}%")
                    ->orWhere(UsuarioTablaInfo::APELLIDOS, 'LIKE', "%{$termino}%")
                    ->orWhere(UsuarioTablaInfo::DNI, '=', "{$termino}");
            })
            ->paginate($cantidad);
    }

    private function getIdNormalUsers()
    {
        return Usuario::select(UsuarioTablaInfo::ID)
            ->whereHas(RolTablaInfo::nombreTabla(), function ($query) {
                return $query->where(RolTablaInfo::NOMBRE, '!=', DefaultRoles::ADMIN_SISTEMA);
            });
    }

    private function getBaseUsers()
    {
        return Usuario::with(['area'])->orderBy(UsuarioTablaInfo::FECHA_CREADO, 'DESC');
    }

    public function count()
    {
        return $this->getUsersPorRol()->count();
    }
}
