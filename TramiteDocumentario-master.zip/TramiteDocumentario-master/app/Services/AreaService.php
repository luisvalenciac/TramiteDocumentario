<?php


namespace App\Services;

use App\Contracts\AreaRepository;
use App\Models\Area;
use App\TablaInfo\AreaTablaInfo;
use Illuminate\Support\Facades\Log;

class AreaService implements AreaRepository
{
    public function areasFiltradas($request, $cantidad = 15)
    {
        $areas = $this->areas()->filter($request->all());
        if ($cantidad == '*')
            return $areas;
        return $areas->paginate($cantidad);
    }

    public function crear($datos)
    {
        return Area::create($datos);
    }

    public function actualizar($area, $datos)
    {
        $area->update($datos);
        return $area;
    }

    public function eliminar($area)
    {
        $area->delete();
        return $area;
    }

    public function buscar($termino)
    {
        return $this->areas()
            ->where(AreaTablaInfo::NOMBRE, 'LIKE', "%{$termino}%")
            ->orWhere(AreaTablaInfo::ABREVIATURA, 'LIKE', "%{$termino}%")
            ->orWhere(AreaTablaInfo::ID, '=', "{$termino}")
            ->paginate(10);
    }

    public function buscarPor($attr, $valor)
    {
        return $this->areas()->where($attr, '=', $valor)->first();
    }

    public function areaTramiteDocumentario()
    {
        return $this->buscarPor(AreaTablaInfo::NOMBRE, AreaTablaInfo::NOMBRE_AREA_POR_DEFECTO);
    }

    public function areas()
    {
        return Area::with(['responsable'])->orderBy(AreaTablaInfo::FECHA_CREADO, 'DESC');
    }
}
