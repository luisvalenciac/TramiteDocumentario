<?php

namespace App\Services;

use App\Contracts\AdjuntoRepository;
use App\Contracts\ArchivoRepository;
use App\Models\Adjunto;
use App\TablaInfo\AdjuntoTablaInfo;

class AdjuntoService implements AdjuntoRepository
{
    private const CARPETA_ADJUNTOS = 'adjuntos';

    private $archivoService;

    public function __construct(ArchivoRepository $archivoService)
    {
        $this->archivoService = $archivoService;
    }

    public function eliminar(Adjunto $adjunto)
    {
        $adjunto->delete();
        return $adjunto;
    }

    public function crearAdjuntos($derivacion, $datos)
    {
        for ($i = 0; $i < count($datos); $i++) {
            $datos[$i][AdjuntoTablaInfo::DERIVACION_ID] = $derivacion->id;
            $this->crearAdjunto($datos[$i]);
        }
    }

    private function crearAdjunto($datos)
    {
        $this->archivoService->saveArchivosFromDatos($datos, [AdjuntoTablaInfo::ADJUNTO],
            self::CARPETA_ADJUNTOS);
        Adjunto::create($datos);
    }
}
