<?php

namespace App\Services;

use App\Contracts\ArchivoRepository;
use App\Contracts\DerivacionRepository;
use App\Contracts\TramiteRepository;
use App\Contracts\UsuarioRepository;
use App\Models\Tramite;
use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\TablaInfo\TramiteTablaInfo as TramiteAttr;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;

class TramiteService implements TramiteRepository
{
    private const CARPETA_TRAMITES = 'tramites';
    private $archivoService;
    private $userService;
    private $derivacionService;

    public function __construct(ArchivoRepository $archivoService, UsuarioRepository $userService,
                                DerivacionRepository $derivacionService)
    {
        $this->archivoService = $archivoService;
        $this->userService = $userService;
        $this->derivacionService = $derivacionService;
    }

    public function tramitesFiltrados($request, $cantidad = 15)
    {
        $tramites = $this->tramitesCreadosLoggedUser()->filter($request->all());
        if ($cantidad == '*')
            return $tramites;
        return $tramites->paginate($cantidad);
    }

    public function crearTramite($datosRequest)
    {
        $tramite = $this->crearTramiteWrapper($datosRequest);
        $derivaciones = Arr::pull($datosRequest, TramiteAttr::DERIVACIONES, []);
        $this->derivacionService->crearDerivaciones($tramite, $derivaciones);
        return $tramite;
    }

    public function buscarPor($attr, $valor, $buscarEnTodos = '*')
    {
        if ($buscarEnTodos == '*')
            return $this->getBaseTramites()->where($attr, '=', $valor)->first();
        return $this->tramitesCreadosLoggedUser()->where($attr, '=', $valor)->first();
    }

    public function ultimoTramite()
    {
        return Tramite::latest()->first();
    }

    public function generarNumeroTramite()
    {
        $ultimoTramite = $this->ultimoTramite();
        return isset($ultimoTramite) ? $ultimoTramite->numero_tramite + 1 : 1;
    }

    private function tramitesCreadosLoggedUser()
    {
        $loggedUser = Auth::user();
        if ($loggedUser->esAdminSistema())
            return $this->getBaseTramites();
        if ($loggedUser->esResponsableArea())
            return $this->getTramitesUserResponsable($loggedUser);
        return $this->getBaseTramites()->where(TramiteAttr::USER_EXPEDIENTE_ID, '=', $loggedUser->id);
    }

    private function getTramitesUserResponsable($loggedUser)
    {
        return $this->getBaseTramites()->whereHas('userOrigen', function (Builder $query) use ($loggedUser) {
            $query->whereHas('area', function (Builder $subQuery) use ($loggedUser) {
                $subQuery->where(AreaTablaInfo::ID, '=', $loggedUser->area->id);
            });
        });
    }

    private function getBaseTramites()
    {
        return Tramite::orderBy(TramiteAttr::FECHA_CREADO, 'DESC');
    }

    private function crearTramiteWrapper($datos)
    {
        $this->setNumeroTramite($datos);
        $this->guardarArchivos($datos, [TramiteAttr::ARCHIVO_TRAMITE, TramiteAttr::ADJUNTO_PAGO]);
        return Tramite::create($datos);
    }

    private function setNumeroTramite(&$datos)
    {
        if (Auth::user() && Auth::user()->esAdminSistema())
            $datos[TramiteAttr::NUMERO_TRAMITE] = $this->generarNumeroTramite();
    }

    private function guardarArchivos(&$datos, $keys)
    {
        $this->archivoService->saveArchivosFromDatos($datos, $keys, self::CARPETA_TRAMITES);
    }
}
