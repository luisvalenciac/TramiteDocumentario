<?php

namespace App\Services;

use App\Contracts\HistorialCambioEstadoRepository;
use App\Models\HistorialCambioEstado;
use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\HistorialCambioEstadoTablaInfo as HistorialCambioAttr;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

class HistorialCambioEstadoService implements HistorialCambioEstadoRepository
{

    public function registrarCambio($derivacionId, $estadoInicial, $estadoFinal)
    {
        return HistorialCambioEstado::updateOrCreate(
            [HistorialCambioAttr::DERIVACION_ID => $derivacionId],
            [
                HistorialCambioAttr::CAMBIADO_DE => $estadoInicial,
                HistorialCambioAttr::CAMBIADO_HACIA => $estadoFinal,
                HistorialCambioAttr::FECHA_DE_CAMBIO => getFechaFormateada(now(), 'Y-m-d')
            ]
        );
    }

    public function statsDerivacion($fechaInicio, $fechaFin, $estado)
    {
        return $this->getHistoriales(Auth::user(), $estado)
            ->whereDate(HistorialCambioAttr::FECHA_DE_CAMBIO, '>=', $fechaInicio)
            ->whereDate(HistorialCambioAttr::FECHA_DE_CAMBIO, '<=', $fechaFin)
            ->count();
    }

    private function getHistoriales($user, $estado)
    {
        if ($estado == DerivacionTablaInfo::ESTADO_POR_ATENDER)
            return $this->getHistorialPorAtender($user);
        return $this->getHistorialPorUser($user, $estado);
    }


    private function getHistorialPorAtender($user)
    {
        $baseQuery = HistorialCambioEstado::where(HistorialCambioAttr::CAMBIADO_HACIA, '=', DerivacionTablaInfo::ESTADO_POR_ATENDER);
        if ($user->esAdminSistema())
            return $baseQuery;
        if ($user->esResponsableArea())
            return $baseQuery
                ->whereHas('derivacion', function (Builder $derivacionQuery) use ($user) {
                    $derivacionQuery
                        ->where(function (Builder $builder) {
                            $builder->whereNull(DerivacionTablaInfo::USER_DESTINO_ID)
                                ->whereNull(DerivacionTablaInfo::AREA_DESTINO_ID);
                        })
                        ->whereHas('tramite', function (Builder $tramiteQuery) use ($user) {
                            $tramiteQuery->whereHas('userOrigen', function (Builder $userQuery) use ($user) {
                                $userQuery->whereHas('area', function (Builder $areaQuery) use ($user) {
                                    $areaQuery->where(AreaTablaInfo::ID, '=', $user->area->id);
                                });
                            });
                        });
                });
        return $baseQuery
            ->whereHas('derivacion', function (Builder $derivacionQuery) use ($user) {
                $derivacionQuery
                    ->where(function (Builder $builder) {
                        $builder->whereNull(DerivacionTablaInfo::USER_DESTINO_ID)
                            ->whereNull(DerivacionTablaInfo::AREA_DESTINO_ID);
                    })
                    ->whereHas('tramite', function (Builder $tramiteQuery) use ($user) {
                        $tramiteQuery->whereHas('userOrigen', function (Builder $userQuery) use ($user) {
                            $userQuery->where(UsuarioTablaInfo::ID, '=', $user->id);
                        });
                    });
            });
    }

    private function getHistorialPorUser($user, $estado)
    {
        $baseQuery = HistorialCambioEstado::where(HistorialCambioAttr::CAMBIADO_HACIA, '=', $estado);
        if ($user->esAdminSistema())
            return $baseQuery;
        if ($user->esResponsableArea())
            return $baseQuery
                ->whereHas('derivacion', function (Builder $derivacionQuery) use ($user) {
                    $derivacionQuery->where(DerivacionTablaInfo::AREA_DESTINO_ID, '=', $user->area->id);
                });
        return $baseQuery
            ->whereHas('derivacion', function (Builder $derivacionQuery) use ($user) {
                $derivacionQuery->where(DerivacionTablaInfo::USER_DESTINO_ID, '=', $user->id);
            });
    }
}
