<?php


namespace App\Exports;


use App\Wrappers\Vistas\DatosTablaExportarDerivaciones;
use Maatwebsite\Excel\Facades\Excel;

class ExcelDerivacionExport implements ArchivoExport
{
    public function download(DatosTablaExportarDerivaciones $datos)
    {
        return Excel::download(new DerivacionExport($datos), 'tramites_exportados.xlsx', \Maatwebsite\Excel\Excel::XLSX);
    }
}
