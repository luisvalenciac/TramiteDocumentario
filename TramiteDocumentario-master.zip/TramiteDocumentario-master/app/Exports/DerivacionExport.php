<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithDrawings;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Events\AfterSheet;
use Maatwebsite\Excel\Excel;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;


class DerivacionExport implements FromView, ShouldAutoSize, WithStyles, WithEvents, WithDrawings
{
    const EXT_PDF = 'pdf';
    const EXT_EXCEL = 'xlsx';

    private $datosVista;

    public function __construct($datosVista)
    {
        $this->datosVista = $datosVista;
    }

    static function getSopportedExtensions()
    {
        return [
            self::EXT_EXCEL => 'Excel',
            self::EXT_PDF => 'PDF',
        ];
    }

    static function getExplicitExtensionsWriter()
    {
        return [
            self::EXT_EXCEL => Excel::XLSX,
            self::EXT_PDF => Excel::DOMPDF,
        ];
    }

    public function view(): View
    {
        return view('procesos.derivaciones.tablaExportarDerivaciones', ["datos" => $this->datosVista]);
    }

    public function drawings()
    {
        $escudoRepublica = new Drawing();
        $escudoRepublica->setName('EscudoRepublica');
        $escudoRepublica->setDescription('Escudo de la Republica del Perú');
        $escudoRepublica->setPath(public_path('assets/images/reportes/escudo_republica.png'));
        $escudoRepublica->setHeight(65);
        $escudoRepublica->setCoordinates('A2');

        $logoUnach = new Drawing();
        $logoUnach->setName('UNACH');
        $logoUnach->setDescription('UNACH');
        $logoUnach->setPath(public_path('assets/images/reportes/logo_unach.png'));
        $logoUnach->setHeight(65);
        $logoUnach->setCoordinates('M2');

        return [$escudoRepublica, $logoUnach];
    }

    public function styles(Worksheet $sheet)
    {
        $sheet->setTitle("Trámites");
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => [self::class, 'afterSheet'],
        ];
    }

    public static function afterSheet(AfterSheet $event)
    {
        $event->sheet->getDelegate()->getPageSetup()
            ->setOrientation(PageSetup::ORIENTATION_LANDSCAPE)
            ->setPaperSize(PageSetup::PAPERSIZE_A2_PAPER);
        $event->sheet->autoSize();
    }
}
