<?php


namespace App\Exports;


use App\Wrappers\Vistas\DatosTablaExportarDerivaciones;
use Barryvdh\DomPDF\Facade as PDF;

class PDFDerivacionExport implements ArchivoExport
{
    public function download(DatosTablaExportarDerivaciones $datos)
    {
        $datos->esPDF = true;
        $pdf = PDF::loadView('procesos.derivaciones.tablaExportarDerivaciones', ["datos" => $datos])
            ->setPaper('a4', 'landscape');
        return $pdf->download('tramites_exportados.pdf');
    }
}
