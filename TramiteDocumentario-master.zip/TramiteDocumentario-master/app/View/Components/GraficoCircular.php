<?php

namespace App\View\Components;

use App\Contracts\HistorialCambioEstadoRepository;
use App\Strategies\GraficoCircularStrategy;
use Illuminate\View\Component;

class GraficoCircular extends Component
{
    private $strategy;


    public function __construct(HistorialCambioEstadoRepository $historialService)
    {
        $this->strategy = new GraficoCircularStrategy($historialService);
    }

    public function render()
    {
        $datos = $this->strategy->obtenerDatos();
        return view('components.grafico-circular', ['datos' => json_encode($datos)]);
    }
}
