<?php

namespace App\View\Components;

use App\Contracts\HistorialCambioEstadoRepository;
use App\Strategies\CardPorAtenderStrategy;
use App\Strategies\CardPorRecibirStrategy;

class CardPorAtender extends Card
{
    public function __construct(HistorialCambioEstadoRepository $historialService)
    {
        $this->strategy = new CardPorAtenderStrategy($historialService);
        $this->vista = 'components.card-por-atender';
    }
}
