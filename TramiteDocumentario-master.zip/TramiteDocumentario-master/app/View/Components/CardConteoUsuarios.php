<?php

namespace App\View\Components;


use App\Contracts\UsuarioRepository;
use Illuminate\View\Component;

class CardConteoUsuarios extends Component
{
    private $usuarioService;

    public function __construct(UsuarioRepository $usuarioService)
    {
        $this->usuarioService = $usuarioService;
    }

    public function render()
    {
        $datos = $this->usuarioService->count();
        return view('components.card-conteo-usuarios', [
            'datos' => $datos
        ]);
    }
}
