<?php

namespace App\View\Components;

use App\Contracts\HistorialCambioEstadoRepository;
use App\Strategies\GraficoDeBarrasStrategy;
use App\TablaInfo\DerivacionTablaInfo;
use Carbon\Carbon;
use Illuminate\View\Component;

class GraficoDeBarras extends Component
{
    private $strategy;

    public function __construct(HistorialCambioEstadoRepository $historialService)
    {
        $this->strategy = new GraficoDeBarrasStrategy($historialService);
    }

    public function render()
    {
        $datos = $this->strategy->obtenerDatos();
        return view('components.grafico-de-barras', ['datos' => json_encode($datos)]);
    }
}
