<?php

namespace App\View\Components;

use App\Contracts\HistorialCambioEstadoRepository;
use App\Strategies\CardArchivadosStrategy;
use Illuminate\View\Component;

class CardArchivados extends Card
{
    public function __construct(HistorialCambioEstadoRepository $historialService)
    {
        $this->strategy = new CardArchivadosStrategy($historialService);
        $this->vista = 'components.card-archivados';
    }
}
