<?php


namespace App\Strategies;


use App\Contracts\GraficoStrategy;
use App\Contracts\HistorialCambioEstadoRepository;

class GraficoDeBarrasStrategy extends GraficoStrategy
{
    public function __construct(HistorialCambioEstadoRepository $historialService)
    {
        parent::__construct();
        $this->historialService = $historialService;
    }

    public function obtenerDatos()
    {
        $datos = [
            'meses' => self::MESES
        ];

        foreach ($this->estadosTramite as $estado) {
            $datos[$estado] = [];
            for ($i = 1; $i < 12; $i++) {
                $fechaInicio = now()->year.'-'.$i.'-01 00:00:00';
                $fechaFin = now()->year.'-'.($i + 1).'-01 23:59:59';
                $conteo = $this->historialService->statsDerivacion($fechaInicio, $fechaFin, $estado);
                array_push($datos[$estado], $conteo);
            }
        }
        return $datos;
    }
}
