<?php


namespace App\Strategies;


use App\Contracts\GraficoStrategy;
use App\Contracts\HistorialCambioEstadoRepository;
use App\TablaInfo\DerivacionTablaInfo;
use Carbon\Carbon;

class GraficoCircularStrategy extends GraficoStrategy
{
    public function __construct(HistorialCambioEstadoRepository $historialService)
    {
        parent::__construct();
        $this->historialService = $historialService;
    }

    public function obtenerDatos()
    {
        $datos = [];
        foreach ($this->estadosTramite as $estado) {
            $fechaInicio = Carbon::now()->subMonth();
	    $fechaFin = Carbon::now()->addDay();
		
	    $datos[$estado] = $this->historialService->statsDerivacion(
                "{$fechaInicio->toDateString()} 00:00:00",
                "{$fechaFin->toDateString()} 23:59:59",
                $estado
            );

            #$datos[$estado] = $this->historialService->statsDerivacion(
           #     $fechaInicio->toDateString(),
           #     $fechaFin->toDateString(),
           #     $estado
           # );
        }
        return $datos;
    }
}
