<?php


namespace App\Strategies;


use App\Contracts\GraficoStrategy;
use App\Contracts\HistorialCambioEstadoRepository;
use App\TablaInfo\DerivacionTablaInfo;

class CardAtendidosStrategy extends CardStrategy
{
    public function __construct(HistorialCambioEstadoRepository $historialService)
    {
        parent::__construct();
        $this->historialService = $historialService;
        $this->estado = DerivacionTablaInfo::ESTADO_ATENDIDO;
    }
}
