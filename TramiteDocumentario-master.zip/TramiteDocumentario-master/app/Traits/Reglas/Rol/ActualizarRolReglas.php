<?php

namespace App\Traits\Reglas\Rol;

use App\TablaInfo\RolTablaInfo;
use Illuminate\Validation\Rule;

trait ActualizarRolReglas
{
    use RolRequestReglas;

    private function nombreReglas($idRol)
    {
        $rolTabla = RolTablaInfo::nombreTabla();
        $reglaUnique = Rule::unique($rolTabla, RolTablaInfo::NOMBRE)->ignore($idRol);
        return ['required', 'alpha_dash', $reglaUnique];
    }

    private function idReglas()
    {
        $tablaRol = RolTablaInfo::nombreTabla();
        $idAttr = RolTablaInfo::ID;
        return ['required', "exists:{$tablaRol},{$idAttr}"];
    }
}
