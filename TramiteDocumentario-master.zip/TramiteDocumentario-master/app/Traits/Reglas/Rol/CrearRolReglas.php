<?php

namespace App\Traits\Reglas\Rol;

use App\TablaInfo\RolTablaInfo;

trait CrearRolReglas
{
    use RolRequestReglas;

    private function nombreReglas()
    {
        $rolTabla = RolTablaInfo::nombreTabla();
        $nombreAttr = RolTablaInfo::NOMBRE;
        return ['required', 'alpha_dash', "unique:{$rolTabla},{$nombreAttr}"];
    }
}
