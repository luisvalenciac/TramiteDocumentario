<?php

namespace App\Traits\Reglas\TipoSolicitud;

use App\TablaInfo\TipoSolicitudTablaInfo;

trait ActualizarTipoSolicitudReglas
{

    use TipoSolicitudRequestReglas;

    private function idTipoSolicitud()
    {
        $tipoSolicitudTabla = TipoSolicitudTablaInfo::NOMBRE_TABLA;
        $idAttr = TipoSolicitudTablaInfo::ID;
        return ['required', "exists:{$areaTabla},{$idAttr}"];
    }
}
