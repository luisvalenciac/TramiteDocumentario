<?php

namespace App\Traits\Reglas\Oficina;

use App\TablaInfo\AreaTablaInfo;
use App\Traits\Reglas\Area\AreaRequestReglas;

trait OficinaRequestReglas
{
    use AreaRequestReglas;

    private function idAreaPadreReglas()
    {
        $idAttr = AreaTablaInfo::ID;
        return ['required', "exists:{$this->oficinaTabla},{$idAttr}"];
    }

    private function nombresAtributos()
    {
        return [
            AreaTablaInfo::AREA_PADRE_ID => 'area padre'
        ];
    }
}
