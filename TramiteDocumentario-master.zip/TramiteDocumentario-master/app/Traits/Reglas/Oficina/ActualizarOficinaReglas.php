<?php

namespace App\Traits\Reglas\Oficina;

use App\TablaInfo\AreaTablaInfo;

trait ActualizarOficinaReglas
{
    use OficinaRequestReglas;

    private function idOficinaReglas()
    {
        $idAttr = AreaTablaInfo::ID;
        return ['required', "exists:{$this->oficinaTabla},{$idAttr}"];
    }
}
