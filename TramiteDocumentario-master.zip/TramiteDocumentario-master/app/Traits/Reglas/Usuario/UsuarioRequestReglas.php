<?php

namespace App\Traits\Reglas\Usuario;

use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\RolTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use App\TablaInfo\UsuarioTablaInfo as UserAttr;

trait UsuarioRequestReglas
{
    private $userTabla = UsuarioTablaInfo::NOMBRE_TABLA;

    private function rolReglas()
    {
        $nombreTabla = RolTablaInfo::nombreTabla();
        $nombreAttr = RolTablaInfo::NOMBRE;
        return ['nullable', "exists:{$nombreTabla},{$nombreAttr}"];
    }

    private function areaReglas()
    {
        $nombreTabla = AreaTablaInfo::NOMBRE_TABLA;
        $nombreAttr = AreaTablaInfo::ID;
        return ['required', "exists:{$nombreTabla},{$nombreAttr}"];
    }

    private function nombresReglas()
    {
        return ['required'];
    }

    private function apellidosReglas()
    {
        return ['required'];
    }

    private function nombreAtributos()
    {
        return [
            UserAttr::DNI => 'DNI',
            UserAttr::AREA_ID => 'unidad orgánica',
            UserAttr::TELEFONO => 'teléfono',
        ];
    }

    private function telefonoReglas()
    {
        return ['nullable', 'digits_between:6,11'];
    }

    private function direccionReglas()
    {
        return ['nullable'];
    }

    private function cargoReglas()
    {
        return ['required'];
    }
}
