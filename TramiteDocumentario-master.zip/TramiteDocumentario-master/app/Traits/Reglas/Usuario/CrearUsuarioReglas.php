<?php

namespace App\Traits\Reglas\Usuario;

use App\TablaInfo\UsuarioTablaInfo as UserAttr;

trait CrearUsuarioReglas
{
    use UsuarioRequestReglas;

    private function usernameReglas()
    {
        $usernameAttr = UserAttr::USERNAME;
        return ['nullable', "unique:{$this->userTabla},{$usernameAttr}"];
    }

    private function dniReglas()
    {
        return ['required', 'digits:8'];
    }

    private function correoReglas()
    {
        return ['nullable', 'email'];
    }

    private function passwordReglas()
    {
        return ['nullable', 'confirmed', 'min:8'];
    }
}
