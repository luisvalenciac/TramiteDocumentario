<?php

namespace App\Traits\Reglas\Usuario;

use App\TablaInfo\UsuarioTablaInfo as UserAttr;
use Illuminate\Validation\Rule;

trait ActualizarUsuarioReglas
{
    use UsuarioRequestReglas;

    private function idUsuarioReglas()
    {
        $idAttr = UserAttr::ID;
        return ['required', "exists:{$this->userTabla},{$idAttr}"];
    }

    private function usernameReglas($idUsuario)
    {
        $reglaUnico = Rule::unique($this->userTabla, UserAttr::USERNAME)->ignore($idUsuario);
        return ['nullable', $reglaUnico];
    }

    private function dniReglas()
    {
        return ['required', 'digits:8'];
    }

    private function correoReglas()
    {
        return ['nullable', 'email'];
    }

    private function passwordReglas()
    {
        return ['exclude_if:change_password,""', 'required_if:change_password,""', 'confirmed', 'min:8'];
    }

    private function cambiarPasswordReglas()
    {
        return ['sometimes'];
    }
}
