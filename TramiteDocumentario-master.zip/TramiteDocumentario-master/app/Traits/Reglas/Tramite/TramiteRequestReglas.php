<?php

namespace App\Traits\Reglas\Tramite;

use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;

trait TramiteRequestReglas
{
    private function nombreAtributos()
    {
        return [
            TramiteTablaInfo::CODIGO_PAGO => 'código de pago',
            TramiteTablaInfo::TIPO_SOLICITANTE => 'tipo de usuario',
            TramiteTablaInfo::DATO_IDENTIFICACION => 'identificación',
            TramiteTablaInfo::USER_EXPEDIENTE_ID => 'usuario de expediente',
            TramiteTablaInfo::NUMERO_TRAMITE => 'número de trámite',
            TramiteTablaInfo::ADJUNTO_PAGO => 'archivo de pago',
            TramiteTablaInfo::OTRO_TIPO_SOLICITUD => 'otro tipo de documento',
            TramiteTablaInfo::DERIVACIONES_ATTR . DerivacionTablaInfo::DETALLE => 'detalle',
        ];
    }
}
