<?php

namespace App\Traits\Reglas\Tramite;

use App\Rules\UserPerteneceAreaRule;
use App\TablaInfo\TipoSolicitudTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

trait CrearTramiteReglas
{
    use TramiteRequestReglas;

    private function prioridadReglas()
    {
        return ['required', Rule::in(array_keys(TramiteTablaInfo::prioridadesDict()))];
    }

    private function userExpedienteReglas($userService)
    {
        return [
            'required', Rule::exists(UsuarioTablaInfo::NOMBRE_TABLA, UsuarioTablaInfo::ID),
            new UserPerteneceAreaRule($userService)
        ];
    }

    private function fechaEmisionReglas()
    {
        return ['required', 'date'];
    }

    private function tipoSolicitudReglas()
    {
        $tablaTipo = TipoSolicitudTablaInfo::NOMBRE_TABLA;
        $idTipoAttr = TipoSolicitudTablaInfo::ID;
        return ['nullable', "exists:{$tablaTipo},{$idTipoAttr}"];
    }

    private function tipoSolicitanteReglas()
    {
        return ['required', Rule::in(array_keys(TramiteTablaInfo::getPrivateTiposSolicitante()))];
    }

    private function tipoSolicitantePublicReglas()
    {
        return ['required', Rule::in(array_keys(TramiteTablaInfo::getPublicTiposSolicitante()))];
    }

    private function numeroTramiteReglas()
    {
        if (Auth::user()->esAdminSistema())
            return ['required', 'integer', 'gt:0',
                Rule::unique(TramiteTablaInfo::NOMBRE_TABLA, TramiteTablaInfo::NUMERO_TRAMITE),];
        return ['nullable'];
    }

    private function formaRecepcionReglas()
    {
        return ['required', Rule::in(array_keys(TramiteTablaInfo::formasRecepcionDict()))];
    }

    private function archivoTramiteReglas()
    {
        return ['nullable', 'file', 'max:4096', 'mimes:pdf,PDF,png,PNG,jpeg'];
    }

    private function foliosReglas()
    {
        return ['required'];
    }

    private function asuntoReglas()
    {
        return ['required'];
    }

    private function anexosReglas()
    {
        return ['nullable', 'string'];
    }

    private function referenciaReglas()
    {
        return ['nullable', 'string'];
    }

    private function incluyePagoReglas()
    {
        return ['boolean'];
    }

    private function codigoPagoReglas($incluyePago)
    {
        $incluirPago = $incluyePago == '1' || $incluyePago == 1;
        $tablaTramite = TramiteTablaInfo::NOMBRE_TABLA;
        $codigoPagoAttr = TramiteTablaInfo::CODIGO_PAGO;
        return ['nullable', Rule::requiredIf($incluirPago), "unique:{$tablaTramite},{$codigoPagoAttr}"];
    }

    private function derivacionesReglas()
    {
        return ['nullable', 'array'];
    }

    private function datoIdentificacionReglas($tipo)
    {
        if ($tipo == TramiteTablaInfo::TIPO_USER_ESTUDIANTE)
            return ['required', 'digits_between:1,20'];
        if ($tipo == TramiteTablaInfo::TIPO_USER_JURIDICO)
            return ['required', 'digits:11'];
        if ($tipo == TramiteTablaInfo::TIPO_USER_NORMAL)
            return ['required', 'digits:8'];
        return ['required', 'digits_between:1,20'];
    }

    private function adjuntoPagoReglas($incluyePago)
    {
        $incluirPago = $incluyePago == '1' || $incluyePago == 1;
        return ['nullable', Rule::requiredIf($incluirPago), 'file', 'max:4096', 'mimes:pdf,PDF,png,PNG,jpeg'];
    }

    private function otroTipoSolicitudReglas($tipoSolicitudValue)
    {
        return ['nullable', Rule::requiredIf($tipoSolicitudValue == '')];
    }
}
