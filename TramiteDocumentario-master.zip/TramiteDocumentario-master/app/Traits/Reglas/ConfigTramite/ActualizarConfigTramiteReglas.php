<?php

namespace App\Traits\Reglas\ConfigTramite;

use App\Contracts\UsuarioRepository;
use App\Rules\UserPerteneceAreaRule;
use App\TablaInfo\ConfigTramiteTablaInfo;
use App\Traits\Reglas\Derivacion\CrearDerivacionReglas;

trait ActualizarConfigTramiteReglas
{
    use CrearDerivacionReglas;

    private function usuarioSolicitudReglas(UsuarioRepository $userService)
    {
        $reglas = $this->userDestinoReglas($userService);
        array_push($reglas, new UserPerteneceAreaRule($userService));
        return $reglas;
    }

    private function nombresAtributos()
    {
        return [
            ConfigTramiteTablaInfo::USER_RECIBE_SOLICITUD_ID => 'usuario receptor del trámite o solicitud'
        ];
    }
}
