<?php


namespace App\Traits\Reglas\Solicitud;


class CrearSolicitudReglas
{

}
