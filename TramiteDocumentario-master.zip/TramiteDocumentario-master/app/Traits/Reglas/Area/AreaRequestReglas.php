<?php

namespace App\Traits\Reglas\Area;

use App\Contracts\UsuarioRepository;
use App\Rules\UserPerteneceAreaRule;
use App\TablaInfo\AreaTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Validation\Rule;

trait AreaRequestReglas
{
    private function nombreReglas()
    {
        return ['required'];
    }

    private function abreviaturaReglas()
    {
        return ['required'];
    }

    private function siglasReglas()
    {
        return ['required'];
    }

    private function tipoAreaReglas()
    {
        return ['required', Rule::in(array_keys(AreaTablaInfo::tiposAreaDict()))];
    }

    private function userResponsableReglas(UsuarioRepository $userService)
    {
        return ['nullable', Rule::exists(UsuarioTablaInfo::NOMBRE_TABLA, UsuarioTablaInfo::ID),
            new UserPerteneceAreaRule($userService)];
    }

    public function nombresAtributos()
    {
        return [
            AreaTablaInfo::USER_RESPONSABLE_ID => 'usuario responsable'
        ];
    }
}
