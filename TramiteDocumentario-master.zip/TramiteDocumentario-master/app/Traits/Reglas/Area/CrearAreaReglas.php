<?php


namespace App\Traits\Reglas\Area;


trait CrearAreaReglas
{
    use AreaRequestReglas;
}
