<?php

namespace App\Traits\Reglas\Area;

use App\TablaInfo\AreaTablaInfo;

trait ActualizarAreaReglas
{
    use AreaRequestReglas;

    private function idAreaReglas()
    {
        $areaTabla = AreaTablaInfo::NOMBRE_TABLA;
        $idAttr = AreaTablaInfo::ID;
        return ['required', "exists:{$areaTabla},{$idAttr}"];
    }
}
