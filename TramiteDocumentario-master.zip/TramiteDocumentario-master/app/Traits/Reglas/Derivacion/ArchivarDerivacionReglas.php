<?php


namespace App\Traits\Reglas\Derivacion;


use App\TablaInfo\ArchivadorTablaInfo;
use App\TablaInfo\DerivacionTablaInfo;

trait ArchivarDerivacionReglas
{
    private function idArchivadorReglas()
    {
        $archivadorTabla = ArchivadorTablaInfo::NOMBRE_TABLA;
        $idAttr = ArchivadorTablaInfo::ID;
        return ['required', "exists:{$archivadorTabla},{$idAttr}"];
    }
}
