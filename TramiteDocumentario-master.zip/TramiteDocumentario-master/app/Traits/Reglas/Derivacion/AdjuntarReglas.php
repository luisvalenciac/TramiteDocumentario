<?php

namespace App\Traits\Reglas\Derivacion;

use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\AdjuntoTablaInfo;
use App\Traits\Reglas\Adjunto\CrearAdjuntoReglas;

trait AdjuntarReglas
{
    use AtenderDerivacionReglas {
        nombresAtributos as atenderDerivacionAttrs;
        mensajesValidacion as atenderDerivacionMessages;
    }
    use CrearAdjuntoReglas {
        nombreAtributos as crearAdjuntoAttrs;
    }

    private function adjuntosReglas($required = false)
    {
        $req = $required ? 'required' : 'nullable';
        return [$req, 'array'];
    }

    private function nombresAtributos()
    {
        return array_merge($this->atenderDerivacionAttrs(), [
            DerivacionTablaInfo::ADJUNTOS_ATTR . AdjuntoTablaInfo::NOMBRE_ADJUNTO =>
                $this->crearAdjuntoAttrs()[AdjuntoTablaInfo::NOMBRE_ADJUNTO],
        ]);
    }

    private function mensajesValidacion()
    {
        return [
            DerivacionTablaInfo::ADJUNTOS_ATTR . AdjuntoTablaInfo::NOMBRE_ADJUNTO . '.required' =>
                'Debe ingresar un nombre de adjunto.',
            DerivacionTablaInfo::ADJUNTOS_ATTR . AdjuntoTablaInfo::ADJUNTO . '.required' =>
                'Debe ingresar un adjunto.',
        ];
    }
}
