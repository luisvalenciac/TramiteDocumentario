<?php

namespace App\Traits\Reglas\Derivacion;


trait DerivarReglas
{
    use AtenderDerivacionReglas {
        nombresAtributos as atenderDerivacionAttrs;
        mensajesValidacion as crearDerivacionMensajes;
    }

    private function nombresAtributos()
    {
        return array_merge($this->crearDerivacionAttrs(), $this->atenderDerivacionAttrs());
    }

    private function mensajesValidacion()
    {
        return $this->crearDerivacionMensajes();
    }
}
