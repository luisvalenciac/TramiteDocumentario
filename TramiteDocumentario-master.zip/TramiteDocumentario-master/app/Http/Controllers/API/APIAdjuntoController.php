<?php

namespace App\Http\Controllers\API;

use App\Contracts\AdjuntoRepository;
use App\Http\Controllers\Controller;
use App\Models\Adjunto;

class APIAdjuntoController extends Controller
{
    private $adjuntoService;

    public function __construct(AdjuntoRepository $adjuntoService)
    {
        $this->middleware(['auth']);
        $this->adjuntoService = $adjuntoService;
    }

    public function eliminarAdjunto(Adjunto $adjunto)
    {
        $this->adjuntoService->eliminar($adjunto);
        return response()->json($adjunto);
    }
}
