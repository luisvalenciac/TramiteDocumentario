<?php

namespace App\Http\Controllers\API;

use App\Contracts\ReniecRepository;
use App\Http\Controllers\Controller;
use App\Http\Requests\API\ConsultaDeDniRequest;

class APIReniecController extends Controller
{
    private $consultaReniec;

    public function __construct(ReniecRepository $consultaReniec)
    {
        $this->middleware('auth');
        $this->consultaReniec = $consultaReniec;
    }

    public function dni(ConsultaDeDniRequest $request)
    {
        $dni = $request->getDni();
        $persona = $this->consultaReniec->consultarDni($dni);
        if ($persona)
            return response()->json($persona);
        return response()->json(['mensaje' => 'No se encontraron registros'], 404);
    }
}

