<?php

namespace App\Http\Controllers\Procesos;

use App\Contracts\AreaRepository;
use App\Contracts\TipoSolicitudRepository;
use App\Contracts\TramiteRepository;
use App\Contracts\UsuarioRepository;
use App\Http\Controllers\Controller;
use App\Http\Requests\Tramite\CrearTramiteRequest;
use App\Models\Tramite;
use App\Wrappers\Vistas\DatosCrearTramite;
use App\Wrappers\Vistas\DatosDetalleTramite;
use Illuminate\Http\Request;

class TramiteController extends Controller
{
    private $tramites;
    private $areas;
    private $tiposSolicitud;
    private $users;

    public function __construct(TramiteRepository $tramites, AreaRepository $areas,
                                TipoSolicitudRepository $tiposSolicitud, UsuarioRepository $users)
    {
        $this->middleware(['auth']);
        $this->tramites = $tramites;
        $this->areas = $areas;
        $this->tiposSolicitud = $tiposSolicitud;
        $this->users = $users;
    }

    public function crearTramite(Request $request)
    {
        $datosVista = new DatosCrearTramite($this->areas, $this->tiposSolicitud, $this->tramites, $request);
        return view('procesos.tramites.crearTramite', ["datos" => $datosVista]);
    }

    public function guardarTramite(CrearTramiteRequest $request)
    {
        $tramite = $this->tramites->crearTramite($request->validated());
        return response()->json($tramite);
    }

    public function detalleTramite(Tramite $tramite)
    {
        $datosVista = new DatosDetalleTramite($tramite);
        return view('procesos.tramites.detalleTramite', ["datos" => $datosVista]);
    }
}
