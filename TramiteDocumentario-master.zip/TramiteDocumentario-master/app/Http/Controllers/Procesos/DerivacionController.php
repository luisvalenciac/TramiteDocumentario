<?php

namespace App\Http\Controllers\Procesos;

use App\Config\Factories\DerivacionesFactory;
use App\Config\Factories\ExportDerivacionFactory;
use App\Contracts\ArchivadorRepository;
use App\Contracts\AreaRepository;
use App\Contracts\DerivacionRepository;
use App\Contracts\TipoSolicitudRepository;
use App\Http\Controllers\Controller;
use App\Http\Requests\Derivacion\AdjuntarDerivacionRequest;
use App\Http\Requests\Derivacion\ArchivarDerivacionRequest;
use App\Http\Requests\Derivacion\AtenderDerivacionRequest;
use App\Http\Requests\Derivacion\DerivarRequest;
use App\Http\Requests\Derivacion\ExportarDerivacionRequest;
use App\Http\Requests\Derivacion\RecepcionarDerivacionRequest;
use App\Http\Requests\Derivacion\RegresarEstadoDerivacionRequest;
use App\Models\Derivacion;
use App\Services\UsuarioService;
use App\Wrappers\Vistas\DatosExportarDerivaciones;
use App\Wrappers\Vistas\DatosListarDerivaciones;
use App\Wrappers\Vistas\DatosTablaExportarDerivaciones;
use Illuminate\Http\Request;

class DerivacionController extends Controller
{
    private $derivacionService;
    private $areaService;
    private $archivadorService;
    private $userService;
    private $tipoSolicitudService;

    public function __construct(DerivacionRepository $derivacionService, AreaRepository $areaService,
                                ArchivadorRepository $archivadorService, UsuarioService $userService,
                                TipoSolicitudRepository $tipoSolicitudService)
    {
        $this->middleware(['auth']);
        $this->derivacionService = $derivacionService;
        $this->areaService = $areaService;
        $this->archivadorService = $archivadorService;
        $this->userService = $userService;
        $this->tipoSolicitudService = $tipoSolicitudService;
    }

    public function derivaciones(Request $request)
    {
        $datosVista = new DatosListarDerivaciones($this->derivacionService, $this->userService,
            $this->tipoSolicitudService, $this->archivadorService, $request);
        return view(DerivacionesFactory::vistaDerivaciones($request), ["datos" => $datosVista]);
    }

    public function vistaRecepcionar(Derivacion $derivacion)
    {
        return view('procesos.derivaciones.recepcionar', ["derivacion" => $derivacion]);
    }

    public function recepcionar(RecepcionarDerivacionRequest $request, Derivacion $derivacion)
    {
        $this->derivacionService->actualizarDerivacion($derivacion, $request->validated());
        return response()->json($derivacion);
    }

    public function vistaAtender(Derivacion $derivacion)
    {
        return view('procesos.derivaciones.atenderDerivacion', ["derivacion" => $derivacion]);
    }

    public function atenderDerivacion(AtenderDerivacionRequest $request, Derivacion $derivacion)
    {
        $this->derivacionService->actualizarDerivacion($derivacion, $request->validated());
        return response()->json($request->validated());
    }

    public function vistaDerivar(Derivacion $derivacion)
    {
        return view('procesos.derivaciones.derivar', ["derivacion" => $derivacion,
            "areas" => $this->areaService->areas()->get()]);
    }

    public function derivar(DerivarRequest $request, Derivacion $derivacion)
    {
        $datos = $request->validated($derivacion->estado);
        $derivacion = $this->derivacionService->actualizarDerivacion($derivacion, $datos);
        return response()->json($derivacion);
    }

    public function vistaAdjuntar(Derivacion $derivacion)
    {
        return view('procesos.derivaciones.adjuntar', ["derivacion" => $derivacion]);
    }

    public function adjuntar(AdjuntarDerivacionRequest $request, Derivacion $derivacion)
    {
        $this->derivacionService->actualizarDerivacion($derivacion, $request->validated());
        return response()->json($derivacion);
    }

    public function vistaArchivar(Derivacion $derivacion)
    {
        return view('procesos.derivaciones.archivar', ["derivacion" => $derivacion,
            "archivadores" => $this->archivadorService->allArchivadores()]);
    }

    public function archivar(ArchivarDerivacionRequest $request, Derivacion $derivacion)
    {
        $this->derivacionService->actualizarDerivacion($derivacion, $request->validated());
        return response()->json($derivacion);
    }

    public function vistaRegresarEstado(Derivacion $derivacion)
    {
        return view('procesos.derivaciones.regresarEstado', ["derivacion" => $derivacion]);
    }

    public function regresarEstado(RegresarEstadoDerivacionRequest $request, Derivacion $derivacion)
    {
        $this->derivacionService->actualizarDerivacion($derivacion, $request->validated());
        return response()->json($derivacion);
    }

    public function vistaExportar()
    {
        $datosVista = new DatosExportarDerivaciones($this->userService, $this->tipoSolicitudService);
        return view('procesos.derivaciones.exportar', ["datos" => $datosVista]);
    }

    public function exportar(ExportarDerivacionRequest $request)
    {
        $extension = $request->validated()['extension'];
        $archivo = ExportDerivacionFactory::getExportArchivo($extension);
        $datosVista = new DatosTablaExportarDerivaciones($this->derivacionService, $request);
        return $archivo->download($datosVista);
    }
}
