<?php

namespace App\Http\Controllers\Administracion;

use App\Contracts\ArchivadorRepository;
use App\Contracts\AreaRepository;
use App\Http\Controllers\Controller;
use App\Http\Requests\Archivador\ActualizarArchivadorRequest;
use App\Http\Requests\Archivador\CrearArchivadorRequest;
use App\Models\Archivador;
use App\Models\Tramite;
use App\Wrappers\Vistas\DatosActualizarArchivador;
use App\Wrappers\Vistas\DatosListarArchivadores;
use Illuminate\Http\Request;


class ArchivadorController extends Controller
{
    private $archivadorService;
    private $areaService;

    public function __construct(ArchivadorRepository $archivadorService, AreaRepository $areaService)
    {
        $this->middleware(['auth']);
        $this->authorizeResource(Archivador::class);
        $this->archivadorService = $archivadorService;
        $this->areaService = $areaService;
    }

    public function index(Request $request)
    {
        $datosVista = new DatosListarArchivadores($this->archivadorService, $this->areaService, $request);
        return view('administracion.archivadores.listarArchivadores', ["datos" => $datosVista]);
    }

    public function create()
    {
        $areas = $this->areaService->areas()->get();
        return view('administracion.archivadores.crearArchivador', ["areas" => $areas]);
    }

    public function store(CrearArchivadorRequest $request)
    {
        $this->archivadorService->crear($request->validated());
        return redirect()->route('administracion.archivadores.index');
    }

    public function edit(Archivador $archivadore)
    {
        $datosVista = new DatosActualizarArchivador($archivadore, $this->areaService);
        return view('administracion.archivadores.editarArchivador', ["datos" => $datosVista]);
    }

    public function update(ActualizarArchivadorRequest $request, Archivador $archivadore)
    {
        $this->archivadorService->actualizar($archivadore, $request->validated());
        return redirect()->route('administracion.archivadores.index');
    }
}
