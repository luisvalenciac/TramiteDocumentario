<?php

namespace App\Http\Controllers\Administracion;

use App\Contracts\AreaRepository;
use App\Contracts\RoleRepository;
use App\Contracts\UsuarioRepository;
use App\Http\Controllers\Controller;
use App\Models\Usuario;
use App\Http\Requests\Usuario\ActualizarUsuarioRequest;
use App\Http\Requests\Usuario\CrearUsuarioRequest;
use App\Wrappers\Vistas\DatosActualizarUsuario;
use App\Wrappers\Vistas\DatosCrearUsuario;
use App\Wrappers\Vistas\DatosListarUsuarios;
use Illuminate\Http\Request;

class UsuarioController extends Controller
{
    private $users;
    private $roles;
    private $areas;

    public function __construct(UsuarioRepository $users, RoleRepository $roles, AreaRepository $areas)
    {
        $this->middleware(['auth']);
        $this->authorizeResource(Usuario::class);
        $this->users = $users;
        $this->roles = $roles;
        $this->areas = $areas;
    }

    public function index(Request $request)
    {
        $datosVista = new DatosListarUsuarios($this->users, $this->areas, $request);
        return view('administracion.usuarios.listarUsuarios', ['datos' => $datosVista]);
    }

    public function create()
    {
        $datos = new DatosCrearUsuario($this->areas, $this->roles);
        return view('administracion.usuarios.crearUsuario', ['datos' => $datos]);
    }

    public function store(CrearUsuarioRequest $request)
    {
        $this->users->crear($request->validated());
        return redirect()->route('administracion.usuarios.index');
    }

    public function show(Usuario $usuario)
    {
        return view('administracion.usuarios.detalleUsuario', ['usuario' => $usuario]);
    }

    public function edit(Usuario $usuario)
    {
        $datosVista = new DatosActualizarUsuario($usuario, $this->roles, $this->areas);
        return view('administracion.usuarios.editarUsuario', ['datos' => $datosVista]);
    }

    public function update(ActualizarUsuarioRequest $request, Usuario $usuario)
    {
        $this->users->actualizar($usuario, $request->validated());
        return redirect()->route('administracion.usuarios.index');
    }

    public function destroy(Usuario $usuario)
    {
        $this->users->deshabilitar($usuario);
        return redirect()->route('administracion.usuarios.index');
    }
}
