<?php


namespace App\Http\Controllers\Administracion;


use App\Contracts\TipoSolicitudRepository;
use App\Http\Controllers\Controller;
use App\Http\Requests\TipoSolicitud\ActualizarTipoSolicitudRequest;
use App\Http\Requests\TipoSolicitud\CrearTipoSolicitudRequest;
use App\Models\TipoSolicitud;
use Illuminate\Http\Request;

class TipoSolicitudController extends Controller
{
    private $tipoSolicitudService;

    public function __construct(TipoSolicitudRepository $tipoSolicitudService)
    {
        $this->middleware(['auth']);
        $this->tipoSolicitudService = $tipoSolicitudService;
    }

    public function index(Request $request)
    {
        $tiposSolicitud = $this->tipoSolicitudService->tiposSolicitudFiltrados($request);
        return view('administracion.tipoSolicitud.listarTiposSolicitud', ['tiposSolicitud' => $tiposSolicitud]);
    }

    public function create()
    {
        return view('administracion.tipoSolicitud.crearTipoSolicitud');
    }

    public function store(CrearTipoSolicitudRequest $request)
    {
        $this->tipoSolicitudService->crear($request->validated());
        return redirect()->route('administracion.tiposSolicitud.index');
    }

    public function edit(TipoSolicitud $tipoSolicitud)
    {
        return view('administracion.tipoSolicitud.editarTipoSolicitud', ['tipoSolicitud' => $tipoSolicitud]);
    }

    public function update(ActualizarTipoSolicitudRequest $request, TipoSolicitud $tipoSolicitud)
    {
        $this->tipoSolicitudService->actualizar($tipoSolicitud, $request->validated());
        return redirect()->route('administracion.tiposSolicitud.index');
    }

    public function destroy(TipoSolicitud $tipoSolicitud)
    {
        $this->tipoSolicitudService->eliminar($tipoSolicitud);
        return redirect()->route('administracion.tiposSolicitud.index');
    }
}
