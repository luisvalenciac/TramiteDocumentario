<?php

namespace App\Http\Requests\Area;

use App\Contracts\UsuarioRepository;
use App\TablaInfo\AreaTablaInfo as AreaAttr;
use App\Traits\Reglas\Area\ActualizarAreaReglas;
use Illuminate\Foundation\Http\FormRequest;

class ActualizarAreaRequest extends FormRequest
{
    use ActualizarAreaReglas;

    public function authorize()
    {
        return true;
    }

    public function rules(UsuarioRepository $userService)
    {
        return [
            AreaAttr::ID => $this->idAreaReglas(),
            AreaAttr::NOMBRE => $this->nombreReglas(),
            AreaAttr::ABREVIATURA => $this->nombreReglas(),
            AreaAttr::SIGLAS => $this->siglasReglas(),
            AreaAttr::TIPO_AREA => $this->tipoAreaReglas(),
            AreaAttr::USER_RESPONSABLE_ID => $this->userResponsableReglas($userService),
        ];
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }
}
