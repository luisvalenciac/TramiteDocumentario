<?php

namespace App\Http\Requests\Usuario;

use App\TablaInfo\UsuarioTablaInfo as UserAttr;
use App\Traits\Reglas\Usuario\CrearUsuarioReglas;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Hash;

class CrearUsuarioRequest extends FormRequest
{
    use CrearUsuarioReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            UserAttr::AREA_ID => $this->areaReglas(),
            UserAttr::USERNAME => $this->usernameReglas(),
            UserAttr::NOMBRES => $this->nombresReglas(),
            UserAttr::TELEFONO => $this->telefonoReglas(),
            UserAttr::APELLIDOS => $this->apellidosReglas(),
            UserAttr::DIRECCION => $this->direccionReglas(),
            UserAttr::CORREO => $this->correoReglas(),
            UserAttr::DNI => $this->dniReglas(),
            UserAttr::CARGO => $this->cargoReglas(),
            UserAttr::PASSWORD => $this->passwordReglas(),
            UserAttr::ROL => $this->rolReglas(),
        ];
    }

    public function attributes()
    {
        return $this->nombreAtributos();
    }

    public function validated()
    {
        $validated = parent::validated();
        $validated[UserAttr::PASSWORD] = Hash::make($validated[UserAttr::PASSWORD]);
        return $validated;
    }
}
