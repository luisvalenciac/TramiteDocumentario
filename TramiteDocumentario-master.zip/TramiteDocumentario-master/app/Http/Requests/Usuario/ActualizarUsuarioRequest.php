<?php

namespace App\Http\Requests\Usuario;

use App\TablaInfo\UsuarioTablaInfo as UserAttr;
use App\Traits\Reglas\Usuario\ActualizarUsuarioReglas;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Hash;

class ActualizarUsuarioRequest extends FormRequest
{
    use ActualizarUsuarioReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        $idUsuario = $this->idUsuario();
        return [
            UserAttr::ID => $this->idUsuarioReglas(),
            UserAttr::AREA_ID => $this->areaReglas(),
            UserAttr::TELEFONO => $this->telefonoReglas(),
            UserAttr::USERNAME => $this->usernameReglas($idUsuario),
            UserAttr::NOMBRES => $this->nombresReglas(),
            UserAttr::APELLIDOS => $this->apellidosReglas(),
            UserAttr::DIRECCION => $this->direccionReglas(),
            UserAttr::CORREO => $this->correoReglas(),
            UserAttr::DNI => $this->dniReglas(),
            UserAttr::CARGO => $this->cargoReglas(),
            UserAttr::ROL => $this->rolReglas(),
            UserAttr::CAMBIAR_PASSWORD => $this->cambiarPasswordReglas(),
            UserAttr::PASSWORD => $this->passwordReglas(),
        ];
    }

    public function attributes()
    {
        return $this->nombreAtributos();
    }

    public function validated()
    {
        $validated = parent::validated();
        if ($this->valorCambiarPass())
            $validated[UserAttr::PASSWORD] = Hash::make($validated[UserAttr::PASSWORD]);
        return $validated;
    }

    private function idUsuario()
    {
        return $this->input(UserAttr::ID);
    }

    private function valorCambiarPass()
    {
        return $this->input(UserAttr::CAMBIAR_PASSWORD, false);
    }
}
