<?php

namespace App\Http\Requests\Derivacion;

use App\Exports\DerivacionExport;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class ExportarDerivacionRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'cantidad' => ['required', 'regex:/^[0-9]+$|^[*]{1}$/'],
            'extension' => ['required', Rule::in(array_keys(DerivacionExport::getSopportedExtensions()))]
        ];
    }


}
