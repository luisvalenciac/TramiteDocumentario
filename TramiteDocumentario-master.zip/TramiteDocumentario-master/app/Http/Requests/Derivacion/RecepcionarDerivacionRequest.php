<?php

namespace App\Http\Requests\Derivacion;

use App\Config\Cleaners\DatosRecepcionarTramiteCleaner;
use App\Contracts\UsuarioRepository;
use App\TablaInfo\DerivacionTablaInfo;
use App\Traits\Reglas\Derivacion\AtenderDerivacionReglas;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\Auth;

class RecepcionarDerivacionRequest extends FormRequest
{
    use AtenderDerivacionReglas;

    public function authorize()
    {
        return true;
    }

    public function rules(UsuarioRepository $userService)
    {
        return [
            DerivacionTablaInfo::ID => $this->derivacionReglas(),
            DerivacionTablaInfo::ESTADO => $this->estadoReglas([DerivacionTablaInfo::ESTADO_POR_RECIBIR]),
            DerivacionTablaInfo::DETALLE => $this->detalleReglas(),
            DerivacionTablaInfo::PROVEIDO => $this->proveidoReglas(),
            DerivacionTablaInfo::USER_DESTINO_ID => $this->userDestinoReglas($userService, Auth::user()->id),
        ];
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }

    public function validated()
    {
        return (new DatosRecepcionarTramiteCleaner(parent::validated()))->getCleanData();
    }
}
