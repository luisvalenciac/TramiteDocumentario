<?php

namespace App\Http\Requests\Derivacion;

use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\AdjuntoTablaInfo;
use App\Traits\Reglas\Derivacion\AdjuntarReglas;
use Illuminate\Foundation\Http\FormRequest;

class AdjuntarDerivacionRequest extends FormRequest
{
    use AdjuntarReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            DerivacionTablaInfo::ID => $this->derivacionReglas(),
            DerivacionTablaInfo::DETALLE => $this->detalleReglas(),
            DerivacionTablaInfo::ESTADO => $this->estadoReglas([DerivacionTablaInfo::ESTADO_ATENDIDO]),

            DerivacionTablaInfo::ADJUNTOS => $this->adjuntosReglas(true),
            DerivacionTablaInfo::ADJUNTOS_ATTR . AdjuntoTablaInfo::NOMBRE_ADJUNTO =>
                $this->nombreAdjuntoReglas(),
            DerivacionTablaInfo::ADJUNTOS_ATTR . AdjuntoTablaInfo::ADJUNTO => $this->adjuntoReglas(true),
        ];
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }

    public function messages()
    {
        return $this->mensajesValidacion();
    }
}
