<?php

namespace App\Http\Requests\Tramite;

use App\Config\Cleaners\DatosCrearTramiteCleaner;
use App\Contracts\UsuarioRepository;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\Traits\Reglas\Derivacion\CrearDerivacionReglas;
use App\Traits\Reglas\Tramite\CrearTramiteReglas;
use Illuminate\Foundation\Http\FormRequest;

class CrearTramiteRequest extends FormRequest
{
    use CrearTramiteReglas;
    use CrearDerivacionReglas;

    public function authorize()
    {
        return true;
    }

    public function rules(UsuarioRepository $userService)
    {
        return [
            TramiteTablaInfo::PRIORIDAD => $this->prioridadReglas(),
            TramiteTablaInfo::USER_EXPEDIENTE_ID => $this->userExpedienteReglas($userService),
            TramiteTablaInfo::FECHA_EMISION => $this->fechaEmisionReglas(),
            TramiteTablaInfo::TIPO_SOLICITUD_ID => $this->tipoSolicitudReglas(),
            TramiteTablaInfo::OTRO_TIPO_SOLICITUD => $this->otroTipoSolicitudReglas($this->tipoSolicitudValue()),
            TramiteTablaInfo::TIPO_SOLICITANTE => $this->tipoSolicitanteReglas(),
            TramiteTablaInfo::DATO_IDENTIFICACION => $this->datoIdentificacionReglas($this->tipoUserValue()),
            TramiteTablaInfo::NUMERO_TRAMITE => $this->numeroTramiteReglas(),
            TramiteTablaInfo::FORMA_RECEPCION => $this->formaRecepcionReglas(),
            TramiteTablaInfo::ARCHIVO_TRAMITE => $this->archivoTramiteReglas(),
            TramiteTablaInfo::FOLIOS => $this->foliosReglas(),
            TramiteTablaInfo::ASUNTO => $this->asuntoReglas(),
            TramiteTablaInfo::ANEXOS => $this->anexosReglas(),
            TramiteTablaInfo::REFERENCIA => $this->referenciaReglas(),
            TramiteTablaInfo::INCLUYE_PAGO => $this->incluyePagoReglas(),
            TramiteTablaInfo::CODIGO_PAGO => $this->codigoPagoReglas($this->incluyePagoValue()),
            TramiteTablaInfo::ADJUNTO_PAGO => $this->adjuntoPagoReglas($this->incluyePagoValue()),

            TramiteTablaInfo::DERIVACIONES => $this->derivacionesReglas(),
            TramiteTablaInfo::DERIVACIONES_ATTR . DerivacionTablaInfo::ES_COPIA => $this->esCopiaReglas(),
            TramiteTablaInfo::DERIVACIONES_ATTR . DerivacionTablaInfo::AREA_DESTINO_ID => $this->areaDestinoReglas(),
            TramiteTablaInfo::DERIVACIONES_ATTR . DerivacionTablaInfo::USER_DESTINO_ID =>
                $this->userDestinoReglas($userService),
            TramiteTablaInfo::DERIVACIONES_ATTR . DerivacionTablaInfo::DETALLE => $this->detalleReglas(),
            TramiteTablaInfo::DERIVACIONES_ATTR . DerivacionTablaInfo::PROVEIDO => $this->proveidoReglas(),
            TramiteTablaInfo::DERIVACIONES_ATTR . DerivacionTablaInfo::ESTADO =>
                $this->estadoReglas([DerivacionTablaInfo::ESTADO_POR_RECIBIR]),

        ];
    }

    public function attributes()
    {
        return $this->nombreAtributos();
    }

    public function validated()
    {
        return (new DatosCrearTramiteCleaner(parent::validated()))->getCleanData();
    }

    private function incluyePagoValue()
    {
        return $this->input(TramiteTablaInfo::INCLUYE_PAGO, 0);
    }

    private function tipoUserValue()
    {
        return $this->input(TramiteTablaInfo::TIPO_SOLICITANTE);
    }

    private function tipoSolicitudValue()
    {
        return $this->input(TramiteTablaInfo::TIPO_SOLICITUD_ID);
    }
}
