<?php

namespace App\Http\Requests\Rol;

use App\TablaInfo\RolTablaInfo;
use App\Traits\Reglas\Rol\ActualizarRolReglas;
use Illuminate\Foundation\Http\FormRequest;

class ActualizarRolRequest extends FormRequest
{
    use ActualizarRolReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            RolTablaInfo::ID => $this->idReglas(),
            RolTablaInfo::NOMBRE => $this->nombreReglas($this->getIdRol()),
            RolTablaInfo::NOMBRE_DESCRIPTIVO => $this->nombreDescriptivoReglas(),
            RolTablaInfo::PERMISOS => $this->permisosReglas()
        ];
    }

    private function getIdRol()
    {
        return $this->input(RolTablaInfo::ID);
    }

    public function attributes()
    {
        return $this->nombreAtributos();
    }

    public function messages()
    {
        return $this->mensajesValidacion();
    }
}
