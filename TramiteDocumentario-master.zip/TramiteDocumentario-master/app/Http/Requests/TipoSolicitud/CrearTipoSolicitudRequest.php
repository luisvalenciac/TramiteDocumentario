<?php

namespace App\Http\Requests\TipoSolicitud;

use App\TablaInfo\TipoSolicitudTablaInfo as TipoSolicitudAttr;
use App\Traits\Reglas\TipoSolicitud\CrearTipoSolicitudReglas;
use Illuminate\Foundation\Http\FormRequest;

class CrearTipoSolicitudRequest extends FormRequest
{
    use CrearTipoSolicitudReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            TipoSolicitudAttr::NOMBRE_TIPO => $this->nombreTipoReglas(),
        ];
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }
}
