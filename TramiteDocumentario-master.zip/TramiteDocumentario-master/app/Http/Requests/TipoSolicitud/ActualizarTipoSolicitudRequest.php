<?php

namespace App\Http\Requests\TipoSolicitud;

use App\TablaInfo\TipoSolicitudTablaInfo as TipoSolicitudAttr;
use App\Traits\Reglas\TipoSolicitud\ActualizarTipoSolicitudReglas;
use Illuminate\Foundation\Http\FormRequest;

class ActualizarTipoSolicitudRequest extends FormRequest
{
    use ActualizarTipoSolicitudReglas;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            TipoSolicitudAttr::NOMBRE_TIPO => $this->nombreTipoReglas()
        ];
    }

    public function attributes()
    {
        return $this->nombresAtributos();
    }
}
