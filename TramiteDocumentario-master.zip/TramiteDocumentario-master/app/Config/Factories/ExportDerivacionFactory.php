<?php


namespace App\Config\Factories;


use App\Exports\ArchivoExport;
use App\Exports\DerivacionExport;
use App\Exports\ExcelDerivacionExport;
use App\Exports\PDFDerivacionExport;

class ExportDerivacionFactory
{
    public static function getExportArchivo($extension): ArchivoExport
    {
        if ($extension === DerivacionExport::EXT_EXCEL)
            return new ExcelDerivacionExport();
        return new PDFDerivacionExport();
    }
}
