<?php

namespace App\Config\Factories;

use App\Contracts\DerivacionRepository;
use App\TablaInfo\DerivacionTablaInfo as DerivacionAttr;
use Illuminate\Http\Request;

class DerivacionesFactory
{
    static function vistaDerivaciones(Request $request)
    {
        $estado = $request->query(DerivacionAttr::ESTADO, DerivacionAttr::ESTADO_POR_RECIBIR);
        if ($estado == DerivacionAttr::ESTADO_POR_RECIBIR)
            return 'procesos.derivaciones.porRecibir';
        if ($estado == DerivacionAttr::ESTADO_ATENDIDO)
            return 'procesos.derivaciones.atendidos';
        if ($estado == DerivacionAttr::ESTADO_ARCHIVADO)
            return 'procesos.derivaciones.archivados';
        if ($estado == DerivacionAttr::ESTADO_POR_ATENDER)
            return 'procesos.derivaciones.porAtender';
        return 'procesos.derivaciones.porRecibir';
    }
}
