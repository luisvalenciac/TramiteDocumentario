<?php

namespace App\Config\Permisos;

class VerbosPermisos
{
    const EDITAR = 'editar';
    const ELIMINAR = 'eliminar';
    const MOSTRAR = 'mostrar';
    const ACTUALIZAR = 'actualizar';
    const CREAR = 'crear';
    const LISTAR = 'listar';
    const TODOS = '*';

    static function getVerbos()
    {
        return [
            self::EDITAR => "Editar",
            self::ELIMINAR => "Eliminar",
            self::MOSTRAR => "Ver detalle",
            self::ACTUALIZAR => "Actualizar",
            self::CREAR => "Crear",
            self::TODOS => "Todos los permisos hacia",
            self::LISTAR => "Ver lista de",
        ];
    }
}
