<?php

namespace App\Config\Permisos;

class DefaultRoles
{
    const ADMIN_SISTEMA = 'admin_sistema';
    const ADMINISTRADOR = 'administrador';
    const SECRETARIO = 'secretario';

    static function getAllRoles()
    {
        return [
            self::ADMIN_SISTEMA => 'Administrador del sistema',
            self::ADMINISTRADOR => 'Administrador',
            self::SECRETARIO => 'Secretario',
        ];
    }

    static function getNormalRoles()
    {
        return [
            self::ADMINISTRADOR => 'Administrador',
            self::SECRETARIO => 'Secretario',
        ];
    }
}
