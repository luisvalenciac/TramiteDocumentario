<?php

namespace App\Config\Cleaners;

use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use Illuminate\Support\Arr;

class DatosCrearSolicitudCleaner extends DatosCleaner
{
    private $tiposSolicitudService;
    private $tramiteService;
    private $configTramiteService;

    public function __construct($datos, $tiposSolicitudService, $tramiteService, $configTramiteService)
    {
        parent::__construct($datos);
        $this->tiposSolicitudService = $tiposSolicitudService;
        $this->tramiteService = $tramiteService;
        $this->configTramiteService = $configTramiteService;
    }

    public function getCleanData()
    {
        $this->setDataFaltante();
        $this->removerDataCondicional();
        return $this->datos;
    }

    private function setDataFaltante()
    {
        $this->datos[TramiteTablaInfo::PRIORIDAD] = TramiteTablaInfo::prioridadesDict()['normal'];
        $this->datos[TramiteTablaInfo::FECHA_EMISION] = date('Y-m-d');
        $this->datos[TramiteTablaInfo::FORMA_RECEPCION] = TramiteTablaInfo::RECEPCION_WEB;
        $tipoSolicitud = $this->tiposSolicitudService->buscarPorId($this->datos[TramiteTablaInfo::TIPO_SOLICITUD_ID]);
        $nombreTipoSolicitud = $this->getNombreTipoSolicitud($tipoSolicitud);
        $userTramite = $this->configTramiteService->getConfigTramite()->userRecibeSolicitud;
        $this->datos[TramiteTablaInfo::USER_CREADOR_ID] = $userTramite->id;
        $this->datos[TramiteTablaInfo::USER_EXPEDIENTE_ID] = $userTramite->id;
        $this->datos[TramiteTablaInfo::NUMERO_TRAMITE] = $this->generarNumeroTramite();
        $this->datos[TramiteTablaInfo::FOLIOS] = $nombreTipoSolicitud . " - Folios";
        $this->datos[TramiteTablaInfo::ASUNTO] = $nombreTipoSolicitud . " - Asunto";
        $this->datos[TramiteTablaInfo::REFERENCIA] = $nombreTipoSolicitud . " - Referencia";
        $this->datos[TramiteTablaInfo::ANEXOS] = $nombreTipoSolicitud . " - Anexos";
        $this->datos[TramiteTablaInfo::DERIVACIONES] = [
            0 => [
                DerivacionTablaInfo::ES_COPIA => false,
                DerivacionTablaInfo::AREA_DESTINO_ID => $userTramite->area->id,
                DerivacionTablaInfo::USER_DESTINO_ID => $userTramite->id,
                DerivacionTablaInfo::PROVEIDO => 'Proveido - ' . $nombreTipoSolicitud,
                DerivacionTablaInfo::DETALLE => $this->datos[DerivacionTablaInfo::DETALLE],
                DerivacionTablaInfo::ESTADO => DerivacionTablaInfo::ESTADO_POR_RECIBIR,
            ]
        ];
    }

    private function getNombreTipoSolicitud($tipoSolicitud)
    {
        if ($tipoSolicitud)
            return $tipoSolicitud->nombre_tipo;
        return $this->datos[TramiteTablaInfo::OTRO_TIPO_SOLICITUD];
    }

    private function removerDataCondicional()
    {
        $this->removerDataIncluyePago();
    }

    private function removerDataIncluyePago()
    {
        $incluyePago = Arr::get($this->datos, TramiteTablaInfo::INCLUYE_PAGO);
        if (!$incluyePago)
            Arr::pull($this->datos, TramiteTablaInfo::ADJUNTO_PAGO);
    }

    private function generarNumeroTramite()
    {
        return $this->tramiteService->generarNumeroTramite();
    }
}
