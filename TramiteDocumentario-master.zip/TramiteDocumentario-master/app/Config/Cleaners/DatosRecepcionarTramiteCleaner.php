<?php

namespace App\Config\Cleaners;

use App\TablaInfo\DerivacionTablaInfo as DerivacionAttr;
use Illuminate\Support\Facades\Auth;

class DatosRecepcionarTramiteCleaner extends DatosCleaner
{

    public function getCleanData()
    {
        $this->setDataFaltante();
        return $this->datos;
    }

    private function setDataFaltante()
    {
        $loggedUser = Auth::user();
        $this->datos[DerivacionAttr::ES_COPIA] = false;
        $this->datos[DerivacionAttr::AREA_DESTINO_ID] = $loggedUser->area->id;
        $this->datos[DerivacionAttr::USER_DESTINO_ID] = $loggedUser->id;
    }
}
