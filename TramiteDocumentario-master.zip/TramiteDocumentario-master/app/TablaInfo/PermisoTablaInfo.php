<?php


namespace App\TablaInfo;


class PermisoTablaInfo
{
    const ID = 'id';
    const NOMBRE = 'name';

    static function nombreTabla()
    {
        $nombreTablas = config('permission.table_names');
        return $nombreTablas['permissions'];
    }
}
