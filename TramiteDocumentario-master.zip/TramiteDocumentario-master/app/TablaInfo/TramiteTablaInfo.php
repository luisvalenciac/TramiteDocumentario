<?php

namespace App\TablaInfo;

use App\Config\Permisos\VerbosPermisos;

class TramiteTablaInfo
{
    const NOMBRE_TABLA = 'tramites';
    const ID = 'id';
    const PRIORIDAD = 'prioridad';
    const USER_CREADOR_ID = 'user_creador_id';
    const ARCHIVADOR_ID = 'archivador_id';
    const USER_EXPEDIENTE_ID = 'user_origen_id';
    const FECHA_EMISION = 'fecha_emision';
    const TIPO_SOLICITUD_ID = 'tipo_solicitud_id';
    const OTRO_TIPO_SOLICITUD = 'otro_tipo_solicitud';
    const TIPO_SOLICITANTE = 'tipo_solicitante';
    const DATO_IDENTIFICACION = 'dato_identificacion';
    const NUMERO_TRAMITE = 'numero_tramite';
    const FORMA_RECEPCION = 'forma_recepcion';
    const ARCHIVO_TRAMITE = 'archivo_tramite';
    const FOLIOS = 'folios';
    const ASUNTO = 'asunto';
    const ANEXOS = 'anexos';
    const REFERENCIA = 'referencia';
    const CODIGO_PAGO = 'codigo_pago';
    const ADJUNTO_PAGO = 'adjunto_pago';
    const FECHA_CREADO = 'fecha_creado';

    const DERIVACIONES = 'derivaciones';
    const DERIVACIONES_ATTR = 'derivaciones.*.';

    const FECHA_ACTUALIZADO = 'fecha_actualizado';
    const INCLUYE_PAGO = 'incluye_pago';

    const PERM_CREAR_TRAMITE = 'crearTramite';
    const PERM_DETALLE_TRAMITE = 'verDetalleTramite';

    const RECEPCION_DIRECTA = 'directa';
    const RECEPCION_FAX = 'fax';
    const RECEPCION_WEB = 'via_web';

    const TIPO_USER_ESTUDIANTE = 'estudiante';
    const TIPO_USER_JURIDICO = 'juridico';
    const TIPO_USER_NORMAL = 'normal';
    const TIPO_USER_TRABAJADOR = 'trabajador';

    static function getPrivateTiposSolicitante()
    {
        return [
            self::TIPO_USER_TRABAJADOR => 'Personal trabajador',
            self::TIPO_USER_ESTUDIANTE => 'Estudiante',
            self::TIPO_USER_JURIDICO => 'Persona Juridíca',
            self::TIPO_USER_NORMAL => 'Persona Natural',
        ];
    }

    static function getPublicTiposSolicitante()
    {
        return [

            self::TIPO_USER_ESTUDIANTE => 'Estudiante',
            self::TIPO_USER_JURIDICO => 'Persona Juridíca',
            self::TIPO_USER_NORMAL => 'Persona Natural',
        ];
    }

    static function getPermisos()
    {
        return [
            self::PERM_CREAR_TRAMITE => 'Crear trámites',
            self::PERM_DETALLE_TRAMITE => 'Ver detalle de trámite',
            VerbosPermisos::TODOS => 'Todos los permisos hacia trámites',
        ];
    }

    static function prioridadesDict()
    {
        return [
            'normal' => 'Normal',
            'urgente' => 'Urgente',
        ];
    }

    static function formasRecepcionDict()
    {
        return [
            self::RECEPCION_DIRECTA => 'Directa',
            self::RECEPCION_FAX => "Fax",
            self::RECEPCION_WEB => "Via Web",
        ];
    }
}
