<?php

namespace App\TablaInfo;

class HistorialCambioEstadoTablaInfo
{
    const NOMBRE_TABLA = 'historial_cambios_estado';
    const ID = 'id';
    const DERIVACION_ID = 'derivacion_id';
    const CAMBIADO_DE = 'cambiado_de';
    const CAMBIADO_HACIA = 'cambiado_hacia';
    const FECHA_DE_CAMBIO = 'fecha_de_cambio';
}
