<?php

namespace App\TablaInfo;

class AdjuntoTablaInfo
{
    const NOMBRE_TABLA = 'adjuntos';

    const ID = 'id';
    const DERIVACION_ID = 'derivacion_id';
    const NOMBRE_ADJUNTO = 'nombre_adjunto';
    const ADJUNTO = 'adjunto';
    const FECHA_CREADO = 'fecha_creado';
    const FECHA_ACTUALIZADO = 'fecha_actualizado';
}
