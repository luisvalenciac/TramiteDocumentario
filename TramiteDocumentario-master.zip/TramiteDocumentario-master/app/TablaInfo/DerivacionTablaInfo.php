<?php

namespace App\TablaInfo;

class DerivacionTablaInfo
{
    const NOMBRE_TABLA = 'derivaciones';
    const ID = 'id';
    const TRAMITE_ID = 'tramite_id';
    const ES_COPIA = 'es_copia';
    const AREA_DESTINO_ID = 'area_destino_id';
    const USER_DESTINO_ID = 'user_destino_id';
    const ARCHIVADOR_ID = 'archivador_id';
    const DETALLE = 'detalle';
    const PROVEIDO = 'proveido';
    const ESTADO = 'estado';
    const FECHA_CREADO = 'fecha_creado';
    const FECHA_ACTUALIZADO = 'fecha_actualizado';

    const ADJUNTOS = 'adjuntos';
    const ADJUNTOS_ATTR = 'adjuntos.*.';

    const ESTADO_POR_RECIBIR = 'por_recibir';
    const ESTADO_POR_ATENDER = 'por_atender';
    const ESTADO_ATENDIDO = 'atendido';
    const ESTADO_ARCHIVADO = 'archivado';

    const PERM_VER_ESTADOS_TRAMITES = 'verEstadosTramite';
    const PERM_EXPORTAR = 'exportarDerivaciones';

    private static $instance = null;

    static function getInstance()
    {
        if (!self::$instance instanceof self)
            self::$instance = new self();
        return self::$instance;
    }

    static function permisos()
    {
        return [
            self::PERM_EXPORTAR => 'Exportar trámites',
            self::PERM_VER_ESTADOS_TRAMITES => 'Ver estados de trámite',
        ];
    }

    static function estadoDerivacionDict()
    {
        return [
            self::ESTADO_POR_RECIBIR => 'Por recibir',
            self::ESTADO_POR_ATENDER => 'Por atender',
            self::ESTADO_ATENDIDO => 'Atendido',
            self::ESTADO_ARCHIVADO => 'Archivado',
        ];
    }

}
