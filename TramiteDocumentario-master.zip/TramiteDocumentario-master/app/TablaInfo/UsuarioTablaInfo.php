<?php

namespace App\TablaInfo;

class UsuarioTablaInfo
{
    const NOMBRE_TABLA = 'usuarios';
    const ID = 'id';
    const AREA_ID = 'area_id';
    const USERNAME = 'username';
    const NOMBRES = 'nombres';
    const APELLIDOS = 'apellidos';
    const DNI = 'dni';
    const CARGO = 'cargo';
    const DIRECCION = 'direccion';
    const CORREO = 'correo';
    const TELEFONO = 'telefono';
    const PASSWORD = 'password';
    const FECHA_CORREO_VERIFICADO = 'fecha_correo_verificado';
    const ESTA_ACTIVO = 'esta_activo';
    const TOKEN_RECORDAR_PASS = 'remember_token';
    const FECHA_CREADO = 'fecha_creado';
    const FECHA_ACTUALIZADO = 'fecha_actualizado';
    const CAMBIAR_PASSWORD = 'change_password';
    const ROL = 'rol';

    const PERM_VER_DASHBOARD = 'verDashboard';
}
