<?php

namespace App\TablaInfo;

class ArchivadorTablaInfo
{
    const NOMBRE_TABLA = 'archivadores';
    const ID = 'id';
    const AREA_ID = 'area_id';
    const NOMBRE = 'nombre';
    const PERIODO = 'periodo';
    const FECHA_CREADO = 'fecha_creado';
    const FECHA_ACTUALIZADO = 'fecha_actualizado';
}
