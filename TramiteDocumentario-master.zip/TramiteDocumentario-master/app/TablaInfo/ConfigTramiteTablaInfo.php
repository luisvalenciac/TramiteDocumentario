<?php

namespace App\TablaInfo;

class ConfigTramiteTablaInfo
{
    const NOMBRE_TABLA = 'configuracion_tramites';
    const USER_RECIBE_SOLICITUD_ID = 'user_recibe_solicitud_id';
    const FECHA_ACTUALIZADO = 'fecha_actualizado';
    const FECHA_CREADO = 'fecha_creado';
    const CONFIG_KEY = 'config_key';
    const PERM_VER_COFIGURACION = 'verConfiguraciones';
    const KEY_VALUE = '123';

    private static $instance = null;

    static function getInstance()
    {
        if (!self::$instance instanceof self)
            self::$instance = new self();
        return self::$instance;
    }


    static function permisos()
    {
        return [
            self::PERM_VER_COFIGURACION => 'Ver configuraciones',
        ];
    }
}
