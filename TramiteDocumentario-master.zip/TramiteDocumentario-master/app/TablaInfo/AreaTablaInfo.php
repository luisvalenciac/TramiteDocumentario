<?php

namespace App\TablaInfo;

class AreaTablaInfo
{
    const NOMBRE_TABLA = 'areas';
    const ID = 'id';
    const NOMBRE = 'nombre';
    const ABREVIATURA = 'abreviatura';
    const SIGLAS = 'siglas';
    const TIPO_AREA = 'tipo_area';
    const USER_RESPONSABLE_ID = 'user_responsable_id';
    const FECHA_CREADO = 'fecha_creado';
    const FECHA_ACTUALIZADO = 'fecha_actualizado';

    const NOMBRE_AREA_POR_DEFECTO = 'Trámite documentario';
    const ABREVIATURA_AREA_POR_DEFECTO = 'Trámite-Doc';
    const SIGLAS_AREA_POR_DEFECTO = 'TD';


    static function tiposAreaDict()
    {
        return [
            'unidad_organica' => 'Unidad Orgánica',
            'area' => 'Área',
            'comision' => 'Comisión',
        ];
    }
}
