<?php

namespace App\Policies;

use App\Config\Permisos\DefaultRoles;
use App\Config\Permisos\VerbosPermisos;
use App\Models\Usuario;
use App\TablaInfo\RolTablaInfo;
use Illuminate\Auth\Access\HandlesAuthorization;
use Spatie\Permission\Models\Role;

class RolPolicy
{
    use HandlesAuthorization;

    private $nombreTabla;

    public function __construct()
    {
        $this->nombreTabla = RolTablaInfo::nombreTabla();
    }

    public function viewAny(Usuario $loggedUser)
    {
        $listar = $this->nombreTabla . '.' . VerbosPermisos::LISTAR;
        return $loggedUser->can($listar);
    }

    public function view(Usuario $loggedUser, Role $role)
    {
        $mostrar = $this->nombreTabla . '.' . VerbosPermisos::MOSTRAR;
        return $loggedUser->can($mostrar);
    }

    public function create(Usuario $loggedUser)
    {
        $crear = $this->nombreTabla . '.' . VerbosPermisos::CREAR;
        return $loggedUser->can($crear);
    }

    public function update(Usuario $loggedUser, Role $role)
    {
        $actualizar = $this->nombreTabla . '.' . VerbosPermisos::ACTUALIZAR;
        return $loggedUser->can($actualizar);
    }

    public function delete(Usuario $loggedUser, Role $role)
    {
        $eliminar = $this->nombreTabla . '.' . VerbosPermisos::ELIMINAR;
        return $loggedUser->can($eliminar);
    }
}
