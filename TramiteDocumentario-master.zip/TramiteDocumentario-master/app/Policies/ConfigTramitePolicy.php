<?php

namespace App\Policies;

use App\Models\Usuario;
use App\TablaInfo\ConfigTramiteTablaInfo;
use Illuminate\Auth\Access\HandlesAuthorization;

class ConfigTramitePolicy
{
    use HandlesAuthorization;

    public function verConfiguraciones(Usuario $loggedUser)
    {
        $verConfiguracion = ConfigTramiteTablaInfo::NOMBRE_TABLA . '.' . ConfigTramiteTablaInfo::PERM_VER_COFIGURACION;
        return $loggedUser->can($verConfiguracion);
    }
}
