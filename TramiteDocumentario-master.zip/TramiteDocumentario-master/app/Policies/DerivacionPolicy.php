<?php

namespace App\Policies;

use App\Models\Usuario;
use App\TablaInfo\DerivacionTablaInfo;
use Illuminate\Auth\Access\HandlesAuthorization;

class DerivacionPolicy
{
    use HandlesAuthorization;

    public function verEstadosDeTramite(Usuario $loggedUser)
    {
        $verDerivados = DerivacionTablaInfo::NOMBRE_TABLA . '.' . DerivacionTablaInfo::PERM_VER_ESTADOS_TRAMITES;
        return $loggedUser->can($verDerivados);
    }

    public function exportarDerivaciones(Usuario $loggedUser)
    {
        $exportar = DerivacionTablaInfo::NOMBRE_TABLA . '.' . DerivacionTablaInfo::PERM_EXPORTAR;
        return $loggedUser->can($exportar);
    }
}
