<?php

namespace App\Policies;

use App\Models\Tramite;
use App\Models\Usuario;
use App\TablaInfo\TramiteTablaInfo;
use Illuminate\Auth\Access\HandlesAuthorization;

class TramitePolicy
{
    use HandlesAuthorization;

    public function crearTramite(Usuario $loggedUser)
    {
        $crear = TramiteTablaInfo::NOMBRE_TABLA . '.' . TramiteTablaInfo::PERM_CREAR_TRAMITE;
        return $loggedUser->can($crear);
    }

    public function verDetalleTramite(Usuario $loggedUser, Tramite $tramite)
    {
        $verDetalle = TramiteTablaInfo::NOMBRE_TABLA . '.' . TramiteTablaInfo::PERM_DETALLE_TRAMITE;
        return $loggedUser->can($verDetalle);
    }
}
