<?php

namespace App\Wrappers\Vistas;

use Illuminate\Support\Facades\Auth;

class DatosActualizarUsuario
{
    public $areas;
    public $usuario;
    public $roles;

    public function __construct($usuario, $roleService, $areaService)
    {
        $this->usuario = $usuario;
        $this->areas = $areaService->areas('*')->get();
        $this->roles = $roleService->roles(Auth::user());
    }
}
