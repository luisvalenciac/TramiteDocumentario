<?php

namespace App\Wrappers\Vistas;

use App\Contracts\AreaRepository;
use App\Models\Archivador;

class DatosActualizarArchivador
{
    public $archivador;
    public $areas;

    public function __construct(Archivador $archivador, AreaRepository $areaService)
    {
        $this->archivador = $archivador;
        $this->areas = $areaService->areas()->get();
    }
}
