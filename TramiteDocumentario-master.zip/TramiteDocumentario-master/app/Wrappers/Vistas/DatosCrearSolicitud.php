<?php

namespace App\Wrappers\Vistas;

use App\Contracts\TipoSolicitudRepository;
use App\TablaInfo\TramiteTablaInfo;

class DatosCrearSolicitud
{
    public $tiposSolicitud;
    public $tiposSolicitante;

    public function __construct(TipoSolicitudRepository $tiposSolicitud)
    {
        $this->tiposSolicitud = $tiposSolicitud->tiposSolicitud('*');
        $this->tiposSolicitante = TramiteTablaInfo::getPublicTiposSolicitante();
    }
}
