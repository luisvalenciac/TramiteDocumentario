<?php

namespace App\Wrappers\Vistas;

use App\Contracts\AreaRepository;
use App\Contracts\UsuarioRepository;
use App\TablaInfo\UsuarioTablaInfo;

class DatosListarAreas
{
    public $areas;
    private $userService;

    public function __construct(AreaRepository $areaService, UsuarioRepository $userService, $request)
    {
        $this->areas = $areaService->areasFiltradas($request);
        $this->userService = $userService;
    }

    public function getUserPorId($userId)
    {
        return $userId == 0 ? null : $this->userService->buscarPor(UsuarioTablaInfo::ID, $userId);
    }
}
