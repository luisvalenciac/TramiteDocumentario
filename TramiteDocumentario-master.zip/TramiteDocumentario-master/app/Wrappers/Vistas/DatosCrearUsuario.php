<?php

namespace App\Wrappers\Vistas;

use Illuminate\Support\Facades\Auth;

class DatosCrearUsuario
{
    public $areas;
    public $roles;

    public function __construct($areaService, $roleService)
    {
        $this->areas = $areaService->areas('*')->get();
        $this->roles = $roleService->roles(Auth::user());
    }
}
