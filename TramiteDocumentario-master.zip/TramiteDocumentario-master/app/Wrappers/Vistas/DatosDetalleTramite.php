<?php

namespace App\Wrappers\Vistas;

use App\Models\Tramite;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;

class DatosDetalleTramite
{
    public $tramite;
    public $prioridadDict;
    public $estadosDerivacionDict;
    public $formasRecepcionDict;
    public $tiposSolicitante;

    public function __construct(Tramite $tramite)
    {
        $this->tramite = $tramite;
        $this->prioridadDict = TramiteTablaInfo::prioridadesDict();
        $this->estadosDerivacionDict = DerivacionTablaInfo::estadoDerivacionDict();
        $this->formasRecepcionDict = TramiteTablaInfo::formasRecepcionDict();
        $this->tiposSolicitante = TramiteTablaInfo::getPrivateTiposSolicitante();
    }
}
