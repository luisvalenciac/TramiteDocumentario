<?php

namespace App\Wrappers\Vistas;

use App\Contracts\TipoSolicitudRepository;
use App\Contracts\UsuarioRepository;
use App\Exports\DerivacionExport;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;

class DatosExportarDerivaciones
{
    public $prioridadDict;
    public $estadosDerivacionDict;
    public $tiposSolicitud;
    public $formasRecepcion;
    public $extensionesArchivo;
    private $userService;

    public function __construct(UsuarioRepository $userService, TipoSolicitudRepository $tipoSolicitudService)
    {
        $this->prioridadDict = TramiteTablaInfo::prioridadesDict();
        $this->estadosDerivacionDict = DerivacionTablaInfo::estadoDerivacionDict();
        $this->tiposSolicitud = $tipoSolicitudService->tiposSolicitud('*');
        $this->formasRecepcion = TramiteTablaInfo::formasRecepcionDict();
        $this->userService = $userService;
        $this->extensionesArchivo = DerivacionExport::getSopportedExtensions();
    }

    public function getUserPorId($id)
    {
        return $id == 0 ? null : $this->userService->buscarPor(UsuarioTablaInfo::ID, $id);
    }
}
