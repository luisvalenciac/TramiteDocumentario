<?php

namespace App\Wrappers\Vistas;

use App\TablaInfo\PermisoTablaInfo;

class DatosActualizarRol
{
    public $permisos;
    public $rol;
    public $permisosRol;

    public function __construct($rol, $permisoService)
    {
        $this->rol = $rol;
        $this->permisos = $permisoService->permisos();
        $this->permisosRol = $this->rol->permissions()->get();
    }

    public function estaSeleccionado($permiso)
    {
        $permiso = $this->permisosRol->where(PermisoTablaInfo::NOMBRE, $permiso->name)->first();
        return isset($permiso);
    }

}
