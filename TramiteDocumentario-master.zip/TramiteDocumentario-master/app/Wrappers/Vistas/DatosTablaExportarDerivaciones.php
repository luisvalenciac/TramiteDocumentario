<?php

namespace App\Wrappers\Vistas;

use App\Contracts\DerivacionRepository;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TramiteTablaInfo;

class DatosTablaExportarDerivaciones
{
    public $derivaciones;
    public $formasRecepcion;
    public $estadosDict;
    public $tiposSolicitante;
    public $esPDF;

    public function __construct(DerivacionRepository $derivacionService, $request)
    {
        $this->derivaciones = $this->getDerivaciones($derivacionService, $request);
        $this->formasRecepcion = TramiteTablaInfo::formasRecepcionDict();
        $this->estadosDict = DerivacionTablaInfo::estadoDerivacionDict();
        $this->tiposSolicitante = TramiteTablaInfo::getPrivateTiposSolicitante();
        $this->esPDF = false;
    }

    private function getDerivaciones($derivacionService, $request)
    {
        $cantidad = $request->input('cantidad');
        $derivaciones = $derivacionService->derivacionesFiltradas($request, '*');
        if ($cantidad == '*')
            return $derivaciones->get();
        return $derivaciones->limit($cantidad)->get();
    }
}
