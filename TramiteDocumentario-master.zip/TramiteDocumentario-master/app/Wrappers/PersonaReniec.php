<?php


namespace App\Wrappers;

use App\TablaInfo\UsuarioTablaInfo;
use Peru\Reniec\Person;

class PersonaReniec
{
    public $dni;
    public $nombres;
    public $apellidos;
    public $seEncontro;

    public function __construct(Person $persona)
    {
        $this->dni = $persona->dni;
        $this->nombres = $persona->nombres;
        $this->apellidos = "{$persona->apellidoPaterno} {$persona->apellidoMaterno}";
        $this->seEncontro = $persona->codVerifica != -1;
    }

    public function getDatosCrearUsuario()
    {
        return [
            UsuarioTablaInfo::DNI => $this->dni,
            UsuarioTablaInfo::NOMBRES => $this->seEncontro ? $this->nombres : "Sin nomrbe",
            UsuarioTablaInfo::APELLIDOS => $this->seEncontro ? $this->apellidos : "Sin apellidos",
        ];
    }
}
