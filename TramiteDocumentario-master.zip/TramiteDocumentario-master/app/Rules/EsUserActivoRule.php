<?php

namespace App\Rules;

use App\Contracts\UsuarioRepository;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Contracts\Validation\Rule;

class EsUserActivoRule implements Rule
{
    private $userService;
    private $idUser;

    public function __construct(UsuarioRepository $userService, $idUser = null)
    {
        $this->userService = $userService;
        $this->idUser = $idUser;
    }

    public function passes($attribute, $value)
    {
        $user = $this->buscarUser($value);
        if ($user)
            return $user->esta_activo;
        return true;
    }

    public function message()
    {
        return 'El usuario se encuentra inactivo.';
    }

    private function buscarUser($value)
    {
        if (isset($this->idUser))
            return $this->userService->buscarPor(UsuarioTablaInfo::ID, $this->idUser, '*');
        return $this->userService->buscarPor(UsuarioTablaInfo::ID, $value, '*');
    }
}
