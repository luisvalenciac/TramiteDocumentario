<?php

namespace App\Rules;

use App\Contracts\UsuarioRepository;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Contracts\Validation\Rule;

class UserPerteneceAreaRule implements Rule
{
    private $userService;
    private $idUser;

    public function __construct(UsuarioRepository $userService, $idUser = null)
    {
        $this->userService = $userService;
        $this->idUser = $idUser;
    }

    public function passes($attribute, $value)
    {
        $user = $this->buscarUser($value);
        if ($user)
            return isset($user->area);
        return true;
    }

    public function message()
    {
        return 'El usuario debe pertenecer a un área.';
    }

    private function buscarUser($value)
    {
        if (isset($this->idUser))
            return $this->userService->buscarPor(UsuarioTablaInfo::ID, $this->idUser, '*');
        return $this->userService->buscarPor(UsuarioTablaInfo::ID, $value, '*');
    }
}
