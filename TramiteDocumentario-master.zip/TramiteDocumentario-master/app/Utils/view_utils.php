<?php

use App\Config\Permisos\DefaultRoles;
use App\TablaInfo\DerivacionTablaInfo;
use Illuminate\Support\Carbon;

function setActive($route)
{
    return request()->routeIs($route) ? 'menuitem-active' : '';
}

function setActiveWithQuery($route)
{
    return url()->full() == $route ? 'menuitem-active' : '';
}

function getRolAdminSistema()
{
    return DefaultRoles::ADMIN_SISTEMA;
}

function getFechaFormateada($fechaStr, $format = 'l d M Y')
{
    try {
        $carbonDate = Carbon::parse($fechaStr);
        return $carbonDate->translatedFormat($format);
    } catch (Exception $e) {
        return now()->format($format);
    }
}

function derivacionTablaInfo()
{
    return DerivacionTablaInfo::getInstance();
}
