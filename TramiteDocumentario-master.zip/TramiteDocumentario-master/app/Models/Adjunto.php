<?php

namespace App\Models;

use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\AdjuntoTablaInfo;
use Illuminate\Database\Eloquent\Model;

class Adjunto extends Model
{
    public const CREATED_AT = AdjuntoTablaInfo::FECHA_CREADO;
    public const UPDATED_AT = AdjuntoTablaInfo::FECHA_ACTUALIZADO;
    protected $table = AdjuntoTablaInfo::NOMBRE_TABLA;

    protected $fillable = [
        AdjuntoTablaInfo::DERIVACION_ID,
        AdjuntoTablaInfo::NOMBRE_ADJUNTO,
        AdjuntoTablaInfo::ADJUNTO,
    ];

    public function derivacion()
    {
        $this->belongsTo('App\Models\Derivacion', AdjuntoTablaInfo::DERIVACION_ID,
            DerivacionTablaInfo::ID);
    }
}
