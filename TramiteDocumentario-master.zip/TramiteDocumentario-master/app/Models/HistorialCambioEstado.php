<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\HistorialCambioEstadoTablaInfo;

class HistorialCambioEstado extends Model
{
    public $timestamps = false;
    protected $table = HistorialCambioEstadoTablaInfo::NOMBRE_TABLA;

    protected $fillable = [
        HistorialCambioEstadoTablaInfo::DERIVACION_ID,
        HistorialCambioEstadoTablaInfo::CAMBIADO_DE,
        HistorialCambioEstadoTablaInfo::CAMBIADO_HACIA,
        HistorialCambioEstadoTablaInfo::FECHA_DE_CAMBIO
    ];

    public function derivacion()
    {
        return $this->belongsTo('App\Models\Derivacion', HistorialCambioEstadoTablaInfo::DERIVACION_ID,
            DerivacionTablaInfo::ID);
    }
}
