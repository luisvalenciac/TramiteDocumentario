<?php

namespace App\Models;

use App\TablaInfo\TipoSolicitudTablaInfo;
use EloquentFilter\Filterable;
use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Traits\HasRoles;

class TipoSolicitud extends Model
{
    use HasRoles;
    use Filterable;

    public $timestamps = false;
    protected $table = TipoSolicitudTablaInfo::NOMBRE_TABLA;

    protected $fillable = [
      TipoSolicitudTablaInfo::NOMBRE_TIPO
    ];
}
