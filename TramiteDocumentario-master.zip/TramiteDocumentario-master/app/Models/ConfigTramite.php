<?php

namespace App\Models;

use App\TablaInfo\ConfigTramiteTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Traits\HasRoles;

class ConfigTramite extends Model
{
    use HasRoles;

    const CREATED_AT = ConfigTramiteTablaInfo::FECHA_CREADO;
    const UPDATED_AT = ConfigTramiteTablaInfo::FECHA_ACTUALIZADO;
    protected $table = ConfigTramiteTablaInfo::NOMBRE_TABLA;
    protected $fillable = [
        ConfigTramiteTablaInfo::USER_RECIBE_SOLICITUD_ID,
        ConfigTramiteTablaInfo::CONFIG_KEY,
    ];

    public function userRecibeSolicitud()
    {
        return $this->hasOne('App\Models\Usuario', UsuarioTablaInfo::ID,
            ConfigTramiteTablaInfo::USER_RECIBE_SOLICITUD_ID);
    }


}
