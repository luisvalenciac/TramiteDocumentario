<?php

namespace App\Models;

use App\TablaInfo\DerivacionTablaInfo;
use App\TablaInfo\TipoSolicitudTablaInfo;
use App\TablaInfo\TramiteTablaInfo;
use App\TablaInfo\UsuarioTablaInfo;
use EloquentFilter\Filterable;
use Illuminate\Database\Eloquent\Model;
use Spatie\Permission\Traits\HasRoles;

class Tramite extends Model
{
    use HasRoles;
    use Filterable;

    const CREATED_AT = TramiteTablaInfo::FECHA_CREADO;
    const UPDATED_AT = TramiteTablaInfo::FECHA_ACTUALIZADO;
    protected $table = TramiteTablaInfo::NOMBRE_TABLA;
    protected $fillable = [
        TramiteTablaInfo::PRIORIDAD,
        TramiteTablaInfo::USER_CREADOR_ID,
        TramiteTablaInfo::USER_EXPEDIENTE_ID,
        TramiteTablaInfo::FECHA_EMISION,
        TramiteTablaInfo::TIPO_SOLICITUD_ID,
        TramiteTablaInfo::OTRO_TIPO_SOLICITUD,
        TramiteTablaInfo::TIPO_SOLICITANTE,
        TramiteTablaInfo::DATO_IDENTIFICACION,
        TramiteTablaInfo::NUMERO_TRAMITE,
        TramiteTablaInfo::FORMA_RECEPCION,
        TramiteTablaInfo::ARCHIVO_TRAMITE,
        TramiteTablaInfo::FOLIOS,
        TramiteTablaInfo::ASUNTO,
        TramiteTablaInfo::ANEXOS,
        TramiteTablaInfo::REFERENCIA,
        TramiteTablaInfo::CODIGO_PAGO,
        TramiteTablaInfo::ADJUNTO_PAGO,
    ];

    public function userOrigen()
    {
        return $this->hasOne('App\Models\Usuario', UsuarioTablaInfo::ID,
            TramiteTablaInfo::USER_EXPEDIENTE_ID);
    }

    public function tipoSolicitud()
    {
        return $this->hasOne('App\Models\TipoSolicitud', TipoSolicitudTablaInfo::ID,
            TramiteTablaInfo::TIPO_SOLICITUD_ID);
    }

    public function derivaciones()
    {
        return $this->hasMany('App\Models\Derivacion', DerivacionTablaInfo::TRAMITE_ID,
            TramiteTablaInfo::ID);
    }
}
