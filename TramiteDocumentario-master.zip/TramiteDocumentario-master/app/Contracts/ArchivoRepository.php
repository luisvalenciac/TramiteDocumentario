<?php

namespace App\Contracts;

interface ArchivoRepository
{
    public function getDisk();

    public function saveArchivosFromDatos(&$datos, $keys, $nombreCarpeta);
}
