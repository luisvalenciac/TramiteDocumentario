<?php

namespace App\Contracts;

use App\Wrappers\PersonaReniec;

interface ReniecRepository
{
    public function consultarDni(string $dni): PersonaReniec;
}
