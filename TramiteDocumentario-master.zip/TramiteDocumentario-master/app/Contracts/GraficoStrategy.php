<?php

namespace App\Contracts;

use App\TablaInfo\DerivacionTablaInfo;

abstract class GraficoStrategy
{
    protected $historialService;
    protected const MESES = [
        'Enero',
        'Febrero',
        'Marzo',
        'Abril',
        'Mayo',
        'Junio',
        'Julio',
        'Agosto',
        'Setiembre',
        'Octubre',
        'Noviembre',
        'Diciembre',
    ];

    protected $estadosTramite;

    public function __construct()
    {
        $this->estadosTramite = array_keys(DerivacionTablaInfo::estadoDerivacionDict());
    }

    public abstract function obtenerDatos();
}
