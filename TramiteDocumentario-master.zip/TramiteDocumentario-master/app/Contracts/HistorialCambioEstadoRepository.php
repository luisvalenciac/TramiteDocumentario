<?php

namespace App\Contracts;

interface HistorialCambioEstadoRepository
{
    public function registrarCambio($derivacionId, $estadoInicial, $estadoFinal);
    public function statsDerivacion($fechaInicio, $fechaFin, $estado);
}
