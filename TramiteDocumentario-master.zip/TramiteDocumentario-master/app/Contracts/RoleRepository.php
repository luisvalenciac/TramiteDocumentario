<?php

namespace App\Contracts;

interface RoleRepository
{
    public function roles($loggedUser);

    public function crearRoles($datos);

    public function editarRole($rol, $datos);

    public function eliminarRole($role);
}
