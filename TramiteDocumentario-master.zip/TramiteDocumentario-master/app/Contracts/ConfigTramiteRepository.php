<?php

namespace App\Contracts;

interface ConfigTramiteRepository
{
    public function actualizarConfig($datos);

    public function getConfigTramite();

    public function existeUserConfigTramite();
}
