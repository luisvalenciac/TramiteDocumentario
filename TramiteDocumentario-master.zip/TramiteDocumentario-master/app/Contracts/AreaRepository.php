<?php

namespace App\Contracts;

interface AreaRepository
{
    public function areasFiltradas($request, $cantidad = 15);

    public function crear($datos);

    public function actualizar($area, $datos);

    public function eliminar($area);

    public function buscar($termino);

    public function buscarPor($attr, $valor);

    public function areaTramiteDocumentario();

    public function areas();
}
