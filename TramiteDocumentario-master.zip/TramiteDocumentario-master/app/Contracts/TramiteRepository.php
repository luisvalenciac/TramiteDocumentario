<?php

namespace App\Contracts;

interface TramiteRepository
{
    public function tramitesFiltrados($request, $cantidad = 15);

    public function crearTramite($datos);

    public function buscarPor($attr, $valor, $buscarEnTodos = '*');

    public function ultimoTramite();

    public function generarNumeroTramite();
}
