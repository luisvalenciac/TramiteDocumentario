<?php

namespace App\Contracts;

interface ArchivadorRepository
{
    public function archivadoresFiltrados($request, $cantidad = 15);

    public function crear($datos);

    public function actualizar($archivador, $datos);

    public function allArchivadores();

    public function buscar($termino, $cantidad = 15);

    public function buscarPor($attr, $value);
}
