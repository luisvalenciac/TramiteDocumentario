<?php

namespace App\ModelFilters;

use App\TablaInfo\UsuarioTablaInfo;
use EloquentFilter\ModelFilter;

class UsuarioFilter extends ModelFilter
{
    public $relations = [];

    public function nombres($value)
    {
        return $this->where(UsuarioTablaInfo::NOMBRES, 'LIKE', "%{$value}%")
            ->orWhere(UsuarioTablaInfo::APELLIDOS, 'LIKE', "%{$value}%");
    }

    public function correo($value)
    {
        return $this->where(UsuarioTablaInfo::CORREO, 'LIKE', "%{$value}%");
    }

    public function area($value)
    {
        return $this->where(UsuarioTablaInfo::AREA_ID, '=', $value);
    }

    public function username($value)
    {
        return $this->where(UsuarioTablaInfo::USERNAME, 'LIKE', "%{$value}%");
    }

    public function dni($value)
    {
        return $this->where(UsuarioTablaInfo::DNI, 'LIKE', "%{$value}%");
    }

    public function cargo($value)
    {
        return $this->where(UsuarioTablaInfo::CARGO, 'LIKE', "%{$value}%");
    }
}
