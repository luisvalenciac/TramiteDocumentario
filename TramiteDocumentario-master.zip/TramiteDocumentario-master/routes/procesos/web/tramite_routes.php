<?php


use App\Http\Controllers\Procesos\TramiteController;

Route::get('crear', [TramiteController::class, 'crearTramite'])
    ->name('crear')
    ->middleware('can:crearTramite,App\Models\Tramite');

Route::get('{tramite}', [TramiteController::class, 'detalleTramite'])
    ->name('detalle')
    ->middleware('can:verDetalleTramite,tramite');

Route::post('guardar', [TramiteController::class, 'guardarTramite'])
    ->name('guardar')
    ->middleware('can:crearTramite,App\Models\Tramite');
