<?php

use App\Http\Controllers\Procesos\DerivacionController;
use Illuminate\Support\Facades\Route;

Route::get('', [DerivacionController::class, 'derivaciones'])
    ->name('derivaciones')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::get('vista-recepcionar/{derivacion}', [DerivacionController::class, 'vistaRecepcionar'])
    ->name('vistaRecepcionar')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::post('recepcionar/{derivacion}', [DerivacionController::class, 'recepcionar'])
    ->name('recepcionar')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::get('vista-regresar-estado/{derivacion}', [DerivacionController::class, 'vistaRegresarEstado'])
    ->name('vistaRegresarEstado')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::post('regresar-estado/{derivacion}', [DerivacionController::class, 'regresarEstado'])
    ->name('regresarEstado')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::get('vistaAtender/{derivacion}', [DerivacionController::class, 'vistaAtender'])
    ->name('vistaAtender')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::post('atender/{derivacion}', [DerivacionController::class, 'atenderDerivacion'])
    ->name('atender')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::get('vistaDerivar/{derivacion}', [DerivacionController::class, 'vistaDerivar'])
    ->name('vistaDerivar')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::post('derivar/{derivacion}', [DerivacionController::class, 'derivar'])
    ->name('derivar')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::get('vistaAdjuntar/{derivacion}', [DerivacionController::class, 'vistaAdjuntar'])
    ->name('vistaAdjuntar')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::post('adjuntar/{derivacion}', [DerivacionController::class, 'adjuntar'])
    ->name('adjuntar')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::get('vistaArchivar/{derivacion}', [DerivacionController::class, 'vistaArchivar'])
    ->name('vistaArchivar')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::post('archivar/{derivacion}', [DerivacionController::class, 'archivar'])
    ->name('archivar')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::post('desantender/{derivacion}', [DerivacionController::class, 'desantender'])
    ->name('desantender')
    ->middleware('can:verEstadosDeTramite,App\Models\Derivacion');

Route::get('vista-exportar', [DerivacionController::class, 'vistaExportar'])
    ->name('vistaExportar')
    ->middleware('can:exportarDerivaciones,App\Models\Derivacion');

Route::get('exportar', [DerivacionController::class, 'exportar'])
    ->name('exportar')
    ->middleware('can:exportarDerivaciones,App\Models\Derivacion');

Route::prefix('api-v1')
    ->name('api.v1.')
    ->group(base_path('routes/procesos/api/derivacion_api_routes.php'));
