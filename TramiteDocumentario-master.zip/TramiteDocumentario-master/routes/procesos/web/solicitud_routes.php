<?php

use App\Http\Controllers\Procesos\PublicTramiteController;

Route::get('crear', [PublicTramiteController::class, 'crearSolicitud'])
    ->name('crear')
    ->middleware('configTramite');

Route::get('aviso', [PublicTramiteController::class, 'mensajeConfigTramite'])
    ->name('avisoConfigTramite');

Route::post('guardar', [PublicTramiteController::class, 'guardarSolicitud'])
    ->name('guardar')
    ->middleware('configTramite');

Route::get('consultar', [PublicTramiteController::class, 'consultarSolicitud'])
    ->name('consultar');
