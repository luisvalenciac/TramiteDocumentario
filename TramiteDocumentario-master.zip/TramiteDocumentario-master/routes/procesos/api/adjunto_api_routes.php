<?php

use App\Http\Controllers\API\APIAdjuntoController;
use Illuminate\Support\Facades\Route;


Route::delete('eliminar/{adjunto}', [APIAdjuntoController::class, 'eliminarAdjunto'])
    ->name('eliminar');
