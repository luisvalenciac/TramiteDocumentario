<?php

use App\Http\Controllers\API\APIArchivadorController;

Route::get('buscar', [APIArchivadorController::class, 'buscar'])
    ->name('buscar');
