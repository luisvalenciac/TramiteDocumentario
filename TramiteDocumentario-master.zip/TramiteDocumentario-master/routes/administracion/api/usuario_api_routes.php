<?php

use App\Http\Controllers\API\APIReniecController;
use App\Http\Controllers\API\APIUsuarioController;

Route::post('consulta-dni', [APIReniecController::class, 'dni'])
    ->name('reniecDni');

Route::get('buscar', [APIUsuarioController::class, 'buscarUsuario'])
    ->name('buscar');
