<?php

Route::get('dashboard', 'Administracion\DashboardController@dashboard')
    ->middleware('can:verDashboard,App\Models\Usuario')
    ->name('dashboard');

