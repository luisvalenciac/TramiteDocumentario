<?php

Route::resource('archivadores', 'Administracion\ArchivadorController');

Route::prefix('archivadores/api-v1')
    ->name('archivadores.api.v1.')
    ->group(base_path('routes/administracion/api/archivador_api_routes.php'));

