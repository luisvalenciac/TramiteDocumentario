<?php

Route::get('tipos-solicitud', 'Administracion\TipoSolicitudController@index')
    ->name('tiposSolicitud.index')->middleware('can:viewAny,App\Models\TipoSolicitud');

Route::get('tipos-solicitud/registrar', 'Administracion\TipoSolicitudController@create')
    ->name('tiposSolicitud.create')->middleware('can:create,App\Models\TipoSolicitud');

Route::post('tipos-solicitud', 'Administracion\TipoSolicitudController@store')
    ->name('tiposSolicitud.store')->middleware('can:create,App\Models\TipoSolicitud');

Route::get('tipos-solicitud/{tipoSolicitud}/editar', 'Administracion\TipoSolicitudController@edit')
    ->name('tiposSolicitud.edit')->middleware('can:update,tipoSolicitud');

Route::patch('tipos-solicitud/{tipoSolicitud}', 'Administracion\TipoSolicitudController@update')
    ->name('tiposSolicitud.update')->middleware('can:update,tipoSolicitud');

Route::delete('tipos-solicitud/{tipoSolicitud}', 'Administracion\TipoSolicitudController@destroy')
    ->name('tiposSolicitud.destroy')->middleware('can:delete,tipoSolicitud');
