<?php

Route::resource('usuarios', 'Administracion\UsuarioController');

Route::prefix('usuarios/api-v1')
    ->name('usuarios.api.v1.')
    ->group(base_path('routes/administracion/api/usuario_api_routes.php'));
