<?php


Route::resource('areas', 'Administracion\AreaController');

Route::prefix('areas/api-v1')
    ->name('areas.api.v1.')
    ->group(base_path('routes/administracion/api/area_api_routes.php'));
