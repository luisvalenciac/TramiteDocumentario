<?php

use App\Http\Controllers\Configuracion\ConfigTramiteController;

Route::get('solicitud', [ConfigTramiteController::class, 'vistaConfigTramite'])
    ->name('configTramite')
    ->middleware('can:verConfiguraciones,App\Models\ConfigTramite');

Route::post('solicitud', [ConfigTramiteController::class, 'actualizarConfigTramite'])
    ->name('guardarConfigTramite')
    ->middleware('can:verConfiguraciones,App\Models\ConfigTramite');
