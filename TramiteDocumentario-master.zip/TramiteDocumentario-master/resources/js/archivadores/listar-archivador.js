import {selectTwoConfig} from "../utils/vendorWrappers";

$(function () {
    configSelectBuscarArea($("#SelectBuscarArea"));
});

function configSelectBuscarArea(select) {

    select.select2(selectTwoConfig({
        url: select.attr('data-buscar-area-url'),
        templateResult: function (area) {
            if (area.loading)
                return "Buscando...";
            return $(`<label>${getInfoArea(area)}</label>`);
        },
        templateSelection: function (area) {
            if (area.id === '')
                return area.text;
            return area.nombre === undefined ? area.text : `${getInfoArea(area)}`;
        }
    }));

    function getInfoArea(area) {
        return `${area.nombre} - ${area.abreviatura} - ${area.siglas}`;
    }

}
