import axiosWrapper, {getBoundary} from "../utils/request";
import {configToggle, configByCheckVisibility, hacerVisible, removerCssYHtml} from "../utils/utils";
import showAlert, {MESSAGE_TYPES} from "../utils/messages";
import {configCamposOtroTipoSolicitud, configUserDerivado} from "./tramites-extracted-functions";
import {infoUser} from "../usuarios/users-extracted-functions";


$(function () {
    let checkIncluyePago = $("#CheckIncluyePago");
    configByCheckVisibility(checkIncluyePago, $("#DivCodigoPago"))
    configByCheckVisibility(checkIncluyePago, $("#DivAdjuntoPago"))

    configCamposOtroTipoSolicitud($("#SelectTipoSolicitud"), $("#DivOtroTipoSolicitud"));

    configTipoExpediente();
    configToggle($("#EsCopiaCheck"));

    let selectAreaDestino = $("#SelectAreaDestino");
    let selectUserResponsable = $("#SelectUserResponsable");
    configUserDerivado(selectAreaDestino, selectUserResponsable);
    let divErrorGeneral = $("#DivErrorGeneral");
    configTablaDerivados(selectAreaDestino, divErrorGeneral, selectUserResponsable);
}());


function configTipoExpediente() {
    let divExpedientePersonal = $("#DivExpedientePersonal");
    let divExpedienteGeneral = $("#DivExpedienteGeneral");
    let inputUserOrigen = $("#InputUserOrigen");
    let spanSiglasArea = $("#SpanSiglasArea");

    configToggle($("#CheckTipoExpediente"),
        () => {
            hacerVisible(divExpedienteGeneral, false);
            hacerVisible(divExpedientePersonal);
            let idUser = divExpedientePersonal.find("input").val();
            inputUserOrigen.val(idUser);
            spanSiglasArea.text(divExpedientePersonal.attr('data-siglas-area'))
        }, () => {
            hacerVisible(divExpedientePersonal, false);
            hacerVisible(divExpedienteGeneral);
            let idUser = divExpedienteGeneral.find("input").val();
            inputUserOrigen.val(idUser);
            spanSiglasArea.text(divExpedienteGeneral.attr('data-siglas-area'))
        });
}

function configTablaDerivados(selectAreaDestino, divErrorGeneral, selectUserDestino) {

    let tablaDerivados = $("#TablaDerivados");

    tablaDerivados.on('click', 'a.eliminar-derivado', function (e) {
        e.preventDefault();
        $(this).parent().parent().remove();
    });

    $("#BtnAddDerivado").click(function (e) {
        e.preventDefault();
        removerCssYHtml(divErrorGeneral);
        let dataDerivado = getDataForRowDerivado();
        axiosWrapper({
            method: "POST",
            url: $(this).attr('data-url-validar-derivacion'),
            data: getDataForDerivadoRequest(dataDerivado),
            loadElem: $(this),
            alertElem: divErrorGeneral,
            form: $("#DivCrearDerivacion"),
            thenFunc: () => tablaDerivados.find('tbody').append(getTemplateRowDerivado(dataDerivado)),
        });
    });

    function getTemplateRowDerivado(dataDerivado) {
        let i = tablaDerivados.find('tbody').find('tr').length;
        return `
            <tr>
                <input type="hidden" name="derivaciones[${i}][estado]" value="${dataDerivado.estado}">
                <td>
                ${dataDerivado.esCopia ? "Copia" : "Original"}
                <input type="hidden" name="derivaciones[${i}][es_copia]" value="${dataDerivado.esCopia ? 1 : 0}">
                </td>
                <td>
                ${dataDerivado.areaDestino.nombre}
                <input type="hidden" name="derivaciones[${i}][area_destino_id]" value="${dataDerivado.areaDestino.id}">
                </td>
                <td>
                   ${dataDerivado.detalle}
                   <input type="hidden" name="derivaciones[${i}][detalle]" value="${dataDerivado.detalle}">
                </td>
                <td>
                 ${dataDerivado.userResponsable.nombres}
                 <input type="hidden" name="derivaciones[${i}][user_destino_id]"
                 value="${dataDerivado.userResponsable.id}">
                </td>
                <td>
                 ${dataDerivado.proveido}
                   <input type="hidden" name="derivaciones[${i}][proveido]" value="${dataDerivado.proveido}">
                </td>
                <td>
                    <a href="#" class="eliminar-derivado">Quitar</a>
                </td>
            </tr>
        `;
    }

    function getDataForRowDerivado() {
        let divDerivacion = $("#DivCrearDerivacion");
        let areaDestino = selectAreaDestino.select2('data')[0] || {};
        let userDestino = selectUserDestino.select2('data')[0] || {};
        return {
            esCopia: divDerivacion.find("#EsCopiaCheck").prop('checked'),
            areaDestino: {
                id: areaDestino.id,
                nombre: areaDestino.text.replace(/\s/g, ""),
            },
            userResponsable: {
                id: userDestino.id,
                nombres: infoUser(userDestino),
            },
            detalle: divDerivacion.find("#InputDetalleTramite").val(),
            proveido: divDerivacion.find("#TextProveido").val(),
            estado: divDerivacion.find("#InputEstadoDerivacion").val()
        }
    }

    function getDataForDerivadoRequest(derivado) {
        return {
            es_copia: derivado.esCopia,
            area_destino_id: derivado.areaDestino.id,
            user_destino_id: derivado.userResponsable.id,
            detalle: derivado.detalle,
            proveido: derivado.proveido,
            estado: derivado.estado,
        };
    }

    $("#BtnGuardarTramite").click(function (e) {
        e.preventDefault();
        let formCrearTramite = document.getElementById("FormCrearTramite");
        let divAlertCrearTramite = $("#DivAlertCrearTramite");
        removerCssYHtml(divAlertCrearTramite);
        axiosWrapper({
            method: "POST",
            url: formCrearTramite.getAttribute('action'),
            headers: {
                'Content-Type': `multipart/form-data;boundary="${getBoundary()};";charset=utf-8`,
            },
            data: new FormData(formCrearTramite),
            loadElem: $(this),
            form: $(formCrearTramite),
            alertElem: divAlertCrearTramite,
            thenFunc: res => {
                let msg = `Se ha realizado correctamente`;
                window.sessionStorage.setItem('msg', msg);
                window.location.reload();
            },
        });
    });
}
