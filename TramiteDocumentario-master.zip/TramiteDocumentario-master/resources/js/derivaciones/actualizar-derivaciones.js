import {getDivModal} from "../utils/utils";
import axiosWrapper, {getBoundary} from "../utils/request";
import showAlert from "../utils/messages";


$(function () {
    let divModal = getDivModal();

    divModal.on('click', '#BtnAtenderDerivacion', function (e) {
        e.preventDefault();
        let formAtenderDerivacion = document.getElementById('FormAtenderDerivacion');
        axiosWrapper({
            method: formAtenderDerivacion.getAttribute('method'),
            url: formAtenderDerivacion.getAttribute('action'),
            loadElem: $(this),
            form: $(formAtenderDerivacion),
            data: new FormData(formAtenderDerivacion),
            alertElem: divModal,
            headers: {
                'Content-Type': `multipart/form-data;boundary="${getBoundary()};";charset=utf-8`,
            },
            thenFunc: res => {
                let msg = `Se ha realizado correctamente`;
                window.sessionStorage.setItem('msg', msg);
                window.location.reload();
            }
        });
    });

    divModal.on('click', '#BtnDerivar', function (e) {
        e.preventDefault();
        let formDerivar = $('#FormDerivar');
        axiosWrapper({
            method: formDerivar.attr('method'),
            url: formDerivar.attr('action'),
            loadElem: $(this),
            form: formDerivar,
            data: formDerivar.serialize(),
            alertElem: divModal,
            thenFunc: res => {
                let msg = `Se ha realizado correctamente`;
                window.sessionStorage.setItem('msg', msg);
                window.location.reload();
            }
        });
    });

    divModal.on('click', "#BtnAdjuntar", function (e) {
        e.preventDefault();
        let formAdjuntar = document.getElementById("FormAdjuntar");
        axiosWrapper({
            method: formAdjuntar.getAttribute('method'),
            url: formAdjuntar.getAttribute('action'),
            loadElem: $(this),
            form: $(formAdjuntar),
            data: new FormData(formAdjuntar),
            alertElem: divModal,
            thenFunc: res => {
                let msg = `Se ha realizado correctamente`;
                window.sessionStorage.setItem('msg', msg);
                window.location.reload();
            }
        });
    });

    divModal.on('click', "#BtnArchivar", function (e) {
        e.preventDefault();
        let formAdjuntar = document.getElementById("FormArchivar");
        axiosWrapper({
            method: formAdjuntar.getAttribute('method'),
            url: formAdjuntar.getAttribute('action'),
            loadElem: $(this),
            form: $(formAdjuntar),
            data: new FormData(formAdjuntar),
            alertElem: divModal,
            thenFunc: res => {
                let msg = `Se ha realizado correctamente`;
                window.sessionStorage.setItem('msg', msg);
                window.location.reload();
            }
        });
    });

    divModal.on('click', "#BtnDesantender", function (e) {
        e.preventDefault();
        let formAdjuntar = document.getElementById("FormDesantenderDerivacion");
        axiosWrapper({
            method: formAdjuntar.getAttribute('method'),
            url: formAdjuntar.getAttribute('action'),
            loadElem: $(this),
            form: $(formAdjuntar),
            data: new FormData(formAdjuntar),
            alertElem: divModal,
            thenFunc: res => {
                let msg = `Se ha realizado correctamente`;
                window.sessionStorage.setItem('msg', msg);
                window.location.reload();
            }
        });
    });

    divModal.on('click', "#BtnRecepcionarDerivacion", function (e) {
        e.preventDefault();
        let formRecepcionar = $("#FormRecepcionarDerivacion");
        axiosWrapper({
            method: formRecepcionar.attr('method'),
            url: formRecepcionar.attr('action'),
            loadElem: $(this),
            form: formRecepcionar,
            data: formRecepcionar.serialize(),
            alertElem: divModal,
            thenFunc: res => {
                let msg = `Se ha realizado correctamente`;
                window.sessionStorage.setItem('msg', msg);
                window.location.reload();
            }
        });
    });

    divModal.on('click', "#BtnRegresarEstado", function (e) {
        e.preventDefault();
        let formRegresarEstado = $("#FormRegresarEstado");
        axiosWrapper({
            method: formRegresarEstado.attr('method'),
            url: formRegresarEstado.attr('action'),
            loadElem: $(this),
            form: formRegresarEstado,
            data: formRegresarEstado.serialize(),
            alertElem: divModal,
            thenFunc: res => {
                let msg = `Se ha realizado correctamente`;
                window.sessionStorage.setItem('msg', msg);
                window.location.reload();
            }
        });
    });

    divModal.on('click', "#BtnAddAdjunto", function (e) {
        e.preventDefault();
        let divAddAdjunto = $("#DivAddAjunto");
        let nombreAdjunto = divAddAdjunto.find('input#nombre_adjunto').val();
        addAdjuntoATabla(nombreAdjunto);
    });

    function addAdjuntoATabla(nombreAdjunto) {
        let tabla = $("#TablaAdjuntos");
        tabla.find('tbody').append(getFilaDeAdjunto(tabla, nombreAdjunto));
    }

    function getFilaDeAdjunto(tabla, nombreAdjunto) {
        let i = tabla.find('tbody').find('tr').length;
        let derivacionId = $("#FormAdjuntar").find('input[name=id]').val();
        return `
              <tr>
                <input type="hidden" name="adjuntos[${i}][derivacion_id]" value="${derivacionId}">
                <td>
                    ${nombreAdjunto}
                    <input type="hidden" name="adjuntos[${i}][nombre_adjunto]" value="${nombreAdjunto}">
                    <span class="error" style="color: red" data-input-name="adjuntos.${i}.nombre_adjunto"></span>
                </td>
                <td>
                    Seleccione el adjunto
                    <input type="file"  name="adjuntos[${i}][adjunto]" class="form-control-file" >
                    <span class="error" style="color: red" data-input-name="adjuntos.${i}.adjunto"></span>
                </td>
                <td>
                    <a href="#" class="quitar-adjunto">Quitar</a>
                </td>
            </tr>
        `;
    }

    divModal.on('click', 'a.quitar-adjunto', function (e) {
        e.preventDefault();
        $(this).parent().parent().remove();
    });

    divModal.on('click', 'a.eliminar-adjunto', function (e) {
        e.preventDefault();
        let divParent = $(this).parent();
        axiosWrapper({
            method: divParent.attr('data-method'),
            url: divParent.attr('data-action'),
            data: {
                '_method': 'delete'
            },
            loadElem: $(this),
            form: divParent,
            thenFunc: res => {
                divParent.parent().parent().remove();
                showAlert('Se ha eliminado correctamente')
            },
            errorFunc: err => console.log(err),
        })
    });

});
