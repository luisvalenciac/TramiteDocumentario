import showAlert, {MESSAGE_TYPES} from "./messages";

export default function axiosWrapper(config) {
    showLoad(config.loadElem || {});
    if (_.isFunction(config.beforeFunc))
        config.beforeFunc();
    clearErrors(config.form);
    axios(config)
        .then(res => config.thenFunc(res))
        .catch(err => {
            showErrorsFromResponse(err, config.form, config.alertElem);
            if (_.isFunction(config.errorFunc))
                config.errorFunc(err)
        }).then(() => {
        removeLoad(config.loadElem || {});
        if (_.isFunction(config.finallyFunc))
            config.finallyFunc();
    });
}

function clearErrors(form) {
    if (form) {
        form.find("input").removeClass("is-invalid");
        form.find("select").removeClass("is-invalid");
        form.find("textarea").removeClass("is-invalid");
        form.find("span[class=invalid-feedback]").text("");
        form.find("span[class=error]").text("");
        form.find("div[class=invalid-feedback]").html("");
        form.find("div[class=invalid-non-field-errors]").html("");
    }
}

export function showErrorsFromResponse(error, form = {}, alertElem) {
    const status = error.response ? error.response.status : STATUS.INTERNAL_SERVER_ERROR;
    if (status === STATUS.UNAUTHORIZED || status === STATUS.FORBIDDEN)
        return showAlert('No tiene permiso para realizar esta acción.', MESSAGE_TYPES.DANGER, alertElem);
    if (status === STATUS.NOT_FOUND)
        return showAlert(`No se ha encontrado el registro en cuestión.`, MESSAGE_TYPES.DANGER, alertElem);
    if (status === STATUS.BAD_REQUEST || status === STATUS.UNPROCESSABLE_ENTITY)
        return showFormErrors(form, error.response);
    return showAlert(`Algo salió mal :(.`, MESSAGE_TYPES.DANGER, alertElem);
}

function showLoad(elem) {
    elem.attr('disabled', true);
    elem.append(getLoadHtml());
}

function removeLoad(elem) {
    elem.find(`#${ID_LOAD_SPAN}`).remove();
    elem.removeAttr('disabled');
}

function getLoadHtml() {
    return `<span id="${ID_LOAD_SPAN}" class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>`;
}

const ID_LOAD_SPAN = 'span-load'

export const STATUS = {
    UNAUTHORIZED: 401,
    FORBIDDEN: 403,
    NOT_FOUND: 404,
    BAD_REQUEST: 400,
    UNPROCESSABLE_ENTITY: 422,
    INTERNAL_SERVER_ERROR: 500
};


function showFormErrors(form, response) {
    let errors = response.data.errors;
    Object.keys(errors).forEach(function (key) {
        form.find(`input[name='${key}']`).addClass("is-invalid");
        form.find(`select[name='${key}']`).addClass("is-invalid");
        form.find(`textarea[name='${key}']`).addClass("is-invalid");
        errors[key].forEach(function (err) {
            form.find(`span[data-input-name='${key}']`).append(`<p>${err}</p>`);
        });
    });
}

export function getBoundary() {
    return Math.floor(Math.random() * 32768) +
        Math.floor(Math.random() * 32768) + Math.floor(Math.random() * 32768);
}
