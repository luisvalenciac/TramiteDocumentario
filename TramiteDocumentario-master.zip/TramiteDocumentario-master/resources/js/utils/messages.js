const Swal = require('sweetalert2');

export const MESSAGE_TYPES = {
    SUCCESS: 'success',
    DANGER: 'error'
};

export default function showAlert(msg, type = MESSAGE_TYPES.SUCCESS, container = undefined) {
    Swal.fire({
        text: msg,
        icon: type
    });
}
