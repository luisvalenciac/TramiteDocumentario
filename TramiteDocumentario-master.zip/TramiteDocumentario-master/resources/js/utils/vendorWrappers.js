export function esLanguajeDataTable() {

    return {
        "sProcessing": "Procesando...",
        "sLengthMenu": "Mostrar _MENU_ registros",
        "sZeroRecords": "No se encontraron resultados",
        "sEmptyTable": "Ningún dato disponible en esta tabla",
        "sInfo": "", //Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros
        "sInfoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
        "sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
        "sInfoPostFix": "",
        "sSearch": "Buscar en tabla:",
        "sUrl": "",
        "sInfoThousands": ",",
        "sLoadingRecords": "Cargando...",
        "oPaginate": {
            "sFirst": "Primero",
            "sLast": "Último",
            "sNext": "Siguiente",
            "sPrevious": "Anterior"
        },
        "oAria": {
            "sSortAscending": ": Activar para ordenar la columna de manera ascendente",
            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
        },
        "buttons": {
            "copy": "Copiar",
            "colvis": "Visibilidad"
        }
    }
}

export function cargarTabla(tabla) {
    if (tabla.length) {
        tabla.DataTable({
            paging: false,
            language: esLanguajeDataTable(),
            "order": []
        });
    }
}

export function selectTwoConfig(config) {
    return {
        placeholder: config.placeholder,
        ajax: {
            url: function (params) {
                return _.isFunction(config.url) ? config.url() : config.url;
            },
            delay: 500,
            dataType: 'json',
            data: function (params) {
                return {
                    q: params.term,
                    page: params.page || 1
                }
            },
            processResults: function (data, params) {
                params.page = params.page || 1;
                return {
                    results: data.data,
                    pagination: {
                        more: (params.page * 10) < data.total
                    }
                };
            },
        },
        templateResult: config.templateResult,
        templateSelection: config.templateSelection,
        minimumInputLength: 'minInputLength' in config ? config.minInputLength : 3,
        maximumInputLength: 30,
        minimumResultsForSearch: 'minResultForSearch' in config ? config.minResultForSearch : 5,
        allowClear: config.allowClear === undefined ? true : config.allowClear,
        tags: config.tags === undefined ? false : config.tags,
        ...config.extraParams
    }
}
