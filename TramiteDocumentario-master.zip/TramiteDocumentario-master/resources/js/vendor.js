import "jquery/dist/jquery.js";
import "bootstrap/dist/js/bootstrap.bundle.min.js";
import "simplebar/dist/simplebar.min.js";
import "node-waves/dist/waves.min.js";
import "waypoints/lib/jquery.waypoints.min.js";
import "jquery.counterup/jquery.counterup.min.js";
import "feather-icons/dist/feather.js";
