import {configByCheckVisibility} from "../utils/utils";
import {configCamposOtroTipoSolicitud} from "../tramites/tramites-extracted-functions";

$(function () {
    let checkIncluyePago = $("#CheckIncluyePago");
    configByCheckVisibility(checkIncluyePago, $("#DivCodigoPago"));
    configByCheckVisibility(checkIncluyePago, $("#DivAdjuntoPago"));

    configCamposOtroTipoSolicitud($("#SelectTipoSolicitud"), $("#DivOtroTipoSolicitud"));
});
