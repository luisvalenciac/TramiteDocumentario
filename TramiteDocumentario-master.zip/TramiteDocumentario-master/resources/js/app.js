import '../js/main/config-inicial';
import 'select2/dist/js/select2';
import 'select2/dist/js/i18n/es';

import './utils/datatables.min.js'
import './utils/footable.min.js';
import './utils/datatables.init';
import './utils/foo-tables.init';

import './layout/app-layout';
import './usuarios';
import './roles/crear-editar-rol';
import './tramites/crear-tramite';
import './derivaciones/listar-derivaciones';
import './derivaciones/actualizar-derivaciones';
import './archivadores/listar-archivador';
import './dashboard/graficos';
import '../js/main/layout'
import '../js/main/app'