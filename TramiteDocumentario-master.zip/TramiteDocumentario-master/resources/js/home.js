import '../js/main/config-inicial';
import '../js/main/layout'
import '../js/main/home'
import './solicitudes/crear-solicitud';
import 'select2/dist/js/select2';
import 'select2/dist/js/i18n/es';

$(document).ready(function () {
    $(".custom-select2").select2();
});