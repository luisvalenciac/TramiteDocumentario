@extends('layouts.app')
@section('titulo', 'Unidades orgánicas')
@section('contenido')

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item active">Áreas</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Unidades orgánicas</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            @can('create', App\Models\Area::class)
                <div class="col-sm-4">
                    <a href="{{ route('administracion.areas.create')}}"
                       class="btn btn-primary btn-rounded waves-effect waves-light mb-3"><i class="mdi mdi-plus"></i>
                        Registrar unidad orgánica</a>
                </div>
            @endcan
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card-box">
                    <form action="{{route('administracion.areas.index')}}" id="DivFiltros">
                        <div class="form-row">
                            <div class="col-md-2 mb-3">
                                <label for="nombres">Nombres</label>
                                <input type="text" name="nombre" class="form-control"
                                value="{{request()->query('nombre', '')}}">
                            </div>
                            <div class="col-md-2 mb-3">
                                <label for="correo">Abreviatura</label>
                                <input type="text" name="abreviatura" class="form-control"
                                    value="{{request()->query('abreviatura', '')}}">
                            </div>
                            <div class="col-md-3 mb-3">
                                <label for="area">Responsable</label>
                                {? $user = $datos->getUserPorId(request()->query('responsable', 0)) ?}
                                <select data-allow-clear="true" name="responsable" id="SelectBuscarUser"
                                        data-placeholder="Busque por username, DNI, nombres, apellidos, correo y username"
                                        class="form-control"
                                        data-buscar-user-url="{{route('administracion.usuarios.api.v1.buscar')}}"
                                        style="position: static !important;">
                                    <option></option>
                                    @if($user)
                                        <option selected value="{{$user->id}}">
                                            {{$user->infoUserYArea()}}
                                        </option>
                                    @endif
                                </select>
                            </div>
                            <div class="col-md-2 mb-3">
                                <label for="cargo">Siglas</label>
                                <input type="text" name="siglas" class="form-control"
                                    value="{{request()->query('siglas', '')}}">
                            </div>
                            <div class="col-md-3 mb-3 mt-3" style="display: flex; align-items: center;">
                                <button class="btn btn-blue waves-effect waves-light"><i class="mdi mdi-filter mr-1"></i> Filtrar</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card-box">
                <h4 class="header-title">Unidad Orgánicas</h4>
                <table class="table table-hover datatable">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Abreviatura</th>
                        <th>Siglas</th>
                        <th>Representante</th>
                        <th>Opciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($datos->areas as $area)
                        <tr>
                            <td>{{ $area->id }}</td>
                            <td>{{ $area->nombre }}</td>
                            <td>{{ $area->abreviatura }}</td>
                            <td>{{ $area->siglas }}</td>
                            <td>
                                @if($area->responsable)
                                    {{ $area->responsable->nombres }} {{$area->responsable->apellidos}}
                                @else
                                    Sin responsable
                                @endif
                            </td>
                            <td>
                                @can('update', $area)

                                    <a href="{{ route('administracion.areas.edit', ['area' => $area]) }}"
                                       class="btn btn-warning waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Editar" data-original-title="Editar">
                                        <i class="mdi mdi-account-box-multiple"></i>
                                    </a>
                                @endcan

                                @can('view', $area)
                                    <a href="{{ route('administracion.areas.show', ['area' => $area]) }}"
                                       class="btn btn-info waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Mostrar" data-original-title="Mostrar">
                                        <i class="mdi mdi-account-box-multiple"></i>
                                    </a>
                                @endcan

                                @can('delete', $area)
                                    <form action="{{ route('administracion.areas.destroy', ['area' => $area]) }}"
                                          method="post" style="margin: 0; padding: 0; display:inline-block;">
                                        @csrf
                                        @method('delete')
                                        <button type="submit" class="btn btn-danger waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Eliminar" data-original-title="Eliminar">
                                            <i class="mdi mdi-account-cancel"></i>
                                        </button>
                                    </form>
                                @endcan
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
            </div>
        </div>

        {{$datos->areas->withQueryString()->links()}}

@endsection
