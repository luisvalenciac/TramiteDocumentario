@extends('layouts.app')
@section('titulo', 'Crear area')
@section('contenido')

<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Unidad Orgánica</a></li>
                    <li class="breadcrumb-item active">Registrar</li>
                </ol>
            </div>
            <h4 id="TituloCrearUser" class="page-title">Registrar Unidad Orgánica</h4>
            @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        </div>
    </div>
</div>

<form action="{{ route('administracion.areas.store') }}" method="post">
    @csrf
    <div class="row">
        <div class="col-lg-6">
            <div class="card-box">
                <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Datos</h5>

                {{-- NOMBRE --}}
                <div class="form-group mb-3">
                    <label for="nombre">Nombre <span class="text-danger">*</span></label>
                    <input type="text" id="nombre" name="nombre"
                           class="form-control @error('nombre') is-invalid @enderror"
                           value="{{ old('nombre', '') }}"
                           autocomplete="off">
                    @error('nombre')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- ABREVIATURA --}}
                <div class="form-group mb-3">
                    <label for="abreviatura">Abreviatura <span class="text-danger">*</span></label>
                    <input type="text" id="abreviatura" name="abreviatura"
                           class="form-control @error('abreviatura') is-invalid @enderror"
                           value="{{ old('abreviatura', '') }}"
                           autocomplete="off">
                    @error('abreviatura')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- SIGLAS --}}
                <div class="form-group mb-3">
                    <label for="siglas">Siglas <span class="text-danger">*</span></label>
                    <input type="text" id="siglas" name="siglas"
                           class="form-control @error('siglas') is-invalid @enderror"
                           value="{{ old('siglas', '') }}"
                           autocomplete="off">
                    @error('siglas')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card-box">
            <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Adicionales</h5>
            {{-- SIGLAS --}}
            <div class="form-group mb-3">
                <label for="tipo_area">Tipo <span class="text-danger">*</span></label>
                <select name="tipo_area" id="tipo_area" style="width: 100%"
                        class="custom-select2 @error('tipo_area') is-invalid @enderror">
                    @foreach($tiposArea as $k => $v)
                        <option value="{{$k}}"
                                @if($k == old('tipo_area' , ''))
                                selected
                            @endif
                        >{{$v}}</option>
                    @endforeach
                </select>
                @error('tipo_area')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

            {{-- USUARIO RESPONSABLE --}}
            <div class="form-group mb-3">
                <label for="SelectBuscarUser">Usuario responsable</label>
                <select name="user_responsable_id" id="SelectBuscarUser"
                        data-placeholder="Busque por username, DNI, nombres, apellidos, correo y username"
                        class="form-control @error('user_responsable_id') is-invalid @enderror"
                        data-buscar-user-url="{{route('administracion.usuarios.api.v1.buscar')}}">
                </select>
                @error('user_responsable_id')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>

            <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
        </div>
    </div>
</form>


@endsection
