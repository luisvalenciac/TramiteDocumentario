@extends('layouts.app')
@section('titulo', 'Usuarios')
@section('contenido')

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item active">Usuarios</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Lista de Usuarios</h4>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        @can('create', App\Models\Usuario::class)
            <div class="col-sm-4">
                <a href="{{ route('administracion.usuarios.create') }}"
                   class="btn btn-primary btn-rounded waves-effect waves-light mb-3"><i
                        class="mdi mdi-plus"></i>
                    Registrar Usuario</a>
            </div>
        @endcan
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <div class="row">
                    <div class="col-lg-12">
                        <form action="{{route('administracion.usuarios.index')}}" id="DivFiltros">
                            <div class="form-row">
                                <div class="form-group col-md-2">
                                    <label for="nombres" class="mr-2">Nombres</label>
                                    <input type="text" name="nombres" class="form-control"
                                           value="{{request()->query('nombres', '')}}">
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="correo" class="mr-2">Correo</label>
                                    <input type="text" name="correo" class="form-control"
                                       value="{{request()->query('correo', '')}}">
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="username" class="mr-2">Username</label>
                                    <input type="text" name="username" class="form-control"
                                           value="{{request()->query('username', '')}}">
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="area" class="mr-2">Área</label>
                                    <select data-allow-clear="true" name="area" style="width: 100%"
                                        data-placeholder="Seleccione una área" class="custom-select2">
                                    <option></option>
                                    @foreach($datos->areas as $area)
                                        <option
                                            @if($area->id == request()->query('area', 0))
                                            selected
                                            @endif
                                            value="{{$area->id}}"
                                        >
                                            {{$area->nombre}}
                                        </option>
                                    @endforeach
                                    </select>
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="cargo" class="mr-2">Cargo</label>
                                    <input type="text" name="cargo" class="form-control"
                                       value="{{request()->query('cargo', '')}}">
                                </div>
                                <div class="form-group col-md-2 mt-3">
                                    <button class="btn btn-blue waves-effect waves-light"><i
                                        class="mdi mdi-filter mr-1"></i> Filtrar
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="header-title mb-4">Usuarios</h4>

                <table class="table table-hover  datatable">
                    <thead>
                    <tr>
                        <th>Nombres y Apellidos</th>
                        <th>Correo</th>
                        <th>Nombre de usuario</th>
                        <th>Unidad orgánica</th>
                        <th>Roles</th>
                        <th>Cargo</th>
                        <th>Opciones</th>
                    </tr>
                    </thead>

                    <tbody>

                    @foreach($datos->usuarios as $usuario)
                        <tr>
                            <td>
                                <span class="ml-2">{{ $usuario->nombres }} {{ $usuario->apellidos }}</span>
                            </td>
                            <td>
                                <b>{{ $usuario->correo }}</b>
                            </td>
                            <td>
                                {{ $usuario->username }}
                            </td>
                            <td>
                                @if($usuario->area)
                                    <span class="badge badge-info p-1">
                                    {{ $usuario->area->nombre }}
                                </span>
                                @else
                                    <span class="badge bg-soft-secondary text-secondary p-1">
                                    Sin unidad
                                </span>
                                @endif
                            </td>
                            <td>
                            <span class="badge badge-success p-1">
                            @foreach($usuario->roles as $r)
                                    {{$r->display_name}}
                                @endforeach
                            </span>
                            </td>
                            <td>
                                {{$usuario->cargo}}
                            </td>
                            <td>
                                @can('update', $usuario)
                                <a href="{{ route('administracion.usuarios.edit', ['usuario' => $usuario]) }}"
                                    class="btn btn-warning waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Editar" data-original-title="Editar">
                                    <i class="mdi mdi-account-edit"></i>
                                </a>
                                @endcan
                                @can('view', $usuario)
                                <a href="{{ route('administracion.usuarios.show', ['usuario' => $usuario]) }}"
                                    class="btn btn-info waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Detalle" data-original-title="Detalle">
                                    <i class="mdi mdi-account-box-multiple"></i>
                                </a>
                                @endcan
                                @can('delete', $usuario)
                                    <form
                                        action="{{ route('administracion.usuarios.destroy', ['usuario' => $usuario]) }}"
                                        method="post" style="margin: 0; padding: 0; display:inline-block;">
                                        @csrf
                                        @method('delete')
                                        @if($usuario->esta_activo)
                                            <button type="submit" class="btn btn-danger waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Eliminar" data-original-title="Eliminar">
                                                <i class="mdi mdi-account-cancel"></i>
                                            </button>
                                        @else
                                            <button type="submit" class="btn btn-secondary waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Dar de Alta" data-original-title="Dar de Alta">
                                                <i class="mdi mdi-account-check"></i>
                                            </button>
                                        @endif
                                    </form>
                                @endcan
                            </td>
                        </tr>
                    @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    {{$datos->usuarios->withQueryString()->links()}}
@endsection