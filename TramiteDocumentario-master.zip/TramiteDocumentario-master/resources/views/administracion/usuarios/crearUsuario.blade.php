
@extends('layouts.app')
@section('titulo', 'Crear Usuario')
@section('contenido')

<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Usuario</a></li>
                    <li class="breadcrumb-item active">Registrar</li>
                </ol>
            </div>
            <h4 id="TituloCrearUser" class="page-title">Registrar Usuario</h4>
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>
    </div>
</div>

<form id="FormCrearUser" action="{{ route('administracion.usuarios.store') }}" method="post">
    @csrf
    <div class="row">

        <input type="hidden" id="url-consulta-reniec" value="{{ route('administracion.usuarios.api.v1.reniecDni') }}">
        <div class="col-lg-6">
            <div class="card-box">
                <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Datos Personales</h5>

                {{-- DNI --}}
                <div class="form-group mb-3">
                    <label for="dni">DNI <span class="text-danger">*</span></label>
                    <input type="text" id="dni" name="dni"
                        class="form-control @error('dni') is-invalid @enderror"
                        value="{{ old('dni', '') }}"
                        autocomplete="off"
                        maxlength="8">
                    <span class="invalid-feedback" data-input-name="dni"></span>
                    @error('dni')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                {{-- NOMBRES --}}
                <div class="form-group mb-3">
                    <label for="nombres">Nombres <span class="text-danger">*</span></label>
                    <input type="text" id="nombres" name="nombres"
                            class="form-control @error('nombres') is-invalid @enderror"
                            value="{{ old('nombres', '') }}"

                            autocomplete="off">
                        @error('nombres')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                </div>

                {{-- APELLIDOS --}}
                <div class="form-group mb-3">
                    <label for="apellidos">Apellidos <span class="text-danger">*</span></label>
                    <input type="text" id="apellidos" name="apellidos"
                            class="form-control @error('apellidos') is-invalid @enderror"
                            value="{{ old('apellidos', '') }}"

                            autocomplete="off">
                        @error('apellidos')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                </div>

                {{-- CORREO ELECTRÓNICO --}}
                <div class="form-group mb-3">
                    <label for="correo">Correo Electrónico</label>
                    <input type="text" id="correo" name="correo"
                                class="form-control @error('correo') is-invalid @enderror"
                                value="{{ old('correo', '') }}"
                                autocomplete="off">
                        @error('correo')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                </div>

                {{-- TELÉFONO --}}
                <div class="form-group mb-3">
                    <label for="telefono">Teléfono</label>
                    <input type="text" id="telefono" name="telefono"
                            class="form-control @error('telefono') is-invalid @enderror"
                            value="{{ old('telefono', '') }}"
                            autocomplete="off">
                        @error('telefono')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                </div>

                {{-- DIRECCIÓN --}}
                <div class="form-group mb-3">
                    <label for="direccion">Dirección</label>
                    <input type="text" id="direccion" name="direccion"
                            class="form-control @error('direccion') is-invalid @enderror"
                            value="{{ old('direccion', '') }}"
                            autocomplete="off">
                        @error('direccion')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                </div>
            </div> <!-- end card-box -->
        </div> <!-- end col -->

        <div class="col-lg-6">

            <div class="card-box">
                <h5 class="text-uppercase mt-0 mb-3 bg-light p-2">Datos de la Cuenta</h5>

                {{-- CARGO --}}
                <div class="form-group mb-3">
                    <label for="cargo">Cargo <span class="text-danger">*</span></label>
                    <input type="text" id="cargo" name="cargo"
                            class="form-control @error('cargo') is-invalid @enderror"
                            value="{{ old('cargo', '') }}"

                            autocomplete="off">
                        @error('cargo')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                </div>

                {{-- ROL DE USUARIO --}}
                <div class="form-group mb-3">
                    <label for="rol">Rol de Usuario <span class="text-danger">*</span></label>
                    <select name="rol" id="rol"
                                class="form-control @error('rol') is-invalid @enderror">
                            @foreach($datos->roles as $r)
                                <option value="{{$r->name}}"
                                        @if($r->name == old('rol', 0))
                                        selected
                                    @endif
                                >{{$r->display_name}}</option>
                            @endforeach
                        </select>
                        @error('rol')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                </div>

                {{-- UNIDAD ORGÁNICA --}}
                <div class="form-group mb-3">
                    <label for="area_id">Unidad orgánica <span class="text-danger">*</span></label>
                    <select name="area_id" id="area_id"
                                class="form-control @error('area_id') is-invalid @enderror">
                            <option value="">Seleccionar una unidad</option>
                            @foreach($datos->areas as $area)
                                <option
                                    @if(old('area_id', 0) == $area->id)
                                    selected
                                    @endif
                                    value="{{$area->id}}">{{$area->nombre}}</option>
                            @endforeach
                        </select>
                        @error('area_id')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                </div>

                {{-- NOMBRE DE USUARIO --}}
                <div class="form-group mb-3">
                    <label for="username">Nombre de usuario</label>
                    <input type="text" id="username" name="username"
                            class="form-control @error('username') is-invalid @enderror"
                            value="{{ old('username', '') }}"
                            autocomplete="off">
                        @error('username')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                </div>

                {{-- CONTRASEÑA --}}
                <div class="form-group mb-3">
                    <label for="password">Contraseña</label>
                    <input type="password" id="password" name="password"
                            class="form-control @error('password') is-invalid @enderror"
                            value=""
                            autocomplete="off">
                        @error('password')
                        <div class="invalid-feedback">
                            {{ $message }}
                        </div>
                        @enderror
                </div>

                {{-- CONTRASEÑA --}}
                <div class="form-group mb-3">
                    <label for="password_confirmation">Confirmar contraseña</label>
                    <input type="password" id="password_confirmation" name="password_confirmation"
                            class="form-control @error('password_confirmation') is-invalid @enderror"
                            autocomplete="off">
                </div>

                <button type="submit" class="btn btn-primary">Guardar</button>

            </div> <!-- end col-->
        </div> <!-- end col-->
    </div>
</form>

@endsection
