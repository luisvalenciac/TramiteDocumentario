@extends('layouts.app')
@section('titulo', 'Editar Rol')
@section('contenido')

<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">Rol</a></li>
                    <li class="breadcrumb-item active">Editar</li>
                </ol>
            </div>
            <h4 class="page-title">Editar rol: {{$datos->rol->display_name}}</h4>
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>
    </div>
</div>

<form id="FormRol" action="{{ route('administracion.roles.update', ['role'=> $datos->rol]) }}"
    method="post">
  @csrf
  @method('PATCH')

  <input type="hidden" value="{{$datos->rol->id}}" name="id">

  <div class="row">
    <div class="col-lg-6">
        <div class="card-box">
            <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Nombres</h5>
            <div class="form-group mb-3">
                <label for="display_name">Nombre declarativo</label>
                <input type="text" id="display_name" name="display_name"
                       class="form-control @error('display_name') is-invalid @enderror"
                       value="{{$datos->rol->display_name}}"
                       autocomplete="off">
                @error('display_name')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>
            <div class="form-group mb-3">
                <label for="name">Nombre clave</label>
                <input type="text" id="name" name="name"
                       class="form-control @error('name') is-invalid @enderror"
                       value="{{$datos->rol->name}}"
                       autocomplete="off">
                @error('name')
                <div class="invalid-feedback">
                    {{ $message }}
                </div>
                @enderror
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card-box">
            <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Permisos</h5>
            <div class="form-group mb-3">
                @if($datos->rol->name == getRolAdminSistema())
                No puede editar los permisos de un administrador de sistema. <br>
            @else
                <div class="form-group mb-3">
                    <label for="permisos">Permisos</label>
                    <select name="permisos[]" id="permisos" class="form-control custom-select2
                        @error('permisos') is-invalid @enderror" multiple
                            data-placeholder="Seleccione permisos" style="width: 100%">
                        @foreach($datos->permisos as $permiso)
                            <option
                                @if($datos->estaSeleccionado($permiso))
                                selected="selected"
                                @endif
                                value="{{$permiso->name}}">{{$permiso->display_name}}</option>
                        @endforeach
                    </select>
                    @error('permisos')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            @endif
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </div>
    </div>
  </div>
</form>
@endsection
