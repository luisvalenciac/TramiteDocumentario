@extends('layouts.app')
@section('titulo', 'Roles')
@section('contenido')

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item active">Roles</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Lista de Roles</h4>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        @can('create', Spatie\Permission\Models\Role::class)
            <div class="col-sm-4">
                <a href="{{route('administracion.roles.create')}}"
                   class="btn btn-primary btn-rounded waves-effect waves-light mb-3"><i
                        class="mdi mdi-plus"></i>
                    Registrar Roles</a>
            </div>
        @endcan
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <h4 class="header-title">Roles</h4>
                <table class="table table-hover m-0 table-centered dt-responsive nowrap w-100 datatable"
                       id="tickets-table">
                    <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Cantidad Permisos</th>
                        <th>Opciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    @forelse($roles as $rol)
                        <tr>
                            <td>{{$rol->display_name}}</td>
                            <td>
                                @if($rol->name == getRolAdminSistema())
                                    Todos
                                @else
                                    {{count($rol->permissions()->get())}}
                                @endif
                            </td>
                            <td>
                                @if($rol->name != getRolAdminSistema())
                                    @can('update', $rol)
                                        <a class="btn btn-warning waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Editar" data-original-title="Editar"
                                           href="{{route('administracion.roles.edit', ["role"=>$rol])}}">
                                            <i class="mdi mdi-account-box-multiple"></i>
                                        </a>
                                    @endcan
                                @endif
                                @can('view', $rol)
                                    <a class="btn btn-info waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Detalle" data-original-title="Detalle"
                                       href="{{route('administracion.roles.show', ["role" => $rol])}}">
                                        <i class="mdi mdi-account-box-multiple"></i>
                                    </a>
                                @endcan
                                @if($rol->name != getRolAdminSistema())
                                    @can('delete', $rol)
                                        <form action="{{ route('administracion.roles.destroy', ['role' => $rol]) }}"
                                              method="post"
                                              style="margin: 0; padding: 0; display:inline-block;">
                                            @csrf
                                            @method('delete')
                                            <button type="submit" class="btn btn-danger waves-effect waves-light" data-toggle="tooltip" data-placement="top" title="Eliminar" data-original-title="Eliminar">
                                                <i class="mdi mdi-account-cancel"></i>
                                            </button>
                                        </form>
                                    @endcan
                                @endif
                            </td>
                        </tr>
                    @empty
                        <p>No existen roles registrados</p>
                    @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

@endsection
