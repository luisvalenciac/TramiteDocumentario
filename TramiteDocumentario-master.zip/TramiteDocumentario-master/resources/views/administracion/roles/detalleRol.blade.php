@extends('layouts.app')
@section('titulo', 'Detalle de rol')
@section('contenido')


    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Rol</a></li>
                        <li class="breadcrumb-item active">Detalle de rol</li>
                    </ol>
                </div>
                <h4 id="TituloCrearUser" class="page-title">Detalle de rol</h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6">
            <div class="card-box">
                <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Información de rol: {{$rol->display_name}}</h5>
                <div class="form-group">
                    <label for="nombre">Nombre declarativo</label>
                    <input type="text" id="nombre" name="nombre"
                           class="form-control"
                           value="{{ $rol->display_name }}"
                           readonly>
                </div>
                <div class="form-group">
                    <label for="nombre">Nombre clave</label>
                    <input type="text" id="nombre" name="nombre"
                           class="form-control"
                           value="{{ $rol->name }}"
                           readonly>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card-box">
                <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Permisos</h5>
                <div class="form-group">
                    <label for="abreviatura">Permisos:</label>
                    @if($rol->name == getRolAdminSistema())
                        <strong>Todos</strong>
                    @else
                        <ul>
                            @forelse($rol->permissions()->get() as $p)
                                <li>{{$p->display_name}}</li>
                            @empty
                                No tiene asociado ningún permiso
                            @endforelse
                        </ul>
                    @endif
                </div>
            </div>
        </div>
    </div>

@endsection
