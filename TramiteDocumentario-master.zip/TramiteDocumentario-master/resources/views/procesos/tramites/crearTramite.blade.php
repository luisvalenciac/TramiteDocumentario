@extends('layouts.app')
@section('titulo', 'Crear Trámite')
@section('contenido')

    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Usuario</a></li>
                        <li class="breadcrumb-item active">Trámite</li>
                    </ol>
                </div>
                <h4 id="TituloCrearTramite" class="page-title">Registrar Trámite</h4>

            </div>
        </div>
    </div>

    <form action="{{route('procesos.tramites.guardar')}}" method="post" id="FormCrearTramite"
          enctype="multipart/form-data">
        @csrf

        <div class="row">
            <div class="col-lg-6">
                <div class="card-box">
                    <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Datos del Registro</h5>

                    <div class="form-group mb-3">
                        <label for="fecha_hora_actual">Fecha y hora <span class="text-danger">*</span></label>
                        <input type="text" id="fecha_hora_actual" value="{{getFechaFormateada(now(), 'l d M Y H:m')}}"
                               readonly
                               class="form-control">
                    </div>

                    <div class="form-group mb-3">
                        <label for="prioridad">Prioridad <span class="text-danger">*</span></label>
                        <select name="prioridad" id="prioridad" class="form-control">
                            @foreach($datos->prioridadDict as $k => $v)
                                <option value="{{$k}}"
                                        @if(old('prioridad', 0) == $k)
                                        selected
                                    @endif
                                >{{$v}}</option>
                            @endforeach
                        </select>
                        <span class="invalid-feedback" data-input-name="prioridad"></span>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">

                <div class="card-box">
                    <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Origen del expediente</h5>

                    <div class="form-group mb-3">
                        <label for="CheckTipoExpediente">Expediente personal <span class="text-danger">*</span></label>
                        <input type="checkbox" name="tipo_expediente" id="CheckTipoExpediente"
                               @if($datos->idPersonal() !== $datos->idResponsable())
                               checked="checked"
                            @endif>
                    </div>

                    <div id="DivExpedientePersonal" class="form-group"
                         data-siglas-area="{{$datos->siglasUnidadOrganicaPersonal()}}">
                        <input type="hidden" value="{{$datos->idPersonal()}}">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Unidad orgánica:
                                <strong>{{$datos->unidadOrganicaPersonal()}}</strong>
                            </li>
                            <li class="list-group-item">Firma:
                                <strong>{{$datos->firmaPersonal()}}</strong>
                            </li>
                            <li class="list-group-item">Cargo:
                                <strong>{{$datos->cargoPersonal()}}</strong>
                            </li>
                        </ul>
                    </div>

                    <div id="DivExpedienteGeneral"
                         data-siglas-area="{{$datos->siglasUnidadOrganicaResponsable()}}">
                        <input type="hidden" value="{{$datos->idResponsable()}}">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">Unidad orgánica:
                                <strong>{{$datos->unidadOrganicaResponsable()}}</strong>
                            </li>
                            <li class="list-group-item">Firma:
                                <strong>{{$datos->firmaResponsable()}}</strong>
                            </li>
                            <li class="list-group-item">Cargo:
                                <strong>{{$datos->cargoResponsable()}}</strong>
                            </li>
                        </ul>
                    </div>
                    <input id="InputUserOrigen" type="hidden" name="user_origen_id" value="">
                    <span class="error" data-input-name="user_origen_id" style="color:red"></span>
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card-box">
                    <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Datos del Documento</h5>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="fecha_emision">Fecha <span class="text-danger">*</span></label>
                                <input type="date" class="form-control" name="fecha_emision" id="fecha_emision"
                                       value="{{getFechaFormateada(old('fecha_emision', now()->format('Y-m-d')), 'Y-m-d')}}">
                                <span class="invalid-feedback" data-input-name="fecha_emision"></span>
                            </div>
                            <div class="form-group mb-3">
                                <label for="tipo_solicitante">Tipo de solicitante
                                    <span class="text-danger">*</span>
                                </label>
                                <select name="tipo_solicitante" id="tipo_solicitante" class="form-control">
                                    @foreach($datos->tiposSolicitante as $k => $v)
                                        <option value="{{$k}}">{{$v}}</option>
                                    @endforeach
                                </select>
                                <span class="invalid-feedback" data-input-name="tipo_solicitante"></span>
                            </div>
                            <div class="form-group mb-3">
                                <label for="dato_identificacion">Documento de identificación
                                    <span class="text-danger">*</span>
                                </label>
                                <input type="text" name="dato_identificacion"
                                       value="{{$datos->documentoIdentidadPersonal() ?? ""}}"
                                       class="form-control"
                                       id="dato_identificacion">
                                <small>Esto es acorde al tipo de solicitante</small>
                                <span class="invalid-feedback" data-input-name="dato_identificacion"></span>
                            </div>
                            <div class="form-group mb-3">
                                <label for="forma_recepcion">Forma de recepción <span
                                        class="text-danger">*</span></label>
                                <select name="forma_recepcion" id="forma_recepcion" class="form-control">
                                    @foreach($datos->formasRecepcion as $k => $v)
                                        <option value="{{$k}}"
                                                @if($k == old('forma_recepcion', ''))
                                                selected
                                            @endif
                                        >{{$v}}</option>
                                    @endforeach
                                </select>
                                <span class="invalid-feedback" data-input-name="forma_recepcion"></span>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="SelectTipoSolicitud">Tipo de Documento <span
                                        class="text-danger">*</span></label>
                                <select name="tipo_solicitud_id" id="SelectTipoSolicitud"
                                        class="form-control custom-select2">
                                    <option value="">Otro</option>
                                    @foreach($datos->tiposSolicitud as $tipo)
                                        <option value="{{$tipo->id}}"
                                                @if($tipo->id == old('tipo_solicitud_id', 0))
                                                selected
                                            @endif
                                        >{{$tipo->nombre_tipo}}</option>
                                    @endforeach
                                </select>
                                <span class="invalid-feedback" data-input-name="tipo_solicitud_id"></span>
                            </div>
                            <div id="DivOtroTipoSolicitud" class="form-group mb-3" hidden>
                                <label for="otro_tipo_solicitud">Otro tipo documento</label>
                                <input type="text" name="otro_tipo_solicitud" class="form-control"
                                       id="otro_tipo_solicitud">
                                <span class="invalid-feedback" data-input-name="otro_tipo_solicitud"></span>
                            </div>
                            <div class="form-group mb-3">
                                {? $esAdminSistema = request()->user()->esAdminSistema() ?}
                                <label for="numero_tramite">Número y siglas <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    @if($esAdminSistema)
                                        <input type="text" class="form-control" id="numero_tramite"
                                               name="numero_tramite"
                                               value="{{$datos->numeroReferenciaTramite()}}">
                                    @else
                                        <input type="text" class="form-control" id="numero_tramite"
                                               name="numero_tramite" readonly
                                               value="{{$datos->numeroReferenciaTramite()}}">
                                    @endif
                                    <div class="input-group-append">
                                        <span id="SpanSiglasArea" class="input-group-text">UNACH</span>
                                    </div>
                                    <span class="invalid-feedback" data-input-name="numero_tramite"></span>
                                </div>
                            </div>
                            @if(!$esAdminSistema)
                                <small>Este es un número de referencia, puede cambiar</small>
                            @endif
                            <div class="form-group mb-3">
                                <label for="archivo_tramite">Archivo</label>
                                <input type="file" name="archivo_tramite" class="form-control-file"
                                       id="archivo_tramite">
                                <small>Archivos con extensión aceptados pdf,PDF,png,PNG,jpeg</small>
                                <span class="invalid-feedback" data-input-name="archivo_tramite"></span>
                            </div>
                            <div class="form-group mt-3">
                                <label for="folios">Folios <span class="text-danger">*</span></label>
                                <input type="text" class="form-control"
                                       name="folios" id="folios">
                                <span class="invalid-feedback" data-input-name="folios"></span>
                            </div>
                        </div>
                    </div>

                    <div class="form-group mb-3">
                        <label for="asunto">Asunto <span class="text-danger">*</span></label>
                        <textarea name="asunto" id="asunto" cols="30" rows="10"
                                  class="form-control">{{old('asunto', '')}}</textarea>
                        <span class="invalid-feedback" data-input-name="asunto"></span>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="anexos">Anexos</label>
                                <input type="text" class="form-control" name="anexos" id="anexos">
                                <span class="invalid-feedback" data-input-name="anexos"></span>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="referencia">Referencia</label>
                                <input type="text" class="form-control @error('referencia') is-invalid @enderror"
                                       id="referencia" name="referencia">
                                <span class="invalid-feedback" data-input-name="referencia"></span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="CheckIncluyePago">¿Incluye pago? <span class="text-danger">*</span></label>
                        <input name="incluye_pago" id="CheckIncluyePago"
                               @if(old('incluye_pago', false))
                               checked="checked"
                               @endif
                               type="checkbox">
                        <span class="invalid-feedback" data-input-name="incluye_pago"></span>
                        <div id="DivCodigoPago" class="form-group" hidden>
                            <label for="codigo_pago">Código de pago</label>
                            <input id="codigo_pago" type="text" name="codigo_pago" value="{{old('codigo_pago', '')}}"
                                   class="form-control">
                            <span class="invalid-feedback" data-input-name="codigo_pago"></span>
                        </div>
                        <div id="DivAdjuntoPago" class="form-group" hidden>
                            <label for="adjunto_pago">Comprobante de pago</label>
                            <input id="adjunto_pago" type="file" name="adjunto_pago"
                                   class="form-control-file">
                            <small>Archivos con extensión aceptados pdf,PDF,png,PNG,jpeg</small>
                            <span class="invalid-feedback" data-input-name="adjunto_pago"></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div id="DivCrearDerivacion" class="card-box">
                    <input type="hidden" id="InputEstadoDerivacion"
                           value="{{derivacionTablaInfo()::ESTADO_POR_RECIBIR}}">
                    <div class="form-group">
                        <span class="error" data-input-name="derivaciones" style="color: red"></span>
                    </div>
                    <h5 class="text-uppercase bg-light p-2 mt-0 mb-3">Derivación del expediente</h5>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="EsCopiaCheck">Copia <span class="text-danger">*</span></label>
                                <input type="checkbox" id="EsCopiaCheck" name="es_copia">
                                <span class="invalid-feedback" data-input-name="es_copia"></span>
                            </div>
                            <div class="form-group mb-3">
                                <label for="SelectUserResponsable">Usuario responsable <span
                                        class="text-danger">*</span></label>
                                <select name="user_destino_id" id="SelectUserResponsable"
                                        data-placeholder="Seleccione usuario responsable"
                                        class="form-control"
                                        data-buscar-user-url="{{route('administracion.usuarios.api.v1.buscar')}}">
                                </select>
                                <span class="invalid-feedback" data-input-name="user_destino_id"></span>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="SelectAreaDestino">Destino <span class="text-danger">*</span></label>
                                <select id="SelectAreaDestino" class="form-control"
                                        name="area_destino_id"
                                        data-placeholder="Seleccione unidad orgánica de destino">
                                    @foreach($datos->areas as $area)
                                        <option value="{{$area->id}}">
                                            {{$area->nombre}}
                                        </option>
                                    @endforeach
                                </select>
                                <span class="invalid-feedback" data-input-name="area_destino_id"></span>
                            </div>
                            <div class="form-group mb-3">
                                <label for="TextProveido">Proveído <span class="text-danger">*</span></label>
                                <input id="TextProveido" name="proveido" class="form-control"/>
                                <span class="invalid-feedback" data-input-name="proveido"></span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <label for="InputDetalleTramite">Detalle <span class="text-danger">*</span></label>
                        <textarea type="text" class="form-control" id="InputDetalleTramite" name="detalle"></textarea>
                        <span class="invalid-feedback" data-input-name="detalle"></span>
                    </div>
                    <button id="BtnAddDerivado"
                            data-url-validar-derivacion="{{route('procesos.derivaciones.api.v1.validar')}}"
                            class="btn btn-outline-secondary"><i class="mdi mdi-plus mr-2"></i>Agregar
                    </button>
                    <div id="DivErrorGeneral">
                    </div>
                    <span class="invalid-feedback" data-input-name="numero_tramite"></span>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card-box">
                    <div class="form-group mb-3">
                        <table id="TablaDerivados" class="table table-hover">
                            <thead>
                            <tr>
                                <th scope="col">Forma</th>
                                <th scope="col">Unidad orgánica</th>
                                <th scope="col">Detalle</th>
                                <th scope="col">Usuario responsable</th>
                                <th scope="col">Proveído</th>
                                <th scope="col">Opciones</th>
                            </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                    <button id="BtnGuardarTramite" class="btn btn-primary"><i class="mdi mdi-check-bold mr-2"></i>Guardar
                    </button>

                    <div id="DivAlertCrearTramite">
                    </div>
                </div>
            </div>
        </div>

    </form>

@endsection
