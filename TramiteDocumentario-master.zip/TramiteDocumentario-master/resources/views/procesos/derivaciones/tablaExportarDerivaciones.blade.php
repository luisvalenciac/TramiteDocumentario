@if($datos->esPDF)

    <style>
        @page {
            margin: 25px 40px 100px 40px;
        }

        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
    </style>

    <div style="border-bottom: 2px solid black; height: 85px; margin-bottom: 5px;">
        <div style="display: inline-block; width: 15%; text-align: center; padding-top: 12px;">
            <figure style="height: 70px;">
                <img src="{{ public_path('/assets/images/reportes/escudo_republica.png') }}" style="height: 100%"/>
            </figure>
        </div>
        <div style="display: inline-block; width: 70%; text-align: center;">
            <p>UNIVERSIDAD NACIONAL AUTÓNOMA DE CHOTA <br> CREADA EL 11 DE MAYO DEL 2010 <br> "{{ env('NOMBRE_ANIO') }}"
            </p>
        </div>
        <div style="display: inline-block; width: 15% text-align: center;">
            <figure style="height: 60px;">
                <img src="{{ public_path('/assets/images/reportes/logo_unach.png') }}" style="height: 100%"/>
            </figure>
        </div>
    </div>

    <footer
        style="position: fixed; bottom: -30px; left: 0px; right: 0px; border-top: 2px solid black; font-size: 12px; margin-top: 5px;">
        <div style="display: inline-block; width: 20% text-align: right;">
        </div>
        <div style="text-align: center; width: 60%; display: inline-block; margin-top: 5px;">
            <p>Sede Central: Jr. José Osores N° 418 – Sede Administrativa: Jr. 27 de Noviembre N° 768- Chota,
                Cajamarca <br> Teléfono 076-351144</p>
        </div>
        <div style="display: inline-block; width: 20%; text-align: right;">
            <p style="font-size: 10px">Generado por: {{request()->user()->nombresCompletos()}} <br>
                {{request()->user()->infoDeArea()}} <br>
                {{getFechaFormateada(now())}}</p>
        </div>
    </footer>

@endif

<table style="width: 100%; font-size: 10px;">
    <thead>
    @if(!$datos->esPDF)
        <tr></tr>
        <tr>
            <th colspan="2" style="height: 70px;">
            </th>
            <th colspan="10" style="text-align: center; vertical-align: top; padding-top: 20px;">
                <h2>UNIVERSIDAD NACIONAL AUTÓNOMA DE CHOTA</h2>
                <h2>CREADA EL 11 DE MAYO DEL 2010</h2>
                <h2>"{{ env('NOMBRE_ANIO', '') }}"</h2>
            </th>
            <th colspan="1" style="height: 70px;">
            </th>
        </tr>
        <tr></tr>
    @endif
        <tr>
            <th style="background-color: #00acc1"><strong>N°</strong></th>
            <th style="background-color: #00acc1"><strong>Expediente</strong></th>
            <th style="background-color: #00acc1"><strong>Registro</strong></th>
            <th style="background-color: #00acc1"><strong>Forma</strong></th>
            <th style="background-color: #00acc1"><strong>Folios</strong></th>
            <th style="background-color: #00acc1"><strong>Asunto</strong></th>
            <th style="background-color: #00acc1"><strong>Referencia</strong></th>
            <th style="background-color: #00acc1"><strong>Tipo de solicitante</strong></th>
            <th style="background-color: #00acc1"><strong>Dato de identificación</strong></th>
            <th style="background-color: #00acc1"><strong>Forma de recepción</strong></th>
            <th style="background-color: #00acc1"><strong>Tipo de documento</strong></th>
            <th style="background-color: #00acc1"><strong>Estado</strong></th>
            <th style="background-color: #00acc1"><strong>Usuario de origen - Firma</strong></th>
        </tr>
    </thead>
    <tbody>
    @foreach($datos->derivaciones as $derivacion)
        <tr>
            <td>{{ $loop->index + 1 }}</td>
            <td>{{ $derivacion->tramite->numero_tramite }}</td>
            <td>
                {{ getFechaFormateada($derivacion->tramite->fecha_emision, 'd-m-Y') }}
                {{getFechaFormateada($derivacion->tramite->fecha_creado, 'H:m')}}
            </td>
            <td>
                @if($derivacion->tramite->es_copia)
                    COPIA
                @else
                    ORIGINAL
                @endif
            </td>
            <td>
                {{$derivacion->tramite->folios}}
            </td>
            <td>
                {{$derivacion->tramite->asunto}}
            </td>
            <td>
                {{$derivacion->tramite->referencia}}
            </td>
            <td>
                {{$datos->tiposSolicitante[$derivacion->tramite->tipo_solicitante]}}
            </td>
            <td>
                {{$derivacion->tramite->dato_identificacion}}
            </td>
            <td>
                {{$datos->formasRecepcion[$derivacion->tramite->forma_recepcion]}}
            </td>
            <td>
                @if($derivacion->tramite->tipoSolicitud)
                    {{$derivacion->tramite->tipoSolicitud->nombre_tipo}}
                @else
                    Otros - {{$derivacion->tramite->otro_tipo_solicitud}}
                @endif
            </td>
            <td>
                {{$datos->estadosDict[$derivacion->estado]}}
            </td>
            <td>
                {{$derivacion->tramite->userOrigen->nombresCompletos()}} <br>
                {{$derivacion->tramite->userOrigen->infoDeArea()}}
            </td>
        </tr>
    @endforeach
    </tbody>
    @if(!$datos->esPDF)
        <tfoot>
        <tr>
            <td colspan="13" style="text-align: center; height: 40px;">
                <h2>Sede Central: Jr. José Osores N° 418 – Sede Administrativa: Jr. 27 de Noviembre N° 768- Chota,
                    Cajamarca</h2>
                <h2>Teléfono 076-351144</h2>
            </td>
        </tr>
        <tr>
            <td colspan="13" style="text-align: center; height: 50px;">
                <h2>Generado por: {{request()->user()->nombresCompletos()}} <br>
                    {{request()->user()->infoDeArea()}} <br>
                    {{getFechaFormateada(now())}}</h2>
            </td>
        </tr>
        </tfoot>
    @endif
</table>
