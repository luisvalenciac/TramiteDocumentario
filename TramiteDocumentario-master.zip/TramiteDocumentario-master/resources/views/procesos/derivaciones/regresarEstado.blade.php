<form id="FormRegresarEstado" action="{{route('procesos.derivaciones.regresarEstado',
                                            ["derivacion" => $derivacion])}}" method="POST">
    @csrf
    <input type="hidden" name="id" value="{{$derivacion->id}}">

    <div class="modal-header">
        <h5 class="modal-title">Regresar a estado</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar"><span
                aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
        <div class="form-group">
            {? $estadosDict = derivacionTablaInfo()::estadoDerivacionDict() ?}
            <label for="estado">Seleccione estado a transicionar</label>
            <select name="estado" id="estado" class="form-control">
                <option value="{{derivacionTablaInfo()::ESTADO_POR_RECIBIR}}">
                    {{$estadosDict[derivacionTablaInfo()::ESTADO_POR_RECIBIR]}}
                </option>
                <option value="{{derivacionTablaInfo()::ESTADO_ATENDIDO}}">
                    {{$estadosDict[derivacionTablaInfo()::ESTADO_ATENDIDO]}}
                </option>
            </select>
            <span class="invalid-feedback" data-input-name="estado"></span>
        </div>
        <div class="form-group">
            <label for="detalle">Detalle</label><br>
            <textarea class="form-control"
                      name="detalle" id="detalle" cols="30" rows="10">{{$derivacion->detalle}}</textarea>
            <span class="invalid-feedback" data-input-name="detalle"></span>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button id="BtnRegresarEstado" class="btn btn-primary">Regresar de estado</button>
    </div>
</form>
