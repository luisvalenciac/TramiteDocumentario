<form id="FormArchivar" action="{{route('procesos.derivaciones.archivar',
                                            ["derivacion" => $derivacion])}}" method="POST">
    @csrf
    <input type="hidden" name="id" value="{{$derivacion->id}}">
    <input type="hidden" name="estado" value="{{derivacionTablaInfo()::ESTADO_ARCHIVADO}}">
    <div class="modal-header">
        <h5 class="modal-title">Archivar</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar"><span
                aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
        <div class="form-group">
            <label for="SelectArchivador">Archivador</label>
            <select id="SelectArchivador" class="form-control" name="archivador_id"
                    data-placeholder="Seleccione archivador"
                    data-buscar-archivador-url="{{route('administracion.archivadores.api.v1.buscar')}}">
                @foreach($archivadores as $archivador)
                    <option value="{{$archivador->id}}">
                        {{$archivador->nombre}}
                    </option>
                @endforeach
            </select>
            <span class="invalid-feedback" data-input-name="archivador_id"></span>
        </div>

        <div class="form-group">
            <label for="detalle">Detalle</label><br>
            <textarea class="form-control"
                      name="detalle" id="detalle" cols="30" rows="10">{{$derivacion->detalle}}</textarea>
            <span class="invalid-feedback" data-input-name="detalle"></span>
        </div>


    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button id="BtnArchivar" class="btn btn-primary">Archivar</button>
    </div>
</form>
