@extends('layouts.app')
@section('titulo', 'Por recibir - Derivaciones')
@section('contenido')

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item active"></li>
                        </ol>
                    </div>
                    <h4 class="page-title">Reporte de trámites</h4>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card-box">
                <form action="{{route('procesos.derivaciones.exportar')}}" id="DivFiltros">

                    <div class="form-row">
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Fecha de emisión desde:</label>
                            <input type="date" class="form-control" name="min_fecha"
                                   value="{{request()->query('min_fecha', '')}}">
                        </div>
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Hasta</label>
                            <input type="date" class="form-control" name="max_fecha"
                                   value="{{request()->query('max_fecha', '')}}">
                        </div>
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Tipo de documento</label>
                            <select data-allow-clear="true" name="tipo_solicitud"
                                    data-placeholder="Seleccione el tipo de documento"
                                    class="form-control custom-select2">
                                <option></option>
                                @foreach($datos->tiposSolicitud as $tipoSolicitud)
                                    <option
                                        @if(request()->query('tipo_solicitud', 0) == $tipoSolicitud->id)
                                        selected="selected"
                                        @endif
                                        value="{{$tipoSolicitud->id}}">
                                        {{$tipoSolicitud->nombre_tipo}}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3 mb-1">
                            <label for="nombres">DNI</label>
                            <input type="text" name="dato_identificacion" class="form-control"
                                   value="{{request()->query('dato_identificacion', '')}}">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Número de trámite</label>
                            <input type="text" name="numero_tramite" class="form-control"
                                   value="{{request()->query('numero_tramite', '')}}">
                        </div>
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Forma de recepción</label>
                            <select data-allow-clear="true" name="forma_recepcion"
                                    data-placeholder="Seleccione la forma de recepción"
                                    class="form-control custom-select2">
                                <option></option>
                                @foreach($datos->formasRecepcion as $k => $v)
                                    <option
                                        @if(request()->query('forma_recepcion', '') == $k)
                                        selected="selected"
                                        @endif
                                        value="{{$k}}">
                                        {{$v}}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Usuario de origen de expediente - Firma</label>
                            {? $user = $datos->getUserPorId(request()->query('user_expediente', 0)) ?}
                            <select data-allow-clear="true" name="user_expediente" id="SelectBuscarUser"
                                    data-placeholder="Busque por username, DNI, nombres, apellidos, correo y username"
                                    class="form-control"
                                    data-buscar-user-url="{{route('administracion.usuarios.api.v1.buscar')}}">
                                <option></option>
                                @if($user)
                                    <option selected value="{{$user->id}}">
                                        {{$user->infoUserYArea()}}
                                    </option>
                                @endif
                            </select>
                        </div>
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Prioridad</label>
                            <select data-allow-clear="true" name="prioridad"
                                    data-placeholder="Seleccione una prioridad"
                                    class="form-control custom-select2">
                                <option></option>
                                @foreach($datos->prioridadDict as $k => $v)
                                    <option
                                        @if(request()->query('prioridad', '') == $k)
                                        selected="selected"
                                        @endif
                                        value="{{$k}}">
                                        {{$v}}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Estado</label>
                            <select data-allow-clear="true" name="estado"
                                    data-placeholder="Estado del trámite"
                                    class="form-control custom-select2">
                                <option></option>
                                @foreach($datos->estadosDerivacionDict as $k => $v)
                                    <option
                                        @if(request()->query('estado', '') == $k)
                                        selected="selected"
                                        @endif
                                        value="{{$k}}">
                                        {{$v}}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Cantidad a exportar (si son todos colocar *)</label>
                            <input type="text" name="cantidad"
                                   class="form-control @error('cantidad') is-invalid @enderror"
                                   value="{{request()->query('cantidad', '')}}">
                            @error('cantidad')
                            <span class="invalid-feedback">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-md-3 mb-1">
                            <label for="extension">Tipo de extensión de archivo</label>
                            <select name="extension" id="extension"
                                    class="form-control @error('extension') is-invalid @enderror">
                                @foreach($datos->extensionesArchivo as $k => $v)
                                    <option value="{{$k}}">{{$v}}</option>
                                @endforeach
                            </select>
                            @error('extension')
                            <span class="invalid-feedback">{{ $message }}</span>
                            @enderror
                        </div>
                        <div class="col-md-3 mb-1 mt-3" style="display: flex; align-items: center;">
                            <button class="btn btn-blue waves-effect waves-light"><i class="mdi mdi-filter mr-1"></i>
                                Exportar
                            </button>
                        </div>
                    </div>

                </form>
            </div>
        </div>
    </div>

    <div class="alert alert-info mt-3">
        Si selecciona todos <strong>*</strong> la operación de exportar puede demorar en base a la cantidad de trámites
        que tiene.<br>
    </div>

@endsection
