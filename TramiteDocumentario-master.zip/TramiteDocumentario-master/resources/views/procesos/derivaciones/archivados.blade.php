@extends('layouts.app')
@section('titulo', 'Archivados - Derivaciones')
@section('contenido')

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Trámites</a></li>
                            <li class="breadcrumb-item active">Trámites Archivados</li>
                        </ol>
                    </div>
                    <h4 id="TituloCrearTramite" class="page-title">Trámites Archivados</h4>
                </div>
            </div>
        </div>
    </div>

    @include('partials.app.filtrosDerivaciones', ["estado" => derivacionTablaInfo()::ESTADO_ARCHIVADO,
                                        "incluirArchivador" => true])

    <div class="row">
        <div class="col-sm-12">
            <div class="card-box">
                <div class="table-responsive">
                    <table class="table table-hover datatable">
                        <thead>
                        <tr>
                            <th>Número de trámite</th>
                            <th>Prioridad</th>
                            <th>¿Es copia?</th>
                            <th>Usuario de origen</th>
                            <th>Fecha de emisión</th>
                            <th>Tipo de documento</th>
                            <th>Opciones</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($datos->derivaciones as $derivacion)
                            <tr>
                                <td>
                                    {{$derivacion->tramite->numero_tramite}} -
                                    @if($derivacion->tramite->archivo_tramite)
                                        <a href="{{$derivacion->tramite->archivo_tramite}}">Archivo</a>
                                    @else
                                        Sin archivo
                                    @endif
                                </td>
                                <td>{{$datos->prioridadDict[$derivacion->tramite->prioridad]}}</td>
                                <td>
                                    @if($derivacion->es_copia)
                                        Sí
                                    @else
                                        No
                                    @endif
                                </td>
                                <td>{{$derivacion->tramite->userOrigen->infoUserYArea()}}</td>
                                <td>{{getFechaFormateada($derivacion->tramite->fecha_emision, 'd/m/Y')}}</td>
                                <td>
                                    @if($derivacion->tramite->tipoSolicitud)
                                        {{$derivacion->tramite->tipoSolicitud->nombre_tipo}}
                                    @else
                                        Otro: {{$derivacion->tramite->otro_tipo_solicitud}}
                                    @endif
                                </td>
                                <td>
                                    @can('verDetalleTramite', $derivacion->tramite)
                                        <a href="{{ route('procesos.tramites.detalle', ['tramite' => $derivacion->tramite]) }}"
                                           class="btn btn-success">
                                            Seguimiento
                                        </a>
                                    @endcan
                                    <a data-toggle="modal" data-target="#ModalTemplate"
                                       href="{{route('procesos.derivaciones.vistaRegresarEstado', ["derivacion" => $derivacion])}}"
                                       class="btn btn-blue regresar-estado-derivacion">
                                        Regresar de estado
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{$datos->derivaciones->withQueryString()->links()}}

@endsection
