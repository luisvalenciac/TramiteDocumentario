<form id="FormAtenderDerivacion" action="{{route('procesos.derivaciones.atender',
                                            ["derivacion" => $derivacion])}}" method="POST">
    @csrf
    <input type="hidden" name="id" value="{{$derivacion->id}}">
    <input type="hidden" name="estado" value="{{derivacionTablaInfo()::ESTADO_ATENDIDO}}">
    <div class="modal-header">
        <h5 class="modal-title">Atender derivación</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Cerrar"><span
                aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
        <div class="form-group">
            <label for="UserOrigen">Firma - Usuario de origen</label>
            <input type="text" id="UserOrigen" readonly class="form-control"
                   value="{{$derivacion->tramite->userOrigen->infoUserYArea()}}">
        </div>
        <div class="form-group">
            <label for="detalle">Detalle</label><br>
            <textarea class="form-control"
                      name="detalle" id="detalle" cols="30" rows="10">{{$derivacion->detalle}}</textarea>
            <span class="invalid-feedback" data-input-name="detalle"></span>
        </div>

        <div class="form-group">
            <p>
                <a class="btn btn-primary waves-effect waves-light" data-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                    Ver historial de adjuntos
                </a>
            </p>
            <div class="collapse" id="collapseExample">
                <div class="card-box bg-light">
                    <table class="table table-hover">
                        <thead>
                        <tr>
                            <th>Nombre de archivo</th>
                            <th>Fecha de agregado</th>
                            <th>Opciones</th>
                        </tr>
                        </thead>
                        <tbody>
                        @forelse($derivacion->adjuntos as $adjunto)
                            <tr>
                                <td>
                                    <a href="{{$adjunto->adjunto}}">{{$adjunto->nombre_adjunto}}</a>
                                </td>
                                <td>
                                    {{getFechaFormateada($adjunto->fecha_creado, 'l d M Y H:i')}}
                                </td>
                                <td>
                                    <div data-method="POST"
                                         data-action="{{ route('procesos.adjuntos.api.v1.eliminar',['adjunto' => $adjunto]) }}">
                                        <a href="#" class="btn btn-danger eliminar-adjunto">
                                            Eliminar
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                Sin historial de adjuntos.
                            </tr>
                        @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label for="proveido">Proveido<span style="color: red">*</span></label><br>
            <input class="form-control" name="proveido" id="proveido" value="{{$derivacion->proveido}}"/>
            <span class="invalid-feedback" data-input-name="proveido"></span>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        <button id="BtnAtenderDerivacion" class="btn btn-primary">Atender</button>
    </div>
</form>

