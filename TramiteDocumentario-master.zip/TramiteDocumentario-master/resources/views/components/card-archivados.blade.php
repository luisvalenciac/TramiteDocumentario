<div class="card">
    <div class="card-body">
        Archivados: {{ $datos }}
    </div>
</div>
