<div class="card">
    <div class="card-body">
        Por recibir: {{ $datos }}
    </div>
</div>
