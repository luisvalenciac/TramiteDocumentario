<div class="card">
    <div class="card-body">
        Atendidos: {{ $datos }}
    </div>
</div>
