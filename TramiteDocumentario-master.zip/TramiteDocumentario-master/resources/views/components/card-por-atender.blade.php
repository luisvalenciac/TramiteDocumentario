<div class="card">
    <div class="card-body">
        Por atender: {{ $datos }}
    </div>
</div>
