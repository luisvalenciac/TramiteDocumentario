<canvas id="GraficoCircular"></canvas>
<input type="hidden" id="GraficoCircularDatos" value="{{ $datos }}">
