<div class="card">
    <div class="card-body">
        Usuarios : {{ $datos }}
    </div>
</div>
