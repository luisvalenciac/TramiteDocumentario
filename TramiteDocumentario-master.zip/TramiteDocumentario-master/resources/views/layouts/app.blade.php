<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('titulo', 'Dashboard')</title>
    <meta content="" name="description"/>
    <meta content="" name="author"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <link rel="shortcut icon" href="{{asset('assets/images/favicon.ico')}}">
    
    <link rel="stylesheet" type="text/css" id="app-default-stylesheet" href="{{ mix('css/app.css') }}">

    
    @yield('css')
</head>
<body @yield('body-extra')>
@include('partials.app.hiddenModal')

<div id="wrapper">
    @include('partials.app.header')
    @include('partials.app.sidebar')
    <div class="content-page">
        <div id="DivAlert">

        </div>
        <div class="content">
            @yield('contenido')
        </div>
        @include('partials.app.footer')
    </div>
</div>

<script src="{{asset('assets/js/vendor.min.js')}}"></script>
<script src="{{ mix('js/app.js') }}"></script>

</body>
</html>
