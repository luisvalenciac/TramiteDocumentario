<div class="left-side-menu">
    <div class="h-100" data-simplebar>
        <div id="sidebar-menu">
            <ul id="side-menu">
                <li class="menu-title">Principal</li>
                @can('verDashboard', App\Models\Usuario::class)
                    <li>
                        <a href="{{route('administracion.dashboard')}}" class="{{setActive('dashboard')}}">
                            <i data-feather="home"></i>
                            <span> Dashboard Principal </span>
                        </a>
                    </li>
                @endcan
                <li class="menu-title mt-2">Módulos</li>
                <li class="{{setActive('administracion.usuarios.*')}}">
                    @can('viewAny', App\Models\Usuario::class)
                        <a href="{{route('administracion.usuarios.index')}}"
                           class="{{setActive('administracion.usuarios.*')}}">
                            <i data-feather="users"></i>
                            <span> Usuarios </span>
                        </a>
                    @endcan
                </li>
                <li class="{{setActive('administracion.roles.*')}}">
                    @can('viewAny', Spatie\Permission\Models\Role::class)
                        <a href="{{route('administracion.roles.index')}}"
                           class="{{setActive('administracion.roles.*')}}">
                            <i data-feather="shield"></i>
                            <span> Roles y permisos </span>
                        </a>
                    @endcan
                </li>
                <li class="{{setActive('administracion.areas.*')}}">
                    @can('viewAny', App\Models\Area::class)
                        <a href="{{route('administracion.areas.index')}}"
                           class="{{setActive('administracion.areas.*')}}">
                            <i data-feather="file"></i>
                            <span>Unidades orgánicas</span>
                        </a>
                    @endcan
                </li>
                <li class="{{setActive('administracion.tiposSolicitud.*')}}">
                    @can('viewAny', App\Models\TipoSolicitud::class)
                        <a href="{{route('administracion.tiposSolicitud.index')}}"
                           class="{{setActive('administracion.tiposSolicitud.*')}}">
                            <i data-feather="file-plus"></i>
                            <span>Tipos de solicitud</span>
                        </a>
                    @endcan
                </li>
                <li class="{{setActive('administracion.archivadores.*')}}">
                    @can('viewAny', App\Models\Archivador::class)
                        <a href="{{route('administracion.archivadores.index')}}"
                           class="{{setActive('administracion.archivadores.*')}}">
                            <i data-feather="layers"></i>
                            <span>Archivadores</span>
                        </a>
                    @endcan
                </li>
                <li class="menu-title mt-2">Tramites</li>
                <li class="{{setActive('procesos.tramites.crear')}}">
                    @can('crearTramite', App\Models\Tramite::class)
                        <a href="{{route('procesos.tramites.crear')}}"
                           class="{{setActive('procesos.tramites.crear')}}">
                            <i data-feather="clipboard"></i>
                            <span>Crear Trámite</span>
                        </a>
                    @endcan
                </li>
                @can('verEstadosDeTramite', App\Models\Derivacion::class)
                    <li class="{{setActiveWithQuery(route('procesos.derivaciones.derivaciones',
                                    ["estado" => derivacionTablaInfo()::ESTADO_POR_ATENDER]))}}">
                        <a href="{{route('procesos.derivaciones.derivaciones',
                                        ["estado" => derivacionTablaInfo()::ESTADO_POR_ATENDER])}}"
                           class="">
                            <i data-feather="clock"></i>
                            <span>Por Atender</span>
                        </a>
                    </li>
                    <li class="{{setActiveWithQuery(route('procesos.derivaciones.derivaciones',
                                    ["estado" => derivacionTablaInfo()::ESTADO_POR_RECIBIR]))}}">
                        <a href="{{route('procesos.derivaciones.derivaciones',
                                    ["estado" => derivacionTablaInfo()::ESTADO_POR_RECIBIR])}}"
                           class="">
                            <i data-feather="download"></i>
                            <span>Por Recibir</span>
                        </a>
                    </li>
                    <li class="{{setActiveWithQuery(route('procesos.derivaciones.derivaciones',
                                    ["estado" => derivacionTablaInfo()::ESTADO_ATENDIDO]))}}">
                        <a href="{{route('procesos.derivaciones.derivaciones',
                                    ["estado" => derivacionTablaInfo()::ESTADO_ATENDIDO])}}" class="">
                            <i data-feather="check-circle"></i>
                            <span>Atendidos</span>
                        </a>
                    </li>
                    <li class="{{setActiveWithQuery(route('procesos.derivaciones.derivaciones',
                                    ["estado" => derivacionTablaInfo()::ESTADO_ARCHIVADO]))}}">
                        <a href="{{route('procesos.derivaciones.derivaciones',
                                    ["estado" => derivacionTablaInfo()::ESTADO_ARCHIVADO])}}">
                            <i data-feather="archive"></i>
                            <span>Archivados</span>
                        </a>
                    </li>
                @endcan
                <li class="menu-title mt-2">Reportes</li>
                @can('exportarDerivaciones', App\Models\Derivacion::class)
                    <li class="{{setActive(route('procesos.derivaciones.vistaExportar'))}}">
                        <a href="{{route('procesos.derivaciones.vistaExportar')}}">
                            <i data-feather="download-cloud"></i>
                            <span>Exportar</span>
                        </a>
                    </li>
                @endcan
                @can('verConfiguraciones', App\Models\ConfigTramite::class)
                    <li class="menu-title mt-2">Configuración</li>
                    <li class="{{setActive(route('configuracion.tramites.configTramite'))}}">
                        <a href="{{route('configuracion.tramites.configTramite')}}">
                            <i class="fe-settings noti-icon"></i>
                            <span>Trámites</span>
                        </a>
                    </li>
                @endcan
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
