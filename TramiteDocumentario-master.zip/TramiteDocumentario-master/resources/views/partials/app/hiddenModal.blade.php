<div id="ModalTemplate" class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby=""
     aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div id="ContenidoModal" class="modal-content">

        </div>
    </div>
</div>
