<div class="row">
    <div class="col-12">
        <div class="card-box">
            <form action="{{route('procesos.derivaciones.derivaciones')}}" id="DivFiltros">
                <input type="hidden" name="estado" value="{{$estado}}">
                <div class="form-row">
                    <div class="col-md-3 mb-1">
                        <label for="nombres">Fecha de emisión desde:</label>
                        <input type="date" class="form-control" name="min_fecha"
                               value="{{request()->query('min_fecha', '')}}">
                    </div>
                    <div class="col-md-3 mb-1">
                        <label for="nombres">Hasta</label>
                        <input type="date" class="form-control" name="max_fecha"
                               value="{{request()->query('max_fecha', '')}}">
                    </div>
                    <div class="col-md-3 mb-1">
                        <label for="nombres">Tipo de documento</label>
                        <select data-allow-clear="true" name="tipo_solicitud"
                                data-placeholder="Seleccione el tipo de documento"
                                class="form-control custom-select2">
                            <option></option>
                            <option
                                @if(request()->query('tipo_solicitud') == -1)
                                selected="selected"
                                @endif
                                value="-1">
                                Otros
                            </option>

                            @foreach($datos->tiposSolicitud as $tipoSolicitud)
                                <option
                                    @if(request()->query('tipo_solicitud', 0) == $tipoSolicitud->id)
                                    selected="selected"
                                    @endif
                                    value="{{$tipoSolicitud->id}}">
                                    {{$tipoSolicitud->nombre_tipo}}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3 mb-1">
                        <label for="dato_identificacion">Dato de identificación</label>
                        <input type="text" name="dato_identificacion" class="form-control"
                               value="{{request()->query('dato_identificacion', '')}}">
                    </div>
                </div>

                <div class="form-row">
                    <div class="col-md-3 mb-1">
                        <label for="numero_tramite">Número de trámite</label>
                        <input type="text" name="numero_tramite" class="form-control"
                               value="{{request()->query('numero_tramite', '')}}">
                    </div>
                    <div class="col-md-3 mb-1">
                        <label for="forma_recepcion">Forma de recepción</label>
                        <select data-allow-clear="true" name="forma_recepcion"
                                data-placeholder="Seleccione la forma de recepción"
                                class="form-control custom-select2">
                            <option></option>
                            @foreach($datos->formasRecepcion as $k => $v)
                                <option
                                    @if(request()->query('forma_recepcion', '') == $k)
                                    selected="selected"
                                    @endif
                                    value="{{$k}}">
                                    {{$v}}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    @if(request()->user()->esAdminSistema() || request()->user()->esResponsableArea())
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Usuario de origen de expediente - Firma</label>
                            {? $user = $datos->getUserPorId(request()->query('user_expediente', 0)) ?}
                            <select data-allow-clear="true" name="user_expediente" id="SelectBuscarUser"
                                    data-placeholder="Busque por username, DNI, nombres, apellidos, correo y username"
                                    class="form-control"
                                    data-buscar-user-url="{{route('administracion.usuarios.api.v1.buscar')}}">
                                <option></option>
                                @if($user)
                                    <option selected value="{{$user->id}}">
                                        {{$user->infoUserYArea()}}
                                    </option>
                                @endif
                            </select>
                        </div>
                    @endif
                    <div class="col-md-3 mb-1">
                        <label for="nombres">Prioridad</label>
                        <select data-allow-clear="true" name="prioridad"
                                data-placeholder="Seleccione una prioridad"
                                class="form-control custom-select2">
                            <option></option>
                            @foreach($datos->prioridadDict as $k => $v)
                                <option
                                    @if(request()->query('prioridad', '') == $k)
                                    selected="selected"
                                    @endif
                                    value="{{$k}}">
                                    {{$v}}
                                </option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    @if($incluirArchivador)
                        <div class="col-md-3 mb-1">
                            <label for="nombres">Archivador</label>
                            {? $archivador = $datos->getArchivador(request()->query('archivador', 0)) ?}
                            <select data-allow-clear="true" name="archivador" id="SelectArchivador"
                                    data-placeholder="Busque archivador por nombre"
                                    class="form-control"
                                    data-buscar-archivador-url="{{route('administracion.archivadores.api.v1.buscar')}}">
                                <option></option>
                                @if($archivador)
                                    <option selected value="{{$archivador->id}}">
                                        {{$archivador->nombre}} - {{$archivador->periodo}}
                                    </option>
                                @endif
                            </select>
                        </div>
                    @endif
                    <div class="col-md-3 mb-1">
                        <label for="tipo_solicitante">Tipo de solicitante</label>
                        <select data-allow-clear="true" name="tipo_solicitante"
                                data-placeholder="Seleccione el tipo de solicitante"
                                class="form-control custom-select2">
                            <option></option>
                            @foreach($datos->tiposSolicitante as $k => $v)
                                <option
                                    @if(request()->query('tipo_solicitante', '') == $k)
                                    selected="selected"
                                    @endif
                                    value="{{$k}}">
                                    {{$v}}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-3 mb-1 mt-3" style="display: flex; align-items: center;">
                        <button class="btn btn-blue waves-effect waves-light"><i class="mdi mdi-filter mr-1"></i>
                            Filtrar
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

