<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\TablaInfo\AreaTablaInfo as AreaAttr;

class CreateAreasTable extends Migration
{
    private const TABLA_AREAS = AreaAttr::NOMBRE_TABLA;

    public function up()
    {
        Schema::create(self::TABLA_AREAS, function (Blueprint $table) {
            $table->id();
            $table->string(AreaAttr::NOMBRE);
            $table->string(AreaAttr::ABREVIATURA);
            $table->string(AreaAttr::SIGLAS);
            $table->enum(AreaAttr::TIPO_AREA, array_keys(AreaAttr::tiposAreaDict()))
                ->default(array_keys(AreaAttr::tiposAreaDict())[0]);
            $table->unsignedBigInteger(AreaAttr::USER_RESPONSABLE_ID)->nullable();
            $table->timestamp(AreaAttr::FECHA_CREADO)->nullable();
            $table->timestamp(AreaAttr::FECHA_ACTUALIZADO)->nullable();
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLA_AREAS);
    }
}
