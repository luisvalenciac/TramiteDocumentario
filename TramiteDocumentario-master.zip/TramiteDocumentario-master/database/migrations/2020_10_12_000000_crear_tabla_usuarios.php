<?php

use App\TablaInfo\UsuarioTablaInfo as UserAttr;
use App\TablaInfo\AreaTablaInfo;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CrearTablaUsuarios extends Migration
{
    private const TABLA_USUARIOS = UserAttr::NOMBRE_TABLA;

    public function up()
    {
        Schema::create(self::TABLA_USUARIOS, function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger(UserAttr::AREA_ID)->nullable();
            $table->string(UserAttr::USERNAME)->unique()->nullable();
            $table->string(UserAttr::NOMBRES)->nullable();
            $table->string(UserAttr::APELLIDOS)->nullable();
            $table->char(UserAttr::DNI, 8);
            $table->string(UserAttr::CARGO)->nullable();
            $table->string(UserAttr::DIRECCION)->nullable();
            $table->string(UserAttr::CORREO)->nullable();
            $table->string(UserAttr::TELEFONO)->nullable();
            $table->string(UserAttr::PASSWORD)->nullable();
            $table->timestamp(UserAttr::FECHA_CORREO_VERIFICADO)->nullable();
            $table->boolean(UserAttr::ESTA_ACTIVO)->default(true);
            $table->string(UserAttr::TOKEN_RECORDAR_PASS, 100)->nullable();
            $table->timestamp(UserAttr::FECHA_CREADO)->nullable();
            $table->timestamp(UserAttr::FECHA_ACTUALIZADO)->nullable();

            $table->foreign(UserAttr::AREA_ID)
                ->references(AreaTablaInfo::ID)
                ->on(AreaTablaInfo::NOMBRE_TABLA)
                ->onDelete('SET NULL')
                ->onUpdate('SET NULL');
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLA_USUARIOS);
    }
}
