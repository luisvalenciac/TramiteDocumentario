<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use App\TablaInfo\HistorialCambioEstadoTablaInfo;
use App\TablaInfo\DerivacionTablaInfo;

class CrearTablaHistorialCambiosEstado extends Migration
{
    private const TABLA_HISTORIAL = HistorialCambioEstadoTablaInfo::NOMBRE_TABLA;

    public function up()
    {
        Schema::create(self::TABLA_HISTORIAL, function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger(HistorialCambioEstadoTablaInfo::DERIVACION_ID);
            $table->string(HistorialCambioEstadoTablaInfo::CAMBIADO_DE);
            $table->string(HistorialCambioEstadoTablaInfo::CAMBIADO_HACIA);
            $table->timestamp(HistorialCambioEstadoTablaInfo::FECHA_DE_CAMBIO);

            $table->foreign(HistorialCambioEstadoTablaInfo::DERIVACION_ID)
                ->references(DerivacionTablaInfo::ID)
                ->on(DerivacionTablaInfo::NOMBRE_TABLA)
                ->onDelete('CASCADE')
                ->onUpdate('CASCADE');
        });
    }

    public function down()
    {
        Schema::dropIfExists(self::TABLA_HISTORIAL);
    }
}
