<?php

use App\TablaInfo\TipoSolicitudTablaInfo;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TipoSolicitudSeeder extends Seeder
{
    public function run()
    {
        $tiposDefecto = TipoSolicitudTablaInfo::TIPOS_DEFECTO;
        foreach ($tiposDefecto as $tipo)
            DB::table(TipoSolicitudTablaInfo::NOMBRE_TABLA)
                ->insert([TipoSolicitudTablaInfo::NOMBRE_TIPO => $tipo]);
    }
}
