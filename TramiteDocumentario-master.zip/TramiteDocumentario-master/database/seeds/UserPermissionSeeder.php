<?php

use App\Config\Permisos\VerbosPermisos;
use App\TablaInfo\UsuarioTablaInfo;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class UserPermissionSeeder extends Seeder
{
    public function run()
    {
        $verbos = VerbosPermisos::getVerbos();
        $tablaUsuarios = UsuarioTablaInfo::NOMBRE_TABLA;
        foreach ($verbos as $k => $v)
            Permission::create([
                'name' => "{$tablaUsuarios}.{$k}",
                'display_name' => "{$v} {$tablaUsuarios}"
            ]);

        Permission::create([
            'name' => $tablaUsuarios. '.' .UsuarioTablaInfo::PERM_VER_DASHBOARD,
            'display_name' => 'Ver dashboard',
        ]);
    }
}
