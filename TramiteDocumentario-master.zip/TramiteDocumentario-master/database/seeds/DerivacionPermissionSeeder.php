<?php

use App\TablaInfo\DerivacionTablaInfo;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class DerivacionPermissionSeeder extends Seeder
{
    public function run()
    {
        $tablaDerivacion = DerivacionTablaInfo::NOMBRE_TABLA;
        $permisos = DerivacionTablaInfo::permisos();

        foreach ($permisos as $k => $v)
            Permission::create([
                'name' => "{$tablaDerivacion}.{$k}",
                'display_name' => $v
            ]);
    }
}
