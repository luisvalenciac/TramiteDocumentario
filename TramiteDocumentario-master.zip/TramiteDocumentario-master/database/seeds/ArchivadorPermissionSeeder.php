<?php

use App\Config\Permisos\VerbosPermisos;
use App\TablaInfo\ArchivadorTablaInfo;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class ArchivadorPermissionSeeder extends Seeder
{

    public function run()
    {
        $verbos = VerbosPermisos::getVerbos();
        $tablaArchivadores = ArchivadorTablaInfo::NOMBRE_TABLA;
        foreach ($verbos as $k => $v)
            Permission::create([
                'name' => "{$tablaArchivadores}.{$k}",
                'display_name' => "{$v} {$tablaArchivadores}"
            ]);
    }
}
