<?php

use App\TablaInfo\TramiteTablaInfo;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class TramitePermissionSeeder extends Seeder
{

    public function run()
    {
        $permisos = TramiteTablaInfo::getPermisos();
        $tablaTramite = TramiteTablaInfo::NOMBRE_TABLA;
        foreach ($permisos as $k => $v)
            Permission::create([
                'name' => "{$tablaTramite}.{$k}",
                'display_name' => "{$v}"
            ]);
    }
}
