<?php

use App\TablaInfo\ConfigTramiteTablaInfo;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class ConfigTramitePermissionSeeder extends Seeder
{

    public function run()
    {
        $permisos = ConfigTramiteTablaInfo::permisos();
        $tablaConfigTramite = ConfigTramiteTablaInfo::NOMBRE_TABLA;
        foreach ($permisos as $k => $v)
            Permission::create([
                'name' => "{$tablaConfigTramite}.{$k}",
                'display_name' => "{$v}"
            ]);
    }
}
